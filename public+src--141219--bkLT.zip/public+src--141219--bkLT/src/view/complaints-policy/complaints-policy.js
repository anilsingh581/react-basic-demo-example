import React from 'react'
import Headingbrd from '../../components/headingbrd'
import ComplaintPolicyText from '../../components/complaintPolicyC/complaintPolicyText'
import WrapperRow from '../../components/wrapperRow'
import Helmet from 'react-helmet'

export default () => {
    return (
        <>
        <Helmet>
            <title>Complaints Policy - LoanTube</title>
            <meta name="description" content="LoanTube has a policy to handle complaints as it helps in providing high quality service to the customers. Know what it does to promote fair business practices." />
        </Helmet>
            <Headingbrd><h1>Complaints Policy</h1></Headingbrd>
            <WrapperRow cls="cookiesMainSec">
                <div className="col-sm-12 comPol">
                    <ComplaintPolicyText />
                </div>
            </WrapperRow>
        </>
    )
}