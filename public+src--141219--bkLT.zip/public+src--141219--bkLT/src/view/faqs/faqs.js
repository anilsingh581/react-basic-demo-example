import React from 'react'
import Wrapper from '../../components/wrapper'
import Headingbrd from '../../components/headingbrd'
import Faqt1 from '../../components/faqC/faqt1'
import Faqt2 from '../../components/faqC/faqt2'
import Homewarnings from '../../components/warnings/homewarnings'
import Helmet from 'react-helmet'

export default () =>
    <>
    <Helmet>
            <title>FAQs - LoanTube | Compare Loans</title>
            <meta name="description" content="Are you looking to apply for a loan but have some queries? LoanTube answered all your key questions here. ✓Read now." />
        </Helmet>
        <Wrapper cls="faqSec faqBg"> <Headingbrd>FAQs</Headingbrd>
            <ul className="nav nav-pills mb-3 faqTabTop" id="pills-tab" role="tablist">
                <li className="nav-item">
                    <a className="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Before You Apply</a>
                </li>
                <li className="nav-item ml-3">
                    <a className="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">During the Application Process</a>
                </li>
            </ul>
            <div className="tab-content" id="pills-tabContent">
                <div className="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                    <Faqt1 />
                </div>
                <div className="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                    <Faqt2 />
                </div>
            </div>
        </Wrapper>
        <Wrapper cls="homeWarningSec"><Homewarnings /></Wrapper>
    </>   