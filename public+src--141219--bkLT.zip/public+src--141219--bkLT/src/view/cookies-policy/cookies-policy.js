import React from 'react'
import Headingbrd from '../../components/headingbrd'
import WrapperRow from '../../components/wrapperRow'
import CookiesRight from '../../components/cookiesPolicyC/cookiesRight'
import CookiesLeft from '../../components/cookiesPolicyC/cookiesLeft'
import Helmet from 'react-helmet'

export default () => {
    return (
        <>
        <Helmet>
            <title>Cookies Policy - LoanTube | Compare Loans</title>
            <meta name="description" content="Cookie is a small piece of data sent from a website and is stored on the user’s device for marketing & technical purposes. Read our Cookies Policy here." />
            <body data-spy="scroll" data-target="#fixedLeftSidebar"></body>
        </Helmet>
            <Headingbrd>Cookies Policy</Headingbrd>
            <WrapperRow cls="cookiesMainSec">
                <div className="col-lg-3">
                    <CookiesLeft />
                </div>
                <div className="col-lg-9">
                    <p>A satisfied customer is the best source of advertisement, said by G.S. Alag. And we entirely believe in this ideology. To enhance your browsing experience while using our Site, we use cookies.</p>
                    <CookiesRight />
                </div>
            </WrapperRow>
        </>
    )
}