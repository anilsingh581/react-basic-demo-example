import React from 'react'
import HeadingBrd from '../../components/headingbrd'
import Subheading from '../../components/subheading'
import WrapperInn from '../../components/wrapperInn'
import PartnerBox from '../../components/ourPartnerC/partnerBox'
import Wrapper from '../../components/wrapper'
import PartnerList from '../../components/ourPartnerC/partnerList'
import Helmet from 'react-helmet'
const images = require.context('../../assets/images')

export default () => {
    const allPartBox = {
        LendingPartners : [
            {
                partLogo:'./shabrook.png', 
                partName:'SHAWBROOK BANK LIMITED', 
                abtPart:'Shawbrook is a specialist UK savings and lending bank founded in 2011 to serve the needs of SMEs and individuals in the UK with a range of lending and saving products. On 31 December 2017 their total lending reached £4.9 billion.', 
                companyNum:'00388466', 
                FCANum:'204574', 
                url:'https://www.shawbrook.co.uk/', 
                terms:'https://www.shawbrook.co.uk/terms-of-use/', 
                privacy:'https://www.shawbrook.co.uk/privacy-notice/', 
                cookiesPolicy:'https://www.shawbrook.co.uk/cookie-policy/'
            },
            {
                partLogo:'./bamboo.png', 
                partName:'BAMBOO LIMITED', 
                abtPart:'Bamboo based in Southampton, London and Caerphilly, is a direct lender. Their service is trusted by over 50,000 customers and they have been voted Best Personal Loan Provider two years in a row at the 2017 and 2018 Consumer Credit Awards.', 
                companyNum:'05629336', 
                FCANum:'720565', 
                url:'https://www.bambooloans.com/', 
                terms:'https://www.bambooloans.com/s/how-we-use-your-information', 
                privacy:'https://www.bambooloans.com/s/how-we-use-your-information', 
                cookiesPolicy:'https://www.bambooloans.com/s/how-we-use-your-information'
            },
            {
                partLogo:'./amigo.png', 
                partName:'AMIGO LOANS LTD', 
                abtPart:'Amigo is a specialised guarantor lender offers loans from £500-£10,000 over terms between 12 and 60 months, with a maximum APR of 49.9%. Amigo is based at Nova Building, 118-128 Commercial Road, Bournemouth, BH2 5LT.', 
                companyNum:'04841153', 
                FCANum:'708284', 
                url:'https://www.amigoloans.co.uk/', 
                terms:'https://www.amigoloans.co.uk/loans/terms', 
                privacy:'https://www.amigoloans.co.uk/privacy-policy', 
                cookiesPolicy:'https://www.amigoloans.co.uk/site-terms'
            },
            {
                partLogo:'./ukCredit.png', 
                partName:'UK CREDIT LIMITED', 
                abtPart:'UK Credit is one of the leading direct guarantor lenders in the market todayoffers loans from £1500-£12,500 over terms between 18 and 60 months.UK Credit is based atSt Crispin’s House, Duke Street, Norwich, Norfolk, United Kingdom, NR3 1PD.', 
                companyNum:'06929807', 
                FCANum:'721556', 
                url:'https://www.ukcredit.co.uk/', 
                terms:'https://www.ukcredit.co.uk/terms-conditions/', 
                privacy:'https://www.ukcredit.co.uk/privacy-policy/', 
                cookiesPolicy:'https://www.ukcredit.co.uk/cookie-policy/'
            }
        ],
        ServiceProviders : [
            {
                partLogo:'./equfix.png', 
                partName:'EQUIFAX LIMITED', 
                abtPart:'Equifax is one of the largest credit reference agencies in UK with 115 years of experience. The company organises, assimilates and analyses data on more than 820 million consumers and more than 91 million businesses worldwide, and its database includes employee data contributed from more than 7,100 employers.', 
                companyNum:'2425920', 
                FCANum:'720565', 
                url:'https://www.equifax.co.uk/', 
                terms:'https://www.equifax.co.uk/About-us/Terms_of_use.html', 
                privacy:'https://www.equifax.co.uk/About-us/Privacy_policy.html', 
                cookiesPolicy:'https://www.equifax.co.uk/About-us/Privacy_policy.html'
            },
            {
                partLogo:'./yodlee.png', 
                partName:'YODLEE, INC', 
                abtPart:'Envestnet® | Yodlee® is a leading data aggregation and data analytics platform powering dynamic, cloud-based innovation for digital financial services. Their platform has proudly fuelled innovation financial institutions (FIs) and fintech for over 17 years ultimately helping consumers get better lending rates, lower fees, higher returns, and more.', 
                companyNum:'FC031908', 
                FCANum: '',
                url:'https://www.yodlee.com/', 
                terms:'https://www.yodlee.com/legal/privacy-notice/', 
                privacy:'https://www.yodlee.com/legal/privacy-notice/', 
                cookiesPolicy:'https://www.yodlee.com/legal/privacy-notice/'
            }
        ],
        BrokerPartners : [
            {
                partLogo:'./movevo.png', 
                partName:'Monevo Limited', 
                abtPart:'Monevo is an award-winning company which helps consumers search and find the best available rates on personal loans. Monevo Limited is based at Oxford House Oxford Road Macclesfield Cheshire SK11 8HS.', 
                companyNum:'06511345', 
                FCANum:'723672', 
                url:'https://www.monevo.co.uk/', 
                terms:'https://www.monevo.co.uk/terms-of-service', 
                privacy:'https://www.monevo.co.uk/privacy-policy', 
                cookiesPolicy:'https://www.monevo.co.uk/cookie-policy'
            },
            {
                partLogo:'./tuk.png', 
                partName:'T Dot UK Limited', 
                abtPart:'T Dot UK Ltd, based in Bournemouth, is an online broker specialising in packaging for short term loans, guarantor loans, personal unsecured loans, and instalment loans. T Dot UK Limited is authorised & regulated by Financial Conduct Authority.', 
                companyNum:'09225672', 
                FCANum:'688026', 
                url:'https://t.uk/', 
                terms:'https://t.uk/terms-and-conditions-of-use/', 
                privacy:'https://t.uk/privacy-policy/', 
                cookiesPolicy:'https://t.uk/privacy-policy/'
            }
        ],
        listWebsite : [
            {href:'https://www.loan-broker.uk/', imgSrc:'./loanBroker.png', companyName:'Loan Broker'},
            {href:'https://www.786loans.uk/', imgSrc:'./786loans.png', companyName:'786 Loans'},
            {href:'https://www.oysterloan.co.uk/', imgSrc:'./oysterloan.png', companyName:'Oyster Loan'},
            {href:'https://www.loantube.com/', imgSrc:'./loantubeLogo.png', companyName:'LoanTube'},
            {href:'https://www.loan-princess.uk/', imgSrc:'./loanprinces.png', companyName:'Loan Princess'},
            {href:'http://www.tigerlionfinancial.co.uk/', imgSrc:'./tigerLoans.png', companyName:'Tiger Loans'}
        ]
    }
    const renderallPartBox = (items) => {
        return items.map((item, i) => <PartnerBox key={i} partLogo={images(item.partLogo)} partName={item.partName} abtPart={item.abtPart} companyNum={item.companyNum} FCANum={item.FCANum} url={item.url} terms={item.terms} privacy={item.privacy} cookiesPolicy={item.cookiesPolicy} />)
    }
    const renderlistWebsite = () => {
        return allPartBox.listWebsite.map((item, i) => <PartnerList key={i} href={item.href} imgSrc={images(item.imgSrc)} companyName={item.companyName} />)
    }
    return (
        <>
        <Helmet>
            <title>Our Partners - LoanTube | Compare Loans</title>
            <meta name="description" content="LoanTube recognize the importance of key partnerships to provide its customers with better and innovative services. Here is a list of partners, we work with." />
        </Helmet>
            <HeadingBrd>Our Partners</HeadingBrd>
            <WrapperInn><Subheading>Our Lending Partners</Subheading>
                <div className="row">
                    {renderallPartBox(allPartBox.LendingPartners)}
                </div>
            </WrapperInn>
            <WrapperInn><Subheading>Our Service Providers</Subheading>
                <div className="row">
                    {renderallPartBox(allPartBox.ServiceProviders)}
                </div>
            </WrapperInn>
            <WrapperInn><Subheading>Our Broker Partners</Subheading>
                <div className="row">
                    {renderallPartBox(allPartBox.BrokerPartners)}
                </div>
            </WrapperInn>
            <Wrapper cls="ourPartnerSec"><Subheading>List of websites owned & operated by Tiger Lion Financial Limited</Subheading>
                <div className="listWebSec"><ul>{renderlistWebsite()}</ul></div>
            </Wrapper>
            
        </>
    )
}