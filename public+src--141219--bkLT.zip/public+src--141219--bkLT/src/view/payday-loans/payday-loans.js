import React from 'react'
import Wrapper from '../../components/wrapper'
import Headingbrd from '../../components/headingbrd'
import PaydayLTT from '../../components/paydayL/paydayLtt'
import PaydayLFQ from '../../components/paydayL/paydayLfq'
import InnerWarning from '../../components/warnings/innerwarning'
import Lists from '../../components/lists'
import OurCompari from '../../components/loans/ourCompari'
import BannerImages from '../../components/bannerImages'
import Helmet from 'react-helmet'
const images = require.context('../../assets/images')

export default () => {
    const allList = {
        mainlists: [
          {lidata:'Short term loan to be repaid by your next payday or within a few monthsAvailable to Home Owners & Tenants both'},
          {lidata:'Maximum interest 80p per day per £100'},
          {lidata:'You can pay off your loan early subjected to early repayment terms of the lender'},
          {lidata:'All lenders in LoanTube panel are Financial Conduct Authority licensed'},
        ],
        mainImage:[
            {cls:'PicMainCircle Place', mysrc:'./main-circle.png', alt:'Payday Loans'},
            {cls:'PicInnerCircle Place', mysrc:'./inner-circle.png', alt:'Payday Loans'},
            {cls:'Pic7 zoomIn7', mysrc:'./groth.png', alt:'Payday Loans'},
            {cls:'Pic6 zoomIn6', mysrc:'./note.png', alt:'Payday Loans'},
            {cls:'Pic5 zoomIn5', mysrc:'./clock.png', alt:'Payday Loans'},
            {cls:'Pic4 zoomIn4', mysrc:'./moneyConvert.png', alt:'Payday Loans'},
            {cls:'Pic3 zoomIn3', mysrc:'./money.png', alt:'Payday Loans'},
            {cls:'Pic2 zoomIn2', mysrc:'./pig.png', alt:'Payday Loans'},
            {cls:'Pic1 zoomIn1', mysrc:'./paydayMain.png', alt:'Payday Loans'},
            {cls:'PicBase zoomIn', mysrc:'./head-img-temp.png', alt:'Payday Loans'}
       ]
     }
     const renderallList = (items) => {
       return items.map((item, i) => <Lists key={i} text={item.lidata} />)
     }
     const rendermainImage = (items) => {
        return items.map((item, i) => <BannerImages key={i} cls={item.cls} mysrc={images(item.mysrc)} alt={item.alt} />)
    }
    return (
        <>
        <Helmet>
            <title>Payday Loans - Compare | LoanTube</title>
            <meta name="description" content="Payday Loans are short term loan to be repaid by your next payday or within a few months. For any financial emergency, a short-term payday loan can be a quick help." />
        </Helmet>
        <section className="loansProducts">
        <div className="container">
            <div className="row">                  
                    <div className="col-lg-6">
                            <div className="headingAll"><h1>Payday Loans</h1></div>
                         <ul>{renderallList(allList.mainlists)}</ul>
                         <div className="mainHomePage loanApplyInner">
                            <a href="https://app.loantube.com/Customer/LoanApplication?utm_source=referral&amp;utm_campaign=loanapplication&amp;utm_website=www.loantube.com&amp;utm_webpage=/" className="btn btn-danger">Find your loans</a>
                        </div>
                    </div>
                    <div className="col-lg-6">
                         <div className="lanImg">
                            {rendermainImage(allList.mainImage)}
                        </div>
                    </div>
            </div>
        </div>
    </section>
            <Wrapper cls="homeWarningSec mt-n4"><OurCompari /></Wrapper>
            <Wrapper cls="threeThingsSec"><Headingbrd>3 Things to Know About Our Payday Loans</Headingbrd><PaydayLTT/></Wrapper>
            <Wrapper cls="faqLoanInnerSec faqBg"><Headingbrd>FAQs on Payday Loans</Headingbrd><PaydayLFQ/></Wrapper>
            <Wrapper cls="homeWarningSec"><InnerWarning /></Wrapper>
        </>
    )
}