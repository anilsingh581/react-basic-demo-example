import React from 'react'
import Wrapper from '../../components/wrapper'
import Headingbrd from '../../components/headingbrd'
import LongTermLoansLTT from '../../components/LongTermLoansC/LongTermLoansLTT'
import LongTermLoansLFQ from '../../components/LongTermLoansC/LongTermLoansLFQ'
import InnerWarningNew from '../../components/warnings/innerWarningNew'
import Lists from '../../components/lists'
import OurCompari from '../../components/loans/ourCompari'
import BannerImages from '../../components/bannerImages'
import Helmet from 'react-helmet'
const images = require.context('../../assets/images')

export default () => {
    const allList = {
        mainlists: [
          {lidata:'Loans from £1,000 to £35,000'},
          {lidata:'The rate you see is the rate you get'},
          {lidata:'Flexible repayment period – 3 years to 7 years'},
          {lidata:'Affordable rates of interest and convenient to apply'},
          {lidata:'We use Soft Credit Check- that won’t harm your credit score'},
        ],
        mainImage:[
            {cls:'PicMainCircle Place', mysrc:'./main-circle.png', alt:'Long Term Loans'},
            {cls:'PicInnerCircle Place', mysrc:'./inner-circle.png', alt:'Long Term Loans'},
            {cls:'Pic7 zoomIn7', mysrc:'./groth.png', alt:'Long Term Loans'},
            {cls:'Pic6 zoomIn6', mysrc:'./passport.png', alt:'Long Term Loans'},
            {cls:'Pic5 zoomIn5', mysrc:'./tree.png', alt:'Long Term Loans'},
            {cls:'Pic4 zoomIn4', mysrc:'./coco.png', alt:'Long Term Loans'},
            {cls:'Pic3 zoomIn3', mysrc:'./boart.png', alt:'Long Term Loans'},
            {cls:'Pic2 zoomIn2', mysrc:'./drink.png', alt:'Long Term Loans'},
            {cls:'Pic1 zoomIn1', mysrc:'./holiday-main.png', alt:'Long Term Loans'},
            {cls:'PicBase zoomIn', mysrc:'./head-img-temp.png', alt:'Long Term Loans'}
       ]
     }
    
     const renderallList = (items) => {
       return items.map((item, i) => <Lists key={i} text={item.lidata} />)
     }
     const rendermainImage = (items) => {
        return items.map((item, i) => <BannerImages key={i} cls={item.cls} mysrc={images(item.mysrc)} alt={item.alt} />)
    }
    return (
        <>
        <Helmet>
            <title>Long Term Loans | LoanTube</title>
            <meta name="description" content="Long Term Loans comes with fixed & predictable repayments. With LoanTube, you can compare offers from multiple holiday loan providers that consider all credit scores." />
        </Helmet>
            <section className="loansProducts">
        <div className="container">
            <div className="row">                  
                    <div className="col-lg-6">
                            <div className="headingAll"><h1>Long Term Loans</h1></div>
                         <ul>{renderallList(allList.mainlists)}</ul>
                         <div className="mainHomePage loanApplyInner">
                            <a href="https://app.loantube.com/Customer/LoanApplication?utm_source=referral&amp;utm_campaign=loanapplication&amp;utm_website=www.loantube.com&amp;utm_webpage=/" className="btn btn-danger">Find your loans</a>
                        </div>
                    </div>
                    <div className="col-lg-6">
                        <div className="lanImg">
                            {rendermainImage(allList.mainImage)}
                        </div> 
                    </div>
            </div>
        </div>
    </section>
    <Wrapper cls="homeWarningSec mt-n4"><OurCompari /></Wrapper>
    <Wrapper cls="threeThingsSec"><Headingbrd>3 Things to Know About Our Long Term Loans</Headingbrd><LongTermLoansLTT/></Wrapper>
    <Wrapper cls="faqLoanInnerSec faqBg"><Headingbrd>FAQs on Long Term Loans</Headingbrd><LongTermLoansLFQ/></Wrapper>
    <Wrapper cls="homeWarningSec"><InnerWarningNew /></Wrapper>
        </>
    )
}