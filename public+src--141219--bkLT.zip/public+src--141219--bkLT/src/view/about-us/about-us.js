import React from 'react'
import AbouttpBox from '../../components/about/tpBox'
import AboutBtmBox from '../../components/about/btmBox'
import Wrapper from '../../components/wrapper'
import Helmet from 'react-helmet'
const images = require.context('../../assets/images')
export default () => {
    return (
        <> 
        <Helmet>
            <title>About us - LoanTube | Compare Loans</title>
            <meta name="description" content="LoanTube is a loan comparison website that compares actual APRs so what you see is what you get and you know exactly how much you’re going to pay back." />
        </Helmet>
        <div className="headingAll">
        <h1><span id="abtHeading">No wait, It's about YOU!</span></h1>
    </div>
    <div className="brdCenter"></div>
    <section>
        <div className="container">
            <div className="row">
                <div className="col">
                    <div className="aboutMainSec">
                        <AbouttpBox />
                        <div className="text-center">
                            <div className="abtBxx abtBxxRed">What am I going to change?</div>
                        </div>
                        <AboutBtmBox />
                        <div className="abtBxx">
                            My team and I set up <a href="https://www.loantube.com/guides/launch-news-loantube/">LoanTube</a> to do
                                something about it – it’s something we all feel very strongly about. It should be much
                                easier for those who need money to cover an emergency bill when one arises and not pay
                                over the odds for the privilege.<br /><br />
                            The right to live free of financial worry is a human right!
                        </div>
                    </div>
<div className="clr"></div>
                    <div className="guidelineSec">
                        <div className="guideHead">
                            <div><img src={images('./guidelinesImg.png')} alt="Guide Lines" /></div>
                            <div className="brdVerti"></div>
                            <div>LoanTube will always work to a proper set of guidelines.</div>
                        </div>
                        <ul>
                            <li>LoanTube is a proper loan comparison site and not only do we compare the loan quotes you
                                get, but we also make sure that you only deal with fair, legit, above-the-line
                                lenders.</li>
                            <li>We’ll compare actual APRs and interest rates so what you see is what you get and you
                                know exactly how much you’re going to pay back. </li>
                            <li>My team and I will do everything we can to make sure that the loan sharks are thrown out
                                of business and no one falls into their trap again.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <Wrapper cls="loveSec">With LoanTube, you’re in safe hands. If you’ve used loan comparison sites before and you didn’t find them clear or helpful, then my team and I built LoanTube especially for you.<br /><br />
                        Help us spread the word by sharing the story to help other people like you.<br /><br />
                        Next time you need money to cover an emergency bill, try LoanTube and see the love we have for you when we find you a really good loan.<br /><br />
                        <span>Love</span><br />
                        [GURPRIT]</Wrapper>
    
        </>
    )
}