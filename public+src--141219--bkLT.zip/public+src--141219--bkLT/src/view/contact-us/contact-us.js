import React from 'react'
import HeadingBrd from '../../components/headingbrd'
import Wrapper from '../../components/wrapper'
import Lists from '../../components/lists'
import ContactFrm from '../../components/contactC/contactFrm'
import Helmet from 'react-helmet'
const images = require.context('../../assets/images')

export default () => {
    const allList = {
        mainlists: [
          {lidata:'Simple loan application process'},
          {lidata:'Get the loan decision instantly'},
          {lidata:'Compare actual APRs among multiple lenders'}
        ]
     }
   
     const renderallList = (items) => {
       return items.map((item, i) => <Lists key={i} text={item.lidata} />)
     }
    return (
        <>
        <Helmet>
            <title>Contact Us - LoanTube | Compare Loans</title>
            <meta name="description" content="Contact us via Tel: 0208-088-1313 or Email: info@loantube.com to speak to LoanTube team." />
        </Helmet>
           <HeadingBrd>Get in touch with us</HeadingBrd> 
           <Wrapper cls="contactSec"><p><span>LoanTube</span> is a real rate loan comparison marketplace that compares actual APRs (Annual Percentage Rate) and monthly repayments. This real-time loans comparison marketplace has a proprietary loan matching engine which connects the right borrower with the right lender.
<br/><br/>
                    In short, what you see on our website is what you get in reality.
                </p></Wrapper>
    <section className="contactSec2 mt-5">
            <div className="container">
                    <div className="row justify-content-md-center">
                      <div className="col col-lg-5">
                        <h3>What do you get at LoanTube:</h3>
                        <div className="contsec2">
                        <ul>{renderallList(allList.mainlists)}</ul>
                    </div>
                      </div>
                      <div className="col col-lg-2">
                        <img src={images('./contactRight.png')} alt="Contact" />
                      </div>
                    </div>
                  </div>
    </section>
    <Wrapper cls="contactMail">Contact us at <span>0208 088 1313</span> or <a href="mailto:info@loantube.com">info@loantube.com</a> to connect with LoanTube team.</Wrapper>
    <section className="contactAddress">
        <div className="container">
            <div className="row">
                <div className="col-lg-8">
                   <h4> Tiger Lion Financial Limited</h4>

                   <p> Registered in England & Wales: Company Number: <span>10189367</span></p>
                    
                    <h5>Registered Office Address:</h5>
                    <p>71-75 Shelton Street, Covent Garden, London, WC2H 9JQ
                    Information Commissioners Office Registration Number: <span>ZA185613</span></p>
                    
                    <h5>Authorised and regulated by the Financial Conduct Authority(FCA)</h5>
                    <p>FCA Firm Reference Number: <span>753151</span></p>
                    <h4>  Contact details for:</h4>

<p>Personal data requests: <a href="mailto:info@loantube.com">info@loantube.com</a></p>

<p>Unsubscribing our marketing emails: <a href="mailto:info@loantube.com">info@loantube.com</a></p>

<p>Business enquiry contact details: <a href="mailto:business@loantube.com">business@loantube.com</a></p>
                </div>
                <div className="col-lg-4">
                    <ContactFrm />
                </div>
            </div>
        </div>
    </section>
        </>
    )
}