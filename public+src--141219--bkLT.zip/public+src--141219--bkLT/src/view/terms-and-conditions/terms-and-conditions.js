import React from 'react'
import Headingbrd from '../../components/headingbrd'
import WrapperRow from '../../components/wrapperRow'
import TermsConditionCLeft from '../../components/termsConditionC/termsConditionCLeft'
import TermsConditionCRight from '../../components/termsConditionC/termsConditionCRight'
import Helmet from 'react-helmet'

export default () => {
    return (
        <>
        <Helmet>
            <title>Terms and conditions - LoanTube</title>
            <meta name="description" content="These Terms & Conditions are rules by which one must agree to abide in order to use a service that are offered by LoanTube." />
            <body data-spy="scroll" data-target="#fixedLeftSidebar"></body>
        </Helmet>
            <Headingbrd><h1>Terms and conditions</h1></Headingbrd>
            <WrapperRow cls="cookiesMainSec">
                <div className="col-lg-3">
                    <TermsConditionCLeft />
                </div>
                <div className="col-lg-9">
                    <TermsConditionCRight />
                </div>
            </WrapperRow>
        </>
    )
}