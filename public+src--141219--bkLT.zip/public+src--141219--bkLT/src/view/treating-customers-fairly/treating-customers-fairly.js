import React from 'react'
import Headingbrd from '../../components/headingbrd'
import WrapperRow from '../../components/wrapperRow'
import TreatingCustomerFairlyText from '../../components/treatingCustomerFairly/treatingCustomerFairlyText'
import Helmet from 'react-helmet'
export default () => {
    return (
        <>
        <Helmet>
            <title>Treating Customers Fairly - LoanTube | Compare Loans</title>
            <meta name="description" content="Core culture of LoanTube is to treat the customers fairly to serve them best. This page will tell you all about how we treat our customers fairly." />
        </Helmet>
            <Headingbrd><h1>Treating Customers Fairly</h1></Headingbrd>
            <WrapperRow cls="cookiesMainSec">
                <div className="col-sm-12 comPol">
                    <TreatingCustomerFairlyText/>
                </div>
            </WrapperRow>
        </>
    )
}