import React from 'react'
import Wrapper from '../../components/wrapper'
import HeadingBrd from '../../components/headingbrd'
import Helmet from 'react-helmet'

export default () => {
    return (
        <>
        
        <Helmet>
            <title>Compare Personal Loans with real interest rates | LoanTube</title>
            <meta name="description" content="Compare personal loans on LoanTube with real interest rates from multiple lenders. The rate you see for loans on LoanTube is the rate you get in reality." />
        </Helmet>
            <HeadingBrd><h1>Page not found</h1></HeadingBrd>
            <Wrapper cls="text-center"><p>Page not found content Page not found content Page not found content</p></Wrapper>
        </>
    )
}