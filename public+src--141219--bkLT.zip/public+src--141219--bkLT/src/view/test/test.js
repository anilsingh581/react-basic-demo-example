import React, { Component } from 'react'


const Admin = () => {
    const toggleNav = () => {
        return (
            // alert("hi22"),
            document.querySelector('.showChildNavs').classList.toggle('active')
        )
    }
    return (
        <>
            <ul>
                <li className="showChildNavs"><span className="showChildNav" onClick={toggleNav}><i className="fa fa-caret-right"></i></span> Main One
                                <ul className="menuLevelOne">
                        <li><span className="showChildNav" onClick={toggleNav}><i className="fa fa-caret-right"></i></span> Level One Nav 1
                                        <ul className="menuLevelTwo">
                                <li>Level Two Nav 1</li>
                                <li>Level Two Nav 2</li>
                                <li>Level Two Nav 3</li>
                            </ul>
                        </li>
                        <li>Level One Nav 2</li>
                        <li>Level One Nav 3</li>
                    </ul>
                </li>
                <li className="showChildNavs"><span className="showChildNav" onClick={toggleNav}><i className="fa fa-caret-right"></i></span> Main Two
                                <ul className="menuLevelOne">
                        <li><span className="showChildNav" onClick={toggleNav}><i className="fa fa-caret-right"></i></span> Level One Nav 1
                                        <ul className="menuLevelTwo">
                                <li>Level Two Nav 1</li>
                                <li>Level Two Nav 2</li>
                                <li>Level Two Nav 3</li>
                            </ul>
                        </li>
                        <li>Level One Nav 2</li>
                        <li>Level One Nav 3</li>
                    </ul>
                </li>
                <li>Main Three</li>
                <li>Main Four</li>
            </ul>
        </>
    )
}

export default Admin;