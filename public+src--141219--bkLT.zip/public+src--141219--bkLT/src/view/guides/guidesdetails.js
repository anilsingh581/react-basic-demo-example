import React, { Component } from 'react'
import Helmet from 'react-helmet'
import { Link } from 'react-router-dom'
import MySidebar from '../../components/mysidebar'
import renderHTML from 'react-render-html';
import { categoryName, dateFormat, apiBaseUrl } from '../../assets/js/helpers'

export default class GuidesDetails extends Component {
    state = {
        error: null,
        isloaded: false,
        listdata: {}
    }
    constructor(props) {
        super(props);
        this.state = this.props.location.state;
        this.state.listdata = this.blogResult;
    }
    blogResult = {};
    metaTagsTimeout = null;


    componentDidMount() {
        fetch(apiBaseUrl+'api/blog/' + this.state.blogUID)
            .then(response => response.json())
            .then(result => {
                this.setState({
                    isloaded: false,
                    listdata: result.data
                });
                this.blogResult = result.data;
                //Bind meta tags on HTML Head 
                document.getElementById("mainBodyLoanT").insertAdjacentHTML('beforeend', result.data.allMeta);

            })
            .catch(error => {
                this.setState({
                    isloaded: true,
                    error
                })
            })



    }

       componentWillUnmount(){
        window.location.reload();
        clearTimeout(this.metaTagsTimeout); 
       }

    render() {

        return (
            <>
                <Helmet>
                    <body className="bloginner"></body>
                </Helmet>
                <div className="container py-3">
                    <div className="row">
                        <div className="col-lg-9">
                            <div className="leftContentSec">
                                <div className="blgSection">
                                    <div className="blogMainImg">
                                        <img src={this.state.listdata.blgImg} alt={this.state.listdata.titleName} />
                                    </div>
                                    <div className="blogHeader">
                                        <ul>
                                            <li className="blgEntryDate">{dateFormat(this.state.listdata.createdAt)}</li>
                                            <li>|</li>
                                            <li className="blgEntryCategory">
                                                <Link id={this.state.listdata.blgCategory} to={{ pathname: this.state.listdata.blgCategoryURL, search: this.state.listdata.blgCategoryURL, state: { id: this.state.listdata.blgCategory } }}>{categoryName(this.state.listdata.blgCategory)}</Link></li>
                                            <li>|</li>
                                            <li className="blgEntryCategory">By admin</li>
                                        </ul>
                                    </div>
                                    <div className="blgEntryTitle">{this.state.listdata.titleName}</div>
                                    <div className="blgEntryContent">{renderHTML(`${this.state.listdata.text}`)}</div>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-3">
                            <MySidebar />
                        </div>
                    </div>
                </div>
            </>
        )
    }
}