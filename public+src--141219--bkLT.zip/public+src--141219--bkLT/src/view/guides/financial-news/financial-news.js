import React, { Component } from 'react'
import Helmet from 'react-helmet'
import GuideMainC from '../../../components/guidesMainC'
import MySidebar from '../../../components/mysidebar'
import {dateFormat, apiBaseUrl} from '../../../assets/js/helpers'

export default class FinancialNews extends Component {
    state = {
        error: null,
        isloaded: false,
        listdata: [],
    }

    constructor(props) {
        super(props);
        this.state = this.props.location.state;
        this.state.listdata = this.LoanCategoryList;
    }

    LoanCategoryList = [];

    componentDidMount() {
        fetch(apiBaseUrl+'api/LoanCategory/' + this.state.id)
            .then(response => response.json())
            .then(result => {
                this.LoanCategoryList = result.data;
                this.setState({
                    isloaded: false,
                    listdata: result.data
                })

            })
            .catch(error => {
                this.setState({
                    isloaded: true,
                    error
                })
            })
    }

    renderBlogdata = () => {
        return this.state.listdata.map((item, i) =>
            <GuideMainC blogUID={item.blogUID} key={i} blgTitle={item.titleName} blgTime={dateFormat(item.createdAt)} blgCategoryUrl={item.blgCategoryURL} blgCategory={item.blgCategory} blgMainContent={item.text} blgTitleUrl={item.titleURL}  blgImg={item.blgImg} blgAlt={item.titleName} />
        )
    }

    render() {
        return (
            <>
                <Helmet>
                    <title>Guides - LoanTube | Compare Loans</title>
                    <meta name="description" content="LoanTube aims at helping borrowers in finding the right loan. Our guide will be helpful in providing a 360-degree approach to the world of finance." />
                    <body className="blogCategories"></body>
                </Helmet>
                <div className="container py-3">
                    <div className="row">
                        <div className="col-lg-9">
                            <div className="leftContentSec">
                                {this.renderBlogdata()}
                            </div>
                        </div>
                        <div className="col-lg-3">
                            <MySidebar />
                        </div>
                    </div>
                </div>
            </>
        )
    }
}