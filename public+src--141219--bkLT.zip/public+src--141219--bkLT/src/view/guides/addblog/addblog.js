import React, { Component } from 'react'
import axios from 'axios';
import { Link } from 'react-router-dom'
import { categoryName, apiBaseUrl } from '../../../assets/js/helpers'
import Logout from '../../../components/logout'

import '../../../assets/js/globals'
import ReactSummernote from 'react-summernote';
import 'react-summernote/dist/react-summernote.css';
import 'bootstrap/js/dist/modal';
import 'bootstrap/js/dist/dropdown';
import 'bootstrap/js/dist/tooltip';

export default class Add extends Component {

    constructor(props) {
        super(props);
        if (window.localStorage.getItem('token') === null) {
            props.history.push('/login')
        }

        this.handleChange = this.handleChange.bind(this);
        this.handleChangeFor = this.handleChangeFor.bind(this);
        this.handleImageChange = this.handleImageChange.bind(this);
    }

    addblogObject = {
        titleName: "",
        contentDescription: "",
        titleURL: "",
        metaattrib: "",
        metaattribvalue: "",
        metacontent: "",
        blgCategory: "",
        blgCategoryURL: "",
        _id: "",
        text: "",
        blgImg: '',
        blogUID: null,
        file: '',
        imagePreview_Url: '',
        allMeta: ''
    }

    state = this.addblogObject;

    handleChange = (propertyName, event) => {
        const state = this.state;
        state[propertyName] = event.target.value;
        this.setState({ state: state });
    }

    handleChangeFor(value) {
        this.setState({ text: value });
    }

    onImageUpload = (fileList) => {
        const reader = new FileReader();
        reader.onloadend = () => {
            ReactSummernote.insertImage(reader.result);
        }
        reader.readAsDataURL(fileList[0]);
    }

    uuidv4() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    handleImageChange(e) {
        e.preventDefault();
        let reader = new FileReader();
        let file = e.target.files[0];
        reader.onloadend = () => {
            this.setState({
                file: file,
                imagePreview_Url: reader.result
            });
        }
        reader.readAsDataURL(file)
    }

    submitDetails = () => {
        this.state.blogUID = this.uuidv4();
        let blogCategoryURL = categoryName(this.state.blgCategory);

        let userInfo = {
            "titleName": this.state.titleName,
            "contentDescription": this.state.contentDescription,
            "titleURL": this.state.titleName.replace(/\s+/g, "-"),
            "metaattrib": this.state.metaattrib,
            "metaattribvalue": this.state.metaattribvalue,
            "metacontent": this.state.metacontent,
            "blgCategory": this.state.blgCategory,
            "blgCategoryURL": blogCategoryURL.replace(/\s+/g, "-"),
            "text": this.state.text,
            "blgImg": this.state.imagePreview_Url,
            "blogUID": this.state.blogUID,
            "allMeta": this.state.allMeta
        }

        axios.post(apiBaseUrl + 'api/blog', userInfo)
            .then(result => {
                this.setState({
                    titleName: "",
                    contentDescription: "",
                    titleURL: "",
                    metaattrib: "",
                    metaattribvalue: "",
                    metacontent: "",
                    blgCategory: "",
                    blgCategoryURL: "",
                    _id: "",
                    text: "",
                    blgImg: '',
                    blogUID: null,
                    file: '',
                    imagePreview_Url: '',
                    allMeta: ''
                });
            })
            .catch(function (error) {
                console.log(error);
            });

        // setTimeout(() => {
        //     this.props.history.push("/guides/dashboard");
        //   }, 10);

    }

    render() {
        const isLoggedIn = window.localStorage.getItem('token')
        return (
            <>
                <div className="container addBlog">
                    <div className="row pt-3">
                        <div className="col">
                            <h1>Add New Post</h1>
                        </div>
                        <div className="col d-flex justify-content-end">
                            <Link className="btn btn-default" to={{ pathname: '/guides/dashboard' }}> Back </Link> | {isLoggedIn ? <Logout /> : null}
                        </div>
                    </div>
                    <div className="row">
                        <div className="col">
                            <div className="form-group">
                                <label>Blog Title Name</label>
                                <input type="text" className="form-control" id="titleName" value={this.state.titleName} onChange={this.handleChange.bind(this, 'titleName')} placeholder="Title Name" />
                            </div>
                        </div>
                    </div>
                    <div className="row form-group">
                        <div className="col-lg-6">
                            <label>Blog Main Image</label>
                            <div className="form-group files color">
                                <input type="file" onChange={this.handleImageChange} className="form-control" multiple="" />
                            </div>
                        </div>
                        <div className="col-lg-6"><div className="imagePreviewBlg"><img src={this.state.imagePreview_Url} /></div></div>
                    </div>
                    <div className="row">
                        <div className="col">
                            <div className="form-group">
                                <label>Content Description</label>
                                <ReactSummernote value={this.state.text}
                                    options={{
                                        lang: 'en-US',
                                        height: 200,
                                        dialogsInBody: true,
                                        toolbar: [
                                            ['style', ['style']],
                                            ['font', ['bold', 'underline', 'clear']],
                                            ['fontname', ['fontname']],
                                            ['para', ['ul', 'ol', 'paragraph']],
                                            ['table', ['table']],
                                            ['insert', ['link', 'picture', 'video']],
                                            ['view', ['fullscreen', 'codeview']]
                                        ]
                                    }}
                                    onChange={this.handleChangeFor}
                                    onImageUpload={this.onImageUpload}
                                />
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col">
                            <div className="row form-group">
                                <div className="col">
                                    <label>All Meta Data</label>
                                    <input type="text" className="form-control" id="metacontent" value={this.state.allMeta} onChange={this.handleChange.bind(this, 'allMeta')} placeholder="All Meta Data" />
                                </div>
                            </div>
                            <div className="row form-group">
                                <div className="col">
                                    <label>Blog Category</label>
                                    <select value={this.state.blgCategory} onChange={this.handleChange.bind(this, 'blgCategory')} className="form-control">
                                        <option id="0" value="0">Select Category</option>
                                        <option id="1" value="1">Financial News</option>
                                        <option id="2" value="2">Unsecured Personal Loans</option>
                                        <option id="3" value="3">Holiday Loans</option>
                                        <option id="4" value="4">Home Improvement Loans</option>
                                        <option id="5" value="5">Payday Loans</option>
                                        <option id="6" value="6">Poor Credit Loans</option>
                                        <option id="7" value="7">Wedding Loans</option>
                                        <option id="8" value="8">Others</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>
                        <button type="button" className="btn btn-primary" onClick={this.submitDetails}>Add post</button>
                    </div>
                </div>
            </>
        )
    }
}