import React, { Component } from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'
import { categoryName, apiBaseUrl, getEditorContent, editorContent } from '../../../assets/js/helpers'
import Logout from '../../../components/logout'

import '../../../assets/js/globals'
import ReactSummernote from 'react-summernote';
import 'react-summernote/dist/react-summernote.css';
import 'bootstrap/js/dist/modal';
import 'bootstrap/js/dist/dropdown';
import 'bootstrap/js/dist/tooltip';

export default class Edit extends Component {

    constructor(props) {
        super(props);
        this.state = this.props.location.state;
        this.handleImageChange = this.handleImageChange.bind(this);
    }

    handleChange = (propertyName, event) => {
        const detail = this.state.detail;
        detail[propertyName] = event.target.value;
        this.setState({ detail: detail });
    }

    onImageUpload = (fileList) => {

        const reader = new FileReader();
        reader.onloadend = () => {
            ReactSummernote.insertImage(reader.result);
        }
        reader.readAsDataURL(fileList[0]);
    }

    handleImageChange(e) {
        e.preventDefault();
        let reader = new FileReader();
        let file = e.target.files[0];

        reader.onloadend = () => {
            this.setState({
                file: file,
                imagePreview_Url: reader.result
            });
        }
        reader.readAsDataURL(file)
    }

    handleChangeFor(value) {
        getEditorContent(value)
    }

    updateDetail = () => {
        let blogCategoryURL = categoryName(this.state.detail.blgCategory);
        let userInfo = {
            _id: this.state.detail._id,
            titleName: this.state.detail.titleName,
            titleURL: this.state.detail.titleName.replace(/\s+/g, "-"),
            metaattrib: this.state.detail.metaattrib,
            metaattribvalue: this.state.detail.metaattribvalue,
            metacontent: this.state.detail.metacontent,
            blgCategory: this.state.detail.blgCategory,
            blgCategoryURL: blogCategoryURL.replace(/\s+/g, "-"),
            text: editorContent,
            blgImg: this.state.detail.blgImg,
            blogUID: this.state.detail.blogUID,
            allMeta: this.state.detail.allMeta
        }

        console.log(userInfo);
        axios.put(apiBaseUrl+'api/Blog/' + this.state.detail.blogUID, userInfo)
            .then(function (response) {
                //console.log(response);
            })
            .catch(function (error) {
                console.log(error);
            });
    }
    

    render() {
        const isLoggedIn = window.localStorage.getItem('token')
        return (
            <>
                <input type="hidden" id={this.state.detail.blogUID} ref={input => this._name = input} value="232323" />
                <div className="container addBlog">
                    <div className="row pt-3">
                        <div className="col">
                            <h1>Edit Post</h1>
                        </div>
                        <div className="col d-flex justify-content-end">
                        <Link className="btn btn-default" to={{ pathname: '/guides/dashboard' }}> Back </Link> | {isLoggedIn ? <Logout /> : null}
                            </div>
                    </div>
                    <div className="row">
                        <div className="col">
                            <div className="form-group">
                                <label>Blog Title Name</label>
                                <input type="text" className="form-control" value={this.state.detail.titleName} onChange={this.handleChange.bind(this, 'titleName')} placeholder="Title Name" />
                            </div>
                        </div>
                    </div>
                    <div className="row form-group">
                        <div className="col-lg-6">
                            <label>Blog Main Image</label>
                            <div className="form-group files color">
                                <input type="file" onChange={this.handleImageChange} className="form-control" multiple="" />
                            </div>
                        </div>
                        <div className="col-lg-6"><div className="imagePreviewBlg"><img src={this.state.detail.blgImg} alt={this.state.detail.titleName} /></div></div>
                    </div>
                    <div className="row">
                        <div className="col">
                            <div className="form-group">
                                <label>Content Description</label>
                                <ReactSummernote id="editText" value={this.state.detail.text}
                                    options={{
                                        lang: 'en-US',
                                        height: 200,
                                        dialogsInBody: true,
                                        toolbar: [
                                            ['style', ['style']],
                                            ['font', ['bold', 'underline', 'clear']],
                                            ['fontname', ['fontname']],
                                            ['para', ['ul', 'ol', 'paragraph']],
                                            ['table', ['table']],
                                            ['insert', ['link', 'picture', 'video']],
                                            ['view', ['fullscreen', 'codeview']]
                                        ]
                                    }}
                                    onChange={this.handleChangeFor}
                                    onImageUpload={this.onImageUpload}
                                />
                            </div>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col">
                            <div className="form-group">
                                <div className="row form-group">
                                    <div className="col">
                                        <label>All Meta Data</label>
                                        <input type="text" className="form-control" id="metacontent" value={this.state.detail.allMeta} onChange={this.handleChange.bind(this, 'allMeta')} placeholder="All Meta Data" />
                                    </div>
                                </div>
                                <div className="row form-group">
                                    <div className="col">
                                        <label>Blog Category</label>
                                        <select value={this.state.detail.blgCategory} onChange={this.handleChange.bind(this, 'blgCategory')} className="form-control">
                                            <option id="0" value="0">Select Category</option>
                                            <option id="1" value="1">Financial News</option>
                                            <option id="2" value="2">Unsecured Personal Loans</option>
                                            <option id="3" value="3">Holiday Loans</option>
                                            <option id="4" value="4">Home Improvement Loans</option>
                                            <option id="5" value="5">Payday Loans</option>
                                            <option id="6" value="6">Poor Credit Loans</option>
                                            <option id="7" value="7">Wedding Loans</option>
                                            <option id="8" value="8">Others</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div>
                        <button type="button" className="btn btn-primary" onClick={this.updateDetail}>Update</button>
                    </div>
                </div>
            </>
        )
    }
}