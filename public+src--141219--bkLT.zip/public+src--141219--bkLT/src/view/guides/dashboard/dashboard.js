import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import renderHTML from 'react-render-html';
import ReactTable from 'react-table'
import ReactTableDefaults from 'react-table'
import axios from 'axios';
import { categoryName, apiBaseUrl, dateFormat } from '../../../assets/js/helpers'
import Logout from '../../../components/logout'

export default class Header extends Component {

    state = {
        error: null,
        isloaded: false,
        listdata: []
    }

    result = [];

    constructor(props) {
        super(props);

        // for login
        if(window.localStorage.getItem('token')=== null){
            props.history.push('/login');
        }

        this.state = this.props.location.state;

        //get detail
        this.getDetail();

        //set default page
        Object.assign(ReactTableDefaults, {
            defaultPageSize: 5,
            minRows: 1
        })

    }

    columns = [{
        Header: 'Title Name',
        accessor: 'titleName',
        Cell: ({ row }) => <Link to={{ pathname: '/guides/editblog/' + `${row.titleURL}`, state: { detail: row } }} title="Edit" className="editClass" >{row.titleName}</Link>,
        filterable: true,
        sortable: true,
    }, {
        Header: 'Loan Type',
        accessor: 'blgCategory',
        Cell: props => <span className='number'>{categoryName(props.value)}</span> // Custom cell components!
    },
    {
        Header: 'Title URL',
        accessor: 'titleURL',
        Cell: props => <span className='number'>{props.value}</span>
    },
    {
        Header: 'Description',
        accessor: 'text',
        Cell: props => <span className='number'>{renderHTML(props.value)}</span>
    },
    {
        Header: 'Blog ID',
        accessor: 'blogUID',
        Cell: props => <span className='number'>{props.value}</span>
    }, 
     {
        Header: 'Created time',
        accessor: 'createdAt',
        Cell: props => <span className='number'>{dateFormat(props.value)}</span>,

    },
    {
        Header: 'Image',
        accessor: 'blgImg',
        Cell: props => <span className='number'>{props.value}</span>,

    },
    {
        Header: 'Meta Tags',
        accessor: 'allMeta',
        Cell: props => <span className='number'>{props.value}</span>,

    },
    // {
    //     Header: 'Meta Content',
    //     accessor: 'metacontent',
    //     Cell: props => <span className='number'>{props.value}</span>,

    // },
    // {
    //     Header: 'Meta Value',
    //     accessor: 'metaattribvalue',
    //     Cell: props => <span className='number'>{props.value}</span>,

    // },
    // {
    //     Header: 'Meta Key',
    //     accessor: 'metaattrib',
    //     Cell: props => <span className='number'>{props.value}</span>,

    // },
    {
        Header: 'id',
        accessor: '_id',
        Cell: props => <span className='number'>{props.value}</span>,

    },
    {
        Header: '',
        accessor: 'blogUID',
        Cell: row => (
            <div>
                <button onClick={() => this.deleteDetail(row)}>Delete</button>
            </div>
        )
    }];

    componentDidMount() { }

    getDetail = () => {
        fetch(apiBaseUrl+'api/blogs')
            .then(response => response.json())
            .then(result => {
                this.result = result.data;
                this.result = this.result.reverse();
                console.log(this.result);
                this.setState({
                    isloaded: false,
                    listdata: result.data
                })
            })
            .catch(error => {
                this.setState({
                    isloaded: true,
                    error
                })
            })
    }

    deleteDetail = (model) => {
        let id = model.original._id;
        axios.delete(apiBaseUrl+'api/Blog/' + id, model)
            .then(function (response) {
                //console.log(response);
                //this.getDetail();
            })
            .catch(function (error) {
                console.log(error);
            });
        window.location.reload()
    }

    render() {
        const isLoggedIn = window.localStorage.getItem('token')
        return (
            <>
                <div className="container">
                    <div className="row pt-3">
                        <div className="col">
                            <div className="float-right"><Link to="/guides/addblog" className="btn btn-primary">+ Add New post</Link>  {isLoggedIn ? <Logout /> : null}</div>
                            <h1>Loantube Dashboard</h1>
                        </div>
                    </div>
                    <div className="row">
                        <div className="col">
                            <ReactTable data={this.result} columns={this.columns} defaultPageSize={10} minRows={1} />
                        </div>
                    </div>
                </div>

            </>
        )
    }
}

