import React from 'react'
import Wrapper from '../../components/wrapper'
import Headingbrd from '../../components/headingbrd'
import USPLTT from '../../components/unsecurePL/uspltt'
import USPLFQ from '../../components/unsecurePL/usplfq'
import InnerWarning from '../../components/warnings/innerwarning'
import Lists from '../../components/lists'
import OurCompari from '../../components/loans/ourCompari'
import BannerImages from '../../components/bannerImages'
import Helmet from 'react-helmet'
const images = require.context('../../assets/images')

export default () => {

  const allList = {
     mainlists: [
       {lidata:'Use it for holiday, buy a car, home improvement & more'},
       {lidata:'Loans from £1000-£35000'},
       {lidata:'Borrow for 12-84 months'},
       {lidata:'Quick Approval. Fast payout'},
       {lidata:'The rate you see is the rate you get'},
     ],
     mainImage:[
        {cls:'PicMainCircle Place', mysrc:'./main-circle.png', alt:'Unsecured Personal Loans'},
        {cls:'PicInnerCircle Place', mysrc:'./inner-circle.png', alt:'Unsecured Personal Loans'},
        {cls:'Pic6 zoomIn6', mysrc:'./online-shop.png', alt:'Unsecured Personal Loans'},
        {cls:'Pic5 zoomIn5', mysrc:'./shop.png', alt:'Unsecured Personal Loans'},
        {cls:'Pic4 zoomIn4', mysrc:'./trolly.png', alt:'Unsecured Personal Loans'},
        {cls:'Pic3 zoomIn3', mysrc:'./car.png', alt:'Unsecured Personal Loans'},
        {cls:'Pic2 zoomIn2', mysrc:'./shop-bag.png', alt:'Unsecured Personal Loans'},
        {cls:'Pic1 zoomIn1', mysrc:'./personalLan-main.png', alt:'Unsecured Personal Loans'},
        {cls:'PicBase zoomIn', mysrc:'./head-img-temp.png', alt:'Unsecured Personal Loans'}
    ]
  }

  const renderallList = (items) => {
    return items.map((item, i) => <Lists key={i} text={item.lidata} />)
  }
  const rendermainImage = (items) => {
    return items.map((item, i) => <BannerImages key={i} cls={item.cls} mysrc={images(item.mysrc)} alt={item.alt} />)
}

    return(
        <>
        <Helmet>
            <title>Unsecured Personal Loans UK - Compare | LoanTube</title>
            <meta name="description" content="Unsecured Personal Loans are instalment loans where you don't have to provide any collateral or security. Tenants are equally eligible. £1000-£35000 ✓Apply Now" />
        </Helmet>
        <section className="loansProducts">
        <div className="container">
            <div className="row">                  
                    <div className="col-lg-6">
                            <div className="headingAll"><h1>Unsecured Personal Loans</h1></div>
                         <ul>
                           {renderallList(allList.mainlists)}
                         </ul>
                         <div className="mainHomePage loanApplyInner">
                            <a href="https://app.loantube.com/Customer/LoanApplication?utm_source=referral&amp;utm_campaign=loanapplication&amp;utm_website=www.loantube.com&amp;utm_webpage=/" className="btn btn-danger">Find your loans</a>
                        </div>
                    </div>
                    <div className="col-lg-6">
                    <div className="lanImg">
                        {rendermainImage(allList.mainImage)}
                    </div>
                    </div>
            </div>
        </div>
    </section>
    <Wrapper cls="homeWarningSec mt-n4"><OurCompari /></Wrapper>
    <Wrapper cls="threeThingsSec"><Headingbrd>3 Things to Know About Our Unsecured Personal Loans</Headingbrd> <USPLTT /></Wrapper>
    <Wrapper cls="faqLoanInnerSec faqBg"><Headingbrd>FAQs on Unsecured Personal Loans</Headingbrd><USPLFQ/></Wrapper>
    <Wrapper cls="homeWarningSec"><InnerWarning /></Wrapper>
        </>
    )
}