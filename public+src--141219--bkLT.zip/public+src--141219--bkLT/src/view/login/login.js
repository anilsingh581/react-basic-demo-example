import React, { useState } from "react";
import { Button } from "react-bootstrap";

export default function Login(props) {
    const [email, setEmail] = useState(""); 
    const [password, setPassword] = useState("");

    function validateForm() {
        return email.length > 0 && password.length > 0;
    }

    function handleSubmit(event) {
        event.preventDefault();
        if(email==='ss@gmail.com' && password ==='123' ){
            window.localStorage.setItem('token',true);
            props.history.push("/guides/dashboard");
        }
        else{
            props.history.push("/login");
        }
    }

    return (
        <div className="container">
            <div className="row justify-content-md-center">
                <div className="card">
                    <div className="card-header">Login</div>
                    <div className="card-body">
                        <form>
                            <div className="form-group">
                                <label for="exampleInputEmail1">Email address</label>
                                <input type="email" className="form-control" aria-describedby="emailHelp" placeholder="Enter email" autoFocus
                                    value={email} onChange={e => setEmail(e.target.value)} />
                            </div>
                            <div className="form-group">
                                <label for="exampleInputPassword1">Password</label>
                                <input type="password" className="form-control" placeholder="Password" value={password}
                                    onChange={e => setPassword(e.target.value)} />
                            </div>
                            <Button block bsSize="large" disabled={!validateForm()} onClick={handleSubmit} type="submit">Login</Button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    )
}