import React from 'react'
import Wrapper from '../../components/wrapper'
import Headingbrd from '../../components/headingbrd'
import WLTT from '../../components/weddLoan/wltt'
import WLFQ from '../../components/weddLoan/wlfq'
import InnerWarning from '../../components/warnings/innerwarning'
import Lists from '../../components/lists'
import OurCompari from '../../components/loans/ourCompari'
import BannerImages from '../../components/bannerImages'
import Helmet from 'react-helmet'
const images = require.context('../../assets/images')

export default () => {
    const allList = {
        mainlists: [
          {lidata:'You can borrow months in advance of the big day'},
          {lidata:'You can add the honeymoon cost'},
          {lidata:'Loans from £1000-£35000'},
          {lidata:'Borrow for 12-84 months'},
          {lidata:'Quick Approval. Fast payout'},
          {lidata:'The rate you see is the rate you get'},
        ],
        mainImage:[
            {cls:'PicMainCircle Place', mysrc:'./main-circle.png', alt:'Wedding Loans'},
            {cls:'PicInnerCircle Place', mysrc:'./inner-circle.png', alt:'Wedding Loans'},
            {cls:'Pic6 zoomIn6', mysrc:'./dress.png', alt:'Wedding Loans'},
            {cls:'Pic5 zoomIn5', mysrc:'./diemend.png', alt:'Wedding Loans'},
            {cls:'Pic4 zoomIn4', mysrc:'./charch.png', alt:'Wedding Loans'},
            {cls:'Pic3 zoomIn3', mysrc:'./rings.png', alt:'Wedding Loans'},
            {cls:'Pic2 zoomIn2', mysrc:'./champian.png', alt:'Wedding Loans'},
            {cls:'Pic1 zoomIn1', mysrc:'./weddingLan-main.png', alt:'Wedding Loans'},
            {cls:'PicBase zoomIn', mysrc:'./head-img-temp.png', alt:'Wedding Loans'}
       ]
     }
   
     const renderallList = (items) => {
       return items.map((item, i) => <Lists key={i} text={item.lidata} />)
     }
     const rendermainImage = (items) => {
        return items.map((item, i) => <BannerImages key={i} cls={item.cls} mysrc={images(item.mysrc)} alt={item.alt} />)
    }
    return (
        <>
        <Helmet>
            <title>Compare Wedding Loans at LoanTube | UK</title>
            <meta name="description" content="Wedding loans are taken to cover the cost of wedding. If you are planning to tie the knot and in need of funds, apply on LoanTube and Compare Loans for Wedding." />
        </Helmet>
    <section className="loansProducts">
        <div className="container">
            <div className="row">                  
                    <div className="col-lg-6">
                            <div className="headingAll"><h1>Wedding Loans</h1></div>
                         <ul>{renderallList(allList.mainlists)}</ul>
                         <div className="mainHomePage loanApplyInner">
                            <a href="https://app.loantube.com/Customer/LoanApplication?utm_source=referral&amp;utm_campaign=loanapplication&amp;utm_website=www.loantube.com&amp;utm_webpage=/" className="btn btn-danger">Find your loans</a>
                        </div>
                    </div>
                    <div className="col-lg-6">
                        <div className="lanImg">
                             {rendermainImage(allList.mainImage)}
                        </div> 
                    </div>
            </div>
        </div>
    </section>
    <Wrapper cls="homeWarningSec mt-n4"><OurCompari /></Wrapper>
    <Wrapper cls="threeThingsSec"><Headingbrd>3 Things to Know About Our Wedding Loans</Headingbrd><WLTT/></Wrapper>
    <Wrapper cls="faqLoanInnerSec faqBg"><Headingbrd>FAQs on Improvement Loans</Headingbrd><WLFQ/></Wrapper>
    <Wrapper cls="homeWarningSec"><InnerWarning /></Wrapper>
        </>
    )
}