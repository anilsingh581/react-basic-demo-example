import React from 'react'
import Wrapper from '../../components/wrapper'
import Headingbrd from '../../components/headingbrd'
import HILTT from '../../components/homeImproveL/hiltt'
import HILFQ from '../../components/homeImproveL/hilfq'
import InnerWarning from '../../components/warnings/innerwarning'
import Lists from '../../components/lists'
import OurCompari from '../../components/loans/ourCompari'
import BannerImages from '../../components/bannerImages'
import Helmet from 'react-helmet'
const images = require.context('../../assets/images')

export default () => {
    const allList = {
        mainlists: [
          {lidata:'Available to Home Owners & Tenants both'},
          {lidata:'Loans from £1000-£35000'},
          {lidata:'Borrow for 12-84 months'},
          {lidata:'Quick Approval. Fast payout'},
          {lidata:'Compare multiple lenders'},
          {lidata:'The rate you see is the rate you get'},
        ],
        mainImage:[
            {cls:'PicMainCircle Place', mysrc:'./main-circle.png', alt:'Home Improvement Loans'},
            {cls:'PicInnerCircle Place', mysrc:'./inner-circle.png', alt:'Home Improvement Loans'},
            {cls:'Pic6 zoomIn6', mysrc:'./rinch.png', alt:'Home Improvement Loans'},
            {cls:'Pic5 zoomIn5', mysrc:'./dril.png', alt:'Home Improvement Loans'},
            {cls:'Pic4 zoomIn4', mysrc:'./brush.png', alt:'Home Improvement Loans'},
            {cls:'Pic3 zoomIn3', mysrc:'./cutter.png', alt:'Home Improvement Loans'},
            {cls:'Pic2 zoomIn2', mysrc:'./hammer.png', alt:'Home Improvement Loans'},
            {cls:'Pic1 zoomIn1', mysrc:'./homeLan-main.png', alt:'Home Improvement Loans'},
            {cls:'PicBase zoomIn', mysrc:'./head-img-temp.png', alt:'Home Improvement Loans'}
       ]
     }
   
     const renderallList = (items) => {
       return items.map((item, i) => <Lists key={i} text={item.lidata} />)
     }
     const rendermainImage = (items) => {
        return items.map((item, i) => <BannerImages key={i} cls={item.cls} mysrc={images(item.mysrc)} alt={item.alt} />)
    }
    return (
        <>
        <Helmet>
            <title>Home Improvement Loans UK - Compare| LoanTube</title>
            <meta name="description" content="Compare different Home Improvement Loans on LoanTube and select the most suitable one. Unsecured home improvement loans are available without any collateral." />
        </Helmet>
            <section className="loansProducts">
        <div className="container">
            <div className="row">                  
                    <div className="col-lg-6">
                            <div className="headingAll"><h1>Home Improvement Loans</h1></div>
                         <ul>{renderallList(allList.mainlists)}</ul>
                         <div className="mainHomePage loanApplyInner">
                            <a href="https://app.loantube.com/Customer/LoanApplication?utm_source=referral&amp;utm_campaign=loanapplication&amp;utm_website=www.loantube.com&amp;utm_webpage=/" className="btn btn-danger">Find your loans</a>
                        </div>
                    </div>
                    <div className="col-lg-6">
                    <div className="lanImg">
                        {rendermainImage(allList.mainImage)}
                    </div>
                    </div>
            </div>
        </div>
    </section>
    <Wrapper cls="homeWarningSec mt-n4"><OurCompari /></Wrapper>
    <Wrapper cls="threeThingsSec"><Headingbrd>3 Things to Know About Our Home Improvement Loans</Headingbrd><HILTT/></Wrapper>
    <Wrapper cls="faqLoanInnerSec faqBg"><Headingbrd>FAQs on Improvement Loans</Headingbrd><HILFQ/></Wrapper>
        <Wrapper cls="homeWarningSec"><InnerWarning /></Wrapper>
        </>
    )
}