import React from 'react'
import PrivacyPolicyLeft from '../../components/privacyPolicyC/privacyPolicyLeft'
import PrivacyPolicyRight from '../../components/privacyPolicyC/privacyPolicyRight'
import Headingbrd from '../../components/headingbrd'
import WrapperRow from '../../components/wrapperRow'
import Helmet from 'react-helmet'

export default () => {
    return (
        <>
        <Helmet>
            <title>Privacy Policy - LoanTube | Compare Loans</title>
            <meta name="description" content="This section describes how we collect, use and manage personal data and ways in which you can manage and update your data." />
            <body data-spy="scroll" data-target="#fixedLeftSidebar"></body>
        </Helmet>
            <Headingbrd><h1>Privacy Policy</h1></Headingbrd>
            <WrapperRow cls="cookiesMainSec">
                <div className="col-lg-3">
                    <PrivacyPolicyLeft />
                </div>
                <div className="col-lg-9">
                    <PrivacyPolicyRight />
                </div>
            </WrapperRow>
        </>
    )
}