import React from 'react'
import Wrapper from '../../components/wrapper'
import Headingbrd from '../../components/headingbrd'
import SecuredLTT from '../../components/securedLC/securedLtt'
import SecuredLFQ from '../../components/securedLC/securedLfq'
import InnerWarningNew from '../../components/warnings/innerWarningNew'
import Lists from '../../components/lists'
import OurCompari from '../../components/loans/ourCompari'
import BannerImages from '../../components/bannerImages'
import Helmet from 'react-helmet'
const images = require.context('../../assets/images')

export default () => {
    const allList = {
        mainlists: [
          {lidata:'Loans from £1000-£35000'},
          {lidata:'Borrow for 1 year to 7 years'},
          {lidata:'Relatively easy to apply'},
          {lidata:'The rate you see is the rate you get'},
          {lidata:'Compare loans from multiple lenders in one quick search'},
        ],
        mainImage:[
            {cls:'PicMainCircle Place', mysrc:'./main-circle.png', alt:'Secured Loans'},
            {cls:'PicInnerCircle Place', mysrc:'./inner-circle.png', alt:'Secured Loans'},
            {cls:'Pic7 zoomIn7', mysrc:'./groth.png', alt:'Secured Loans'},
            {cls:'Pic6 zoomIn6', mysrc:'./note.png', alt:'Secured Loans'},
            {cls:'Pic5 zoomIn5', mysrc:'./HomeCont.png', alt:'Secured Loans'},
            {cls:'Pic4 zoomIn4', mysrc:'./homeEye.png', alt:'Secured Loans'},
            {cls:'Pic3 zoomIn3', mysrc:'./multiHome.png', alt:'Secured Loans'},
            {cls:'Pic2 zoomIn2', mysrc:'./pig.png', alt:'Secured Loans'},
            {cls:'Pic1 zoomIn1', mysrc:'./securedLanHead.png', alt:'Secured Loans'},
            {cls:'PicBase zoomIn', mysrc:'./head-img-temp.png', alt:'Secured Loans'}
       ]
     }
     const renderallList = (items) => {
       return items.map((item, i) => <Lists key={i} text={item.lidata} />)
     }
     const rendermainImage = (items) => {
        return items.map((item, i) => <BannerImages key={i} cls={item.cls} mysrc={images(item.mysrc)} alt={item.alt} />)
    }
    return (
        <>
        <Helmet>
            <title>Secured Loans - LoanTube | Compare Loans</title>
            <meta name="description" content="Secured Loans - Description" />
        </Helmet>
        <section className="loansProducts">
        <div className="container">
            <div className="row">                  
                    <div className="col-lg-6">
                            <div className="headingAll"><h1>Secured Loans</h1></div>
                         <ul>{renderallList(allList.mainlists)}</ul>
                         <div className="mainHomePage loanApplyInner">
                            <a href="https://app.loantube.com/Customer/LoanApplication?utm_source=referral&amp;utm_campaign=loanapplication&amp;utm_website=www.loantube.com&amp;utm_webpage=/" className="btn btn-danger">Find your loans</a>
                        </div>
                    </div>
                    <div className="col-lg-6">
                         <div className="lanImg">
                            {rendermainImage(allList.mainImage)}
                        </div>
                    </div>
            </div>
        </div>
    </section>
    <Wrapper cls="homeWarningSec mt-n4"><OurCompari /></Wrapper>
    <Wrapper cls="threeThingsSec"><Headingbrd>3 Things to Know About Our Secured Loans</Headingbrd><SecuredLTT/></Wrapper>
    <Wrapper cls="faqLoanInnerSec faqBg"><Headingbrd>FAQs on Secured Loans</Headingbrd><SecuredLFQ/></Wrapper>
    <Wrapper cls="homeWarningSec"><InnerWarningNew /></Wrapper>
        </>
    )
}