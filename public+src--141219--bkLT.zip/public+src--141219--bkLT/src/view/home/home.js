import React from 'react'
import Homeloans from '../../components/homeC/homeLoans'
import Homewarnings from '../../components/warnings/homewarnings'
import Wrapper from '../../components/wrapper'
import BannerImages from '../../components/bannerImages'
import HeadingBrd from '../../components/headingbrd'
import Helmet from 'react-helmet'
import Typewriter from 'typewriter-effect'
const images = require.context('../../assets/images')

export default () => {
    const loanDetails = {
        loanlist:[
            {loanLink:'/unsecured-personal-loans', loanClass:'presonalLoan', loansName:'Personal Loan'},
             {loanLink:'/secured', loanClass:'secured', loansName:'Secured'},
             {loanLink:'/holiday-loans', loanClass:'holiday', loansName:'Holiday'},
             {loanLink:'/home-improvement-loans', loanClass:'homeImprovement', loansName:'Home Improvement'},
             {loanLink:'/payday-loans', loanClass:'payday', loansName:'Payday'},
             {loanLink:'/wedding-loans', loanClass:'wedding', loansName:'Wedding'}
        ],
        cloudBirds:[
            {cls:'cloud1', mysrc:'./cloud1.png', alt:'Cloud'},
            {cls:'cloud2', mysrc:'./cloud2.png', alt:'Cloud'},
            {cls:'cloud3', mysrc:'./cloud3.png', alt:'Cloud'},
            {cls:'cloud4', mysrc:'./cloud1.png', alt:'Cloud'},
            {cls:'cloud5', mysrc:'./cloud3.png', alt:'Cloud'},
            {cls:'birds', mysrc:'./birds.png', alt:'Bird'},
            {cls:'birds birds1', mysrc:'./birds.png', alt:'Bird'},
            {cls:'birds birds2', mysrc:'./birds.png', alt:'Bird'},
            {cls:'birds birds3', mysrc:'./birds.png', alt:'Bird'},
            {cls:'birds birds1 birds4', mysrc:'./birds.png', alt:'Bird'}
        ],
        mainBannerss:[
            {cls:'mainBanner', mysrc:'./mainBanner.png', alt:'London'},
            {cls:'londonEyeBase', mysrc:'./londonEyeBase.png', alt:'London Base'},
            {cls:'londonEye', mysrc:'./londonEye.png', alt:'London Eye'},
            {cls:'watch', mysrc:'./watch.png', alt:'Watch'}
        ]
    }
    
    const renderloans = () => {
       return loanDetails.loanlist.map((item, i) => <Homeloans key={i} href={item.loanLink} clsName={item.loanClass} loanName={item.loansName} />)
    }

    const rendercloudBirds = (items) => {
        return items.map((item,i) => <BannerImages key={i} cls={item.cls} mysrc={images(item.mysrc)} alt={item.alt} />)
    }

    return(
        <> 
        <Helmet>
            <title>Compare Personal Loans with real interest rates | LoanTube</title>
            <meta name="description" content="Compare personal loans on LoanTube with real interest rates from multiple lenders. The rate you see for loans on LoanTube is the rate you get in reality." />
        </Helmet>
        <Wrapper cls="mainBannerBg">
            <h1 className="bgHeading">Compare  <label className="typewrite"><span><Typewriter
  options={{
    strings: ['personal', 'holiday', 'home improvement', 'unsecured', 'wedding' ],
    autoStart: true,
    loop: true,
    cursor: ' ',
  }}
/></span></label> loans with real interest rates!</h1>
                    <div className="mainHomePage">
                        <a href="https://app.loantube.com/Customer/LoanApplication?utm_source=referral&utm_campaign=loanapplication&utm_website=www.loantube.com&utm_webpage=/"
                            className="btn btn-danger">Find your loans</a>
                    </div>
                    <div className="mainBannerSec">{rendercloudBirds(loanDetails.mainBannerss)}</div>
                    {rendercloudBirds(loanDetails.cloudBirds)}
        </Wrapper>
    <Wrapper cls="homeWarningSec"><h4>Our comparison service is free for you to use. Yes it’s free!!</h4>
                    <p>Are you thinking how we make money then? – We receive a fee or commission from lenders whenever you obtain a loan through LoanTube.</p></Wrapper>
                    <Wrapper cls="loanSec">
                        <HeadingBrd>Loans | LoanTube</HeadingBrd>
                    <p className="loansPara">Most of us need a loan at some point – and cheap loans are the most attractive.
                        LoanTube is a platform where you can choose your lender as per your needs.</p>
                    <ul className="loanBoxes">{renderloans()}</ul>
                    </Wrapper>
                    <Wrapper cls="representaSec">
                    <HeadingBrd>Representative APR Example</HeadingBrd>
                    <p>The rate you are offered will depend on your individual circumstances.<br/><br/>
                        All loans are subject to status. The interest rate offered will vary depending on our assessment of your financial circumstances and your chosen loan amount.<br/><br/>
                        Representative APR Example: for comparison purposes 12.9% APR Representative Fixed based on a loan of £10,000 repayable over 60 Months. Monthly payment of £223.43 total amount repayable £13,405.80.</p>
                    </Wrapper>
                    <Wrapper cls="homeWarningSec pt-0"><Homewarnings /></Wrapper>
                    <Wrapper cls="resistationSec">
                    <HeadingBrd>LoanTube is a trading name of Tiger Lion Financial Limited</HeadingBrd>
                    <div className="registBox">
                        <h4>Tiger Lion Financial Limited:</h4>
                        <p>Registered in England & Wales : Company Number: <span>10189367</span></p>
                        <h5>Registered Office Address:</h5>
                        <p>71-75 Shelton Street, Covent Garden, London, WC2H 9JQ<br/><br/>
                            Information Commissioners Office Registration Number: <span>ZA185613</span><br/><br/>
                            Authorised and regulated by the Financial Conduct Authority(FCA)<br/><br/>
                            FCA Firm Reference Number: <span><a href="https://register.fca.org.uk/ShPo_FirmDetailsPage?id=001b000003RFLpvAAH" target="_blank" rel="noopener noreferrer">753151</a></span></p>
                    </div></Wrapper>
        </>
    )
}