import React from 'react'
import {Switch, Route, Redirect} from 'react-router-dom'

import Home from './view/home/home'
import Pagenotfound from './view/page-not-found/page-not-found'
import Login from './view/login/login'
import Aboutus from './view/about-us/about-us'
import Unsecuredpersonalloans from './view/unsecured-personal-loans/unsecured-personal-loans'
import Homeimprovementloans from './view/home-improvement-loans/home-improvement-loans'
import Weddingloans from './view/wedding-loans/wedding-loans'
import Holidayloans from './view/holiday-loans/holiday-loans'
import Paydayloans from './view/payday-loans/payday-loans'
import Securedloans from './view/secured-loans/secured-loans'
import DebtConsolidationLoans from './view/debt-consolidation-loans/debt-consolidation-loans'
import GuarantorLoans from './view/guarantor-loans/guarantor-loans'
import LongTermLoans from './view/long-term-loans/long-term-loans'
import Ourpartners from './view/our-partners/our-partners'
import Contactus from './view/contact-us/contact-us'
import Faqs from './view/faqs/faqs'
import CookiesPolicy from './view/cookies-policy/cookies-policy'
import PrivacyPolicy from './view/privacy-policy/privacy-policy'
import TermsAndConditions from './view/terms-and-conditions/terms-and-conditions'
import ComplaintsPolicy from './view/complaints-policy/complaints-policy'
import TreatingCustomersFairly from './view/treating-customers-fairly/treating-customers-fairly'
import Dashboard from './view/guides/dashboard/dashboard'
import AddBlog from './view/guides/addblog/addblog'
import EditBlog from './view/guides/editblog/editblog'
import GuidesG from './view/guides/guides'
import GuidesDetailsG from './view/guides/guidesdetails'
import FinancialNewsG from './view/guides/financial-news/financial-news'
import UnsecuredPersonalLoansG from './view/guides/unsecured-personal-loans/unsecured-personal-loans'
import HolidayLoansG from './view/guides/holiday-loans/holiday-loans'
import HomeImprovementLoansG from './view/guides/home-improvement-loans/home-improvement-loans'
import PaydayLoansG from './view/guides/payday-loans/payday-loans'
import PoorCreditLoansG from './view/guides/poor-credit-loans/poor-credit-loans'
import WeddingLoansG from './view/guides/wedding-loans/wedding-loans'
import OthersG from './view/guides/others/others'


export default () => {
    return (
        <Switch>
            <Route path="/" exact component={Home} />
            <Route path="/page-not-found" component={Pagenotfound} />
            <Route path="/login" component={Login} />
            <Route path="/home" component={Home} />
            <Route path="/about-us" component={Aboutus} />
            <Route path="/unsecured-personal-loans" component={Unsecuredpersonalloans} /> 
            <Route path="/home-improvement-loans" component={Homeimprovementloans} />
            <Route path="/wedding-loans" component={Weddingloans} />
            <Route path="/holiday-loans" component={Holidayloans} />
            <Route path="/payday-loans" component={Paydayloans} />
            <Route path="/secured-loans" component={Securedloans} />
            <Route path="/debt-consolidation-loans" component={DebtConsolidationLoans} />
            <Route path="/guarantor-loans" component={GuarantorLoans} />
            <Route path="/long-term-loans" component={LongTermLoans} />
            <Route path="/our-partners" component={Ourpartners} />
            <Route path="/contact-us" component={Contactus} />
            <Route path="/faqs" component={Faqs} />
            <Route path="/cookies-policy" component={CookiesPolicy} />
            <Route path="/privacy-policy" component={PrivacyPolicy} />
            <Route path="/terms-and-conditions" component={TermsAndConditions} />
            <Route path="/complaints-policy" component={ComplaintsPolicy} />
            <Route path="/treating-customers-fairly" component={TreatingCustomersFairly} />
            <Route path="/guides/dashboard" component={Dashboard} />
            <Route path='/guides/addblog' component={AddBlog} />
            <Route path='/guides/editblog' component={EditBlog} />
            <Route path='/guides/guides' component={GuidesG} />
            <Route path='/guides/guidesdetails' component={GuidesDetailsG} />
            <Route path='/guides/financial-news' component={FinancialNewsG} />
            <Route path='/guides/unsecured-personal-loans' component={UnsecuredPersonalLoansG} />
            <Route path='/guides/holiday-loans' component={HolidayLoansG} />
            <Route path='/guides/home-improvement-loans' component={HomeImprovementLoansG} />
            <Route path='/guides/payday-loans' component={PaydayLoansG} />
            <Route path='/guides/poor-credit-loans' component={PoorCreditLoansG} />
            <Route path='/guides/wedding-loans' component={WeddingLoansG} />
            <Route path='/guides/others' component={OthersG} />
            <Route path='/guides/others' component={OthersG} />
            
            <Redirect from="/*" to="/page-not-found" />
        </Switch>
    )
}