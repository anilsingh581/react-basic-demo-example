import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css'
import 'jquery/dist/jquery.min.js'
import 'bootstrap/dist/js/bootstrap.min.js'
import '../src/assets/js/custom.js'
import 'react-table/react-table.css'
import './App.css';
import Approuter from './approuter'
import Header from '../src/containers/header/header'
import Footer from '../src/containers/footer/footer'

function App() {
  
  return (
    <>
      <Header />
      <Approuter/>
      <Footer/>
    </>
  );
}

export default App;
