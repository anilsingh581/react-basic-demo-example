import $ from 'jquery';

$(function () {
    $('.navClick').click(function () {
        $('.menuContainer').toggleClass('showMenu');
        $('.menuWrap').toggleClass('menuWrapper');
        $(this).toggleClass('cross');
    });
    $('.menuWrap').click(function () {
        $(this).removeClass('menuWrapper');
        $('.menuContainer').removeClass('showMenu');
        $('.navClick').removeClass('cross');
    });

    $(".backtotop").click(function () {
        $("html,body").animate({ scrollTop: 0 }, "slow");
    });
    $(window).scroll(function () {
        if ($(document).scrollTop() > 500) {
            $(".backtotop").fadeIn();
        }
        else { $(".backtotop").fadeOut(); }
    });

    // for google review link replace
    var isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    if (isMobile) {
        //alert("Mobile");
        $('#googleReview').find('a').attr('href', 'http://bit.ly/reviewmob');
        $('#amount').attr('type', 'number');
        $('#term').attr('type', 'number');
        //document.getElementById("amount")[0].setAttribute("type","number");
    } else {
        $('#googleReview').find('a').attr('href', 'http://bit.ly/reviewdesk');
        $('#amount').attr('type', 'text');
        $('#term').attr('type', 'text');
    }




    $(window).scroll(function () {
        if ($(document).scrollTop() > 10) {
            // for the smooth input text
            $('input, textarea').each(function () {
                var valls = $(this).val();
                if (valls !== "") {
                    $(this).addClass("hasValueFrm");
                } else {
                    $(this).removeClass("hasValueFrm");
                }
            });

            $(".placeholderfrm").change(function () {
                if ($(this).val() !== "") {
                    $(this).addClass("hasValueFrm");
                }
                else {
                    $(this).removeClass("hasValueFrm");
                }
            });
        }

    });


    // for the cookies section added class

    var docHeight = $(document).height();
    var fHeight = $('footer').height();
    var selfContainerHeight = $('#fixedLeftSidebar').height();
    var fbtm = docHeight - fHeight;
    var finalbtm = fbtm - selfContainerHeight;


    var windWid = $(window).width();
    if (windWid > 992) {
        $(window).scroll(function () {
            if ($(document).scrollTop() > 260) {
                $('#fixedLeftSidebar').addClass('fixedLeftSidTp').css('top', '0');

                if ($(document).scrollTop() > finalbtm) {
                    $('#fixedLeftSidebar').removeAttr('style').css('bottom', fHeight);
                }

            } else {
                $('#fixedLeftSidebar').removeAttr('style').removeClass('fixedLeftSidTp');
            }
        });
    } else {
        $('#fixedLeftSidebar').removeAttr('style').removeClass('fixedLeftSidTp');
    }

});


