
export var apiBaseUrl = 'http://localhost:3005/'
export var baseUrl = 'http://localhost:3000/'

export function categoryName(cateName) {
    if (cateName === '1') {
        return 'Financial News';
    } else if (cateName === '2') {
        return 'Unsecured Personal Loans';
    } else if (cateName === '3') {
        return 'Holiday Loans';
    } else if (cateName === '4') {
        return 'Home Improvement Loans';
    } else if (cateName === '5') {
        return 'Payday Loans';
    } else if (cateName === '6') {
        return 'Poor Credit Loans';
    } else if (cateName === '7') {
        return 'Wedding Loans';
    } else if (cateName === '8') {
        return 'Others';
    } else {
        return 'Others';
    }
}

export function categoryUrl(cateUrl) {
    if (cateUrl === '1') {
        return 'financial-news?/financial-news';
    } else if (cateUrl === '2') {
        return 'unsecured-personal-loans?/unsecured-personal-loans';
    } else if (cateUrl === '3') {
        return 'holiday-loans?/holiday-loans';
    } else if (cateUrl === '4') {
        return 'home-improvement-loans?/home-improvement-loans';
    } else if (cateUrl === '5') {
        return 'payday-loans?/payday-loans';
    } else if (cateUrl === '6') {
        return 'poor-credit-loans?/poor-credit-loans';
    } else if (cateUrl === '7') {
        return 'wedding-loans?/wedding-loans';
    } else if (cateUrl === '8') {
        return 'others?/others';
    } else {
        return 'others?/others';
    }
}

var theMonths = ["January", "February", "March", "April", "May",
    "June", "July", "August", "September", "October", "November", "December"];

export function dateFormat(date) {
    var today = new Date(date);
    var dd = today.getDate();
    var mm = today.getMonth(); //January is 0!

    var yyyy = today.getFullYear();

    mm = theMonths[mm];

    return mm + ' ' + dd + ' ' + yyyy;

}

var categories =[];

export function getCategories() {

    categories =[{id :1, name:'Financial News'},
        {id :2, name:'Unsecured Personal Loans'},
        {id :3, name:'Holiday Loans'},
        {id :4, name:'Home Improvement Loans'},
        {id :5, name:'Payday Loans'},
        {id :6, name:'Poor Credit Loans'},
        {id :7, name:'Wedding Loans'},
        {id :8, name:'Others'}];

        return categories;
}

export var editorContent ="Hello, editor!";

export function getEditorContent(content){
    editorContent = content;    
}

