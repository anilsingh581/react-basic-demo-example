import React from 'react'
const images = require.context('../../assets/images')

export default () => 
        <>
            <div className="brdCenterText">Did you know that <a href="#">payday loans</a> are the most heavily-regulated area of lending in the UK? All that protection is there to make sure you get a fair deal and that you don’t get surprised with fees and charges you weren’t expecting. Here are LoanTube’s 3 things you need to know about payday loans.</div>
                            <div className="threeText"><div className="threeimg"><img src={images('./Payday31.png')} alt="Home improvement Loans" /></div>
                            <div>Although payday loans are most often associated with borrowers who have had financial difficulty in the past, people with all types of credit histories are welcome to apply for a payday loan online with LoanTube. As long as you can afford it, there are lenders out there who can lend you*</div></div>
                            <div className="threeText"><div className="threeimg"><img src={images('./Payday32.png')} alt="Home improvement Loans" /></div><div>There are legal limits to how much interest can be charged on a payday loan. In addition, payday lenders can’t charge default fees of more than £15 or increase the rate of interest you pay on a payday loan if you miss the repayment date.</div></div>
                            <div className="threeText"><div className="threeimg"><img src={images('./Payday33.png')} alt="Home improvement Loans" /></div><div>Many people think that taking out a payday loan will look bad on their credit file. Whilst every company has their own way of coming to a decision, leading credit report agency Experian say on their website that, “Your score won’t be damaged by a payday loan, as long as you repay it in full and on time.”</div></div>
                        <div className="brdCenterText">There are some important things to think about before you take out a Payday loan so please do bear these in mind. Is there no other way you can get the money? Payday loans should only be used in an emergency – is this really an emergency? Could you wait until your next payday and sort the problem out then?</div>
                <br/>
                        <div className="brdCenterText"><strong> loans may not be suitable for you if you think you will struggle to repay the loan.</strong> If you think it’s going to be too difficult, please don’t apply for one because it will make the chances of you being able to take out loans, <a href="#"> credit cards</a>, and mortgages in the future much harder.</div>    
                <br/>      
                        <div className="brdCenterText">A short-term instalment loan may be better as the amount you have to pay back each month is smaller, however, the amount you’ll end up paying in interest will be higher.</div>
        </>
    