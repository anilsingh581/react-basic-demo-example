import React from 'react'

export default () => 
<div className="accordion" id="accordionBefore">
<div className="card">
    <div id="headingOne">
    <h2 className="mb-0" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
        How do I know that the lenders you’ll put me in touch with are reputable? How do I know that LoanTube is reputable?
    </h2>
    </div>
    <div id="collapseOne" className="collapse show" aria-labelledby="headingOne" data-parent="#accordionBefore">
    <div className="card-body">
        <div className="MyAns">
        <p>LoanTube is a customer-focused credit broker, licensed by the Financial Conduct Authority. All of our lenders are reputable, customer-oriented, and&nbsp; licensed by the Financial Conduct Authority. <strong>Why is that important and what difference does it make to you?</strong></p>
        <p>Payday loans have always had a very bad reputation. The government, the regulators, charities, and many people in the press thought that the interest rates charged on Payday Loans were too high and that there wasn’t enough help. In 2015, the regulator, the <a href="https://www.loantube.com/guides/know-your-rights-while-borrowing-money/">Financial Conduct Authority</a>, laid down, new rules on companies that offer payday loans under the High-Cost Short Term Loans guidelines.</p>
        <p><strong> five rules are </strong></p>
        <ul>
            <li>only an FCA regulated lender can legally offer payday loans to members of the public</li>
            <li>no borrower will be charged more than 80p a day per £100 borrowed (that’s a daily interest rate of 0.8%)</li>
            <li>if a customer fails a payment, a lender can try to collect the payment from customer’s bank account only once without asking the borrower for permission, and that they can not charge a default fee of more than £15</li>
            <li>the total amount you pay back in interest and in fees can’t be more than 100% of the loan you took out.</li>
            <li>if you can’t meet your repayments on the loan and ask for help, your lender must point you in the right direction or to someone who can represent and advise you.</li>
        </ul>
    </div>
    </div>
    </div>
</div>
<div className="card">
    <div id="headingTwo">
    <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
            Do I need to be of a minimum age to apply for a payday loan with LoanTube?
    </h2>
    </div>
    <div id="collapseTwo" className="collapse" aria-labelledby="headingTwo" data-parent="#accordionBefore">
    <div className="card-body">
            Yes. Our lenders lend only to customers who are aged 18 or above.
    </div>
    </div>
</div>
<div className="card">
    <div id="headingThree">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
            Do I need to be employed?
        </h2>
    </div>
    <div id="collapseThree" className="collapse" aria-labelledby="headingThree" data-parent="#accordionBefore">
        <div className="card-body">
            Yes, it is preferred by the lenders. If you are unemployed, you may not be able to pass the lender’s affordability assessments. The exception is if you have other good sources of incomes like rental income and you can convince lenders that you can afford to pay the loan with those other incomes.
        </div>
    </div>
    </div>
<div className="card">
    <div id="headingFour">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
            Can you work with someone who is bankrupt, someone who is in an Individual Voluntary Arrangement (IVA), or someone who is on a debt management arrangement?
        </h2>
    </div>
    <div id="collapseFour" className="collapse" aria-labelledby="headingFour" data-parent="#accordionBefore">
        <div className="card-body">
            People on IVA, Debt Management Plan and on Bankruptcy are considered as negative customers by lenders. It is a sign that you can’t really manage your finances. Due to this, we are very sure we won’t be able to find you a loan if you are on IVA or Debt Management Plan or have filed a bankruptcy in past.
        </div>
    </div>
    </div>
    
<div className="card">
    <div id="headingFive">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
            How much information about my life and my finances will you need to know?
        </h2>
    </div>
    <div id="collapseFive" className="collapse" aria-labelledby="headingFive" data-parent="#accordionBefore">
        <div className="card-body">
            It’ll take you a couple of minutes to give us the details we need. What we’ll be asking for is for information on your current employment status, your earnings, your monthly expenditure, where you’re living and what is your residential status.
        </div>
    </div>
    </div>
    
<div className="card">
    <div id="headingSix">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
            Is this a guarantor loan?
        </h2>
    </div>
    <div id="collapseSix" className="collapse" aria-labelledby="headingSix" data-parent="#accordionBefore">
        <div className="card-body">
            No.
        </div>
    </div>
    </div>
    <div className="card">
        <div id="headingSeven">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                How long will I have to wait for an answer?
        </h2>
        </div>
        <div id="collapseSeven" className="collapse" aria-labelledby="headingSeven" data-parent="#accordionBefore">
        <div className="card-body">
                It depends. If we have all the information we and our lenders need, a “yes or a no” answer from lenders who are willing to lend you and the quotes/APRs they want to offer you will be displayed on your screen on a real-time basis.
        </div>
        </div>
    </div>
    <div className="card">
        <div id="headingEight">
            <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
                Are you licensed to lend me money?                                            
            </h2>
        </div>
        <div id="collapseEight" className="collapse" aria-labelledby="headingEight" data-parent="#accordionBefore">
            <div className="card-body">
                LoanTube doesn’t lend you the money – we’re not a lender, we’re a credit broker. We connect with you the lenders (all licensed by the Financial Conduct Authority) who will consider your loan application. Applying through LoanTube means you don’t have to submit dozens of applications individually to each lender to get your loan decision.
            </div>
        </div>
        </div>
        <div className="card">
            <div id="headingNine">
            <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
                    How do you know which companies will lend me money and which ones won’t?
            </h2>
            </div>
            <div id="collapseNine" className="collapse" aria-labelledby="headingNine" data-parent="#accordionBefore">
            <div className="card-body">
                    When we become partners with a lender, one of the first things they do is to send us a list of the types of borrowers they would like to work with. You might be just the type of borrower one company lender is looking for but another might not consider you. Our job is to pair you with the right lenders based on the information you give us.
            </div>
            </div>
        </div>
        <div className="card">
            <div id="headingTen">
                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
                    Will I pay more by going through LoanTube?
                </h2>
            </div>
            <div id="collapseTen" className="collapse" aria-labelledby="headingTen" data-parent="#accordionBefore">
                <div className="card-body">
                    Definitely not. You don’t pay us anything to make an application for a loan. If you’re approved, you’ll pay the lender exactly what you’d have paid them had you approached them directly.
                </div>
            </div>
            </div>
            <div className="card">
            <div id="headingEve">
                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseEve" aria-expanded="false" aria-controls="collapseEve">
                    How does LoanTube get paid?
                </h2>
            </div>
            <div id="collapseEve" className="collapse" aria-labelledby="headingEve" data-parent="#accordionBefore">
                <div className="card-body">
                    When we match a borrower up with a lender and the borrower decides to take out the loan, we get payment from the lender in the form of a commission – simple.
                </div>
            </div>
            </div>
            <div className="card">
            <div id="headingTwe">
                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwe" aria-expanded="false" aria-controls="collapseTwe">
                    Do you have to run a credit check?
                </h2>
            </div>
            <div id="collapseTwe" className="collapse" aria-labelledby="headingTwe" data-parent="#accordionBefore">
                <div className="card-body">
                    When we’re searching around for the best deal for you, we only carry out a soft credit check. Soft credit checks have no effect at all on your credit score. Doing so helps us in knowing the right lenders for you even before we pass your details to them. So we don’t pass your details to any lender we already know won’t be able to lend you. The Financial Conduct Authority also requires anyone who offers payday loans to run credit checks – it’s one of the ways a lender can check that you can afford the repayments. The more we know and the more our lenders know about you, the more personalised and more suitable loan deal can be found for you.
                </div>
            </div>
            </div>
            <div className="card">
                <div id="headingThr">
                    <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseThr" aria-expanded="false" aria-controls="collapseThr">
                        What if I get an offer and change my mind?
                    </h2>
                </div>
                <div id="collapseThr" className="collapse" aria-labelledby="headingThr" data-parent="#accordionBefore">
                    <div className="card-body">
                        That’s fine. You’re never under any obligation to accept an offer that you receive from LoanTube. Even if we say “yes” then you turn around and tell us “no”, there’s no charge for our service.
                    </div>
                </div>
                </div>
</div>
    