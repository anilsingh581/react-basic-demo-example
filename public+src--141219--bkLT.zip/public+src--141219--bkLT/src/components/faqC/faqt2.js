import React from 'react'

export default () => {
    return (
        <>
            <div className="accordion" id="accordionDuring">
                                <div className="card">
                                  <div id="headingOneD">
                                    <h2 className="mb-0"  data-toggle="collapse" data-target="#collapseOneD" aria-expanded="true" aria-controls="collapseOneD">
                                        How much do you charge for a loan?
                                    </h2>
                                  </div>
                                  <div id="collapseOneD" className="collapse show" aria-labelledby="headingOneD" data-parent="#accordionDuring">
                                    <div className="card-body">
                                        We do not charge any fees from our customers. Yes. You read it right. LoanTube doesn’t charge any fees whatsoever from our customers. We do not even deduct any amount from the loan advance. Hence, an individual applying for a loan with us will receive the whole amount of the loan applied for.
                                        However, we do receive a fee or commission from lenders whenever you obtain a loan through LoanTube.
                                    </div>
                                  </div>
                                </div>
                                <div className="card">
                                  <div id="headingTwoD">
                                    <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwoD" aria-expanded="false" aria-controls="collapseTwoD">
                                        How long do I have to wait after applying for the loan?
                                    </h2>
                                  </div>
                                  <div id="collapseTwoD" className="collapse" aria-labelledby="headingTwoD" data-parent="#accordionDuring">
                                    <div className="card-body">
                                        After applying, if we have all the information we and our lenders need, a “yes” or “no” answer from lenders who are willing to lend you with the APRs and quotes will be displayed on your screen on a real-time basis.
                                    </div>
                                  </div>
                                </div>
                                <div className="card">
                                  <div id="headingThreeD">
                                    <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseThreeD" aria-expanded="false" aria-controls="collapseThreeD">
                                        How will my loan get approved?
                                    </h2>
                                  </div>
                                  <div id="collapseThreeD" className="collapse" aria-labelledby="headingThreeD" data-parent="#accordionDuring">
                                    <div className="card-body">
                                        LoanTube offers a platform where lenders and borrowers meet to fulfil each other’s need. Lenders use various parameters to select and approve a loan. These parameters vary from lender to lender. Some may approve your loan instantly and some may take time for reconsideration as well and some may not consider your loan request at all.
                                    </div>
                                  </div>
                                </div>
                                <div className="card">
                                  <div id="headingFourD">
                                    <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFourD" aria-expanded="false" aria-controls="collapseFourD">
                                        I have finished filling out my loan application, what happens next?
                                    </h2>
                                  </div>
                                  <div id="collapseFourD" className="collapse" aria-labelledby="headingFourD" data-parent="#accordionDuring">
                                    <div className="card-body">
                                        Once you complete filling out the loan application form, we will try to search for lender that matches your needs and preferences. We will consider all the information provided by you to get you deals that are personalised to you. We show you all the matching lenders with their offered APRs on your screen in real-time. You have to accept the quotes from one of these lenders before we can handover you completely to that lender. Its between you and the lender then to complete the rest of the loan journey. We have no role in that. If lender requires any additional information, it will ask you. If you pass it’s additional checks, lender will transfer the loan amount to your bank account as per its usual loan disbursal policy.
Please read lender’s Terms & Conditions carefully before signing any loan agreement with them.
                                    </div>
                                  </div>
                                </div>
                                <div className="card">
                                  <div id="headingFiveD">
                                    <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFiveD" aria-expanded="false" aria-controls="collapseFiveD">
                                        Do you offer a fixed rate loan or variable rate loan?
                                    </h2>
                                  </div>
                                  <div id="collapseFiveD" className="collapse" aria-labelledby="headingFiveD" data-parent="#accordionDuring">
                                    <div className="card-body">
                                        LoanTube offers loan at fixed APR which doesn’t change after the loan has been approved by the lender. The rate of interest will never fluctuate in case you are applying through us. We really work hard to make things transparent.
                                    </div>
                                  </div>
                                </div>
                                <div className="card">
                                  <div id="headingSixD">
                                    <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseSixD" aria-expanded="false" aria-controls="collapseSixD">
                                        Where can I use this loan amount?
                                    </h2>
                                  </div>
                                  <div id="collapseSixD" className="collapse" aria-labelledby="headingSixD" data-parent="#accordionDuring">
                                    <div className="card-body">
                                        This is preferential. The loan amount can be used to simplify finances, making home improvements, traveling or for treating any other financial emergencies. We have a varied range of loan for the convenience of our customers.
                                    </div>
                                  </div>
                                </div>
                                <div className="card">
                                  <div id="headingSevenD">
                                    <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseSevenD" aria-expanded="false" aria-controls="collapseSevenD">
                                        Can I choose my loan term?
                                    </h2>
                                  </div>
                                  <div id="collapseSevenD" className="collapse" aria-labelledby="headingSevenD" data-parent="#accordionDuring">
                                    <div className="card-body">
                                        Yes. You have all the rights to choose your own loan term. Depending upon the affordability and preference, an individual is suggested to choose the repayment term to avoid any negative impact on the credit history.
                                    </div>
                                  </div>
                                </div>
                                <div className="card">
                                  <div id="headingEightD">
                                    <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseEightD" aria-expanded="false" aria-controls="collapseEightD">
                                        What are the chances that my loan application will be approved?
                                    </h2>
                                  </div>
                                  <div id="collapseEightD" className="collapse" aria-labelledby="headingEightD" data-parent="#accordionDuring">
                                    <div className="card-body">
                                        Your chances of approval depend upon many factors. Some of them are your past credit history, your current incomes & expenditures, your residential status, and lenders’ criteria. LoanTube does not impact your approval chances with any lender in any way. However as we deal with multiple lenders, we process your single loan application with all of our lenders. So your chances of getting approval for a loan through LoanTube are comparatively higher than applying with any lender directly.
Though we do suggest you to check your credit report before applying for any loan. We request you to recheck all the information that you fill in loan application form, in case you wish to check the eligibility for a loan through us.
                                    </div>
                                  </div>
                                </div>
                                <div className="card">
                                  <div id="headingNineD">
                                    <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseNineD" aria-expanded="false" aria-controls="collapseNineD">
                                        I want a guarantee that the loan will be approved. Will LoanTube offer me that?
                                    </h2>
                                  </div>
                                  <div id="collapseNineD" className="collapse" aria-labelledby="headingNineD" data-parent="#accordionDuring">
                                    <div className="card-body">
                                        No, we don’t provide guarantee of your loan approval. At the end of the day, it is the lender who approves or rejects your loan request. However as we deal with multiple lenders, we process your single loan application with all of our lenders. So your chances of getting approval for a loan through LoanTube are comparatively higher than applying with any lender directly.
                                    </div>
                                  </div>
                                </div>
                              </div>
        </>
    )
}