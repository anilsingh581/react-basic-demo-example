import React from 'react'

export default () => 
    <div className="accordion" id="accordionBefore">
    <div className="card">
    <div id="headingOne">
    <h2 className="mb-0" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
        What is an unsecured loan?
    </h2>
    </div>
    <div id="collapseOne" className="collapse show" aria-labelledby="headingOne" data-parent="#accordionBefore">
    <div className="card-body">
        An unsecured loan is a type of personal loan where no collateral is involved. Instead of pledging assets or properties, a borrower’s loan is approved based on their creditworthiness.
    </div>
    </div>
    </div>
    <div className="card">
    <div id="headingTwo">
    <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
        What is LoanTube? What is its role in the whole process?
    </h2>
    </div>
    <div id="collapseTwo" className="collapse" aria-labelledby="headingTwo" data-parent="#accordionBefore">
    <div className="card-body">
        LoanTube is a FCA registered broker operating in the UK. With state-of-the-art digital loan platform. It is a common platform that brings lenders and borrowers with the help of real-time loan quotation comparison.
    </div>
    </div>
    </div>
    <div className="card">
    <div id="headingThree">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
        Why should I choose LoanTube?
        </h2>
    </div>
    <div id="collapseThree" className="collapse" aria-labelledby="headingThree" data-parent="#accordionBefore">
        <div className="card-body">
        LoanTube is a FCA registered broker that compares actual APRs among multiple lenders, which give borrowers a freedom to choose their own lender. Moreover, it believes in transparency and simplification of the process.
        </div>
    </div>
    </div>
    <div className="card">
    <div id="headingFour">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
        How can I apply and what happens after I finish applying for a loan?
        </h2>
    </div>
    <div id="collapseFour" className="collapse" aria-labelledby="headingFour" data-parent="#accordionBefore">
        <div className="card-body">
        Applying for a loan is easier, faster, and simple with LoanTube. Fill out the required details in the form available on our website and wait for a few minutes for the decision. The decision will be shown to you on the screen. Say good-bye to the waiting time! We try to match your loan requirements with lenders on our panel to find the right loan for you.
        </div>
    </div>
    </div>

    <div className="card">
    <div id="headingFive">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
        How much can I borrow?
        </h2>
    </div>
    <div id="collapseFive" className="collapse" aria-labelledby="headingFive" data-parent="#accordionBefore">
        <div className="card-body">
        The limits are set by lenders according to the responsible lending guidelines set by the financial regulatory body of the UK, FCA and it depends upon various factors like your incomes & your expenses. This limit do vary customer to customer.
        </div>
    </div>
    </div>

    <div className="card">
    <div id="headingSix">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
        What is the legal age for applying for a loan?
        </h2>
    </div>
    <div id="collapseSix" className="collapse" aria-labelledby="headingSix" data-parent="#accordionBefore">
        <div className="card-body">
        The legal age for applying a loan is 18 and the borrower should be a resident of the UK.
        </div>
    </div>
    </div>
    <div className="card">
        <div id="headingSeven">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
            How long does it take to get an unsecured loan in the UK?
        </h2>
        </div>
        <div id="collapseSeven" className="collapse" aria-labelledby="headingSeven" data-parent="#accordionBefore">
        <div className="card-body">
            After you fill out the available application form, we make an assessment based on the information provided by you. If we have all the information we and our lenders need, a “yes or a no” answer from lenders who are willing to lend you and the quotes/APRs they want to offer you will be displayed on your screen on a real-time basis.
    Once you accept any offer we display on the screen, it depends on the lender how soon they disburse the loan to you. Please read lender’s Terms & Conditions before you choose to accept the quote of any lender.
        </div>
        </div>
    </div>
    <div className="card">
        <div id="headingEight">
            <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
            How to decide which broker or bank to take a loan from?                                            
            </h2>
        </div>
        <div id="collapseEight" className="collapse" aria-labelledby="headingEight" data-parent="#accordionBefore">
            <div className="card-body">
            We suggest you to always run a thorough check before applying for a loan. Compare the interest rates, tenure and terms, and conditions before choosing your lender.
            </div>
        </div>
        </div>
        <div className="card">
            <div id="headingNine">
            <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
                Will LoanTube make a credit search on me?
            </h2>
            </div>
            <div id="collapseNine" className="collapse" aria-labelledby="headingNine" data-parent="#accordionBefore">
            <div className="card-body">
                A loan with credit check is always the safest option. LoanTube runs a soft credit check on your name which won’t affect your credit score. But that’s a good thing. Doing so helps us in knowing the right lenders for you even before we pass your details to them. So this way we don’t pass your details to any lender we already know won’t be able to lend you. The more we know know about you, the more personalised and more suitable loan deal we can find for you.
                Please note that soft credit check does not affect your borrowing capacity.
            </div>
            </div>
        </div>
        <div className="card">
            <div id="headingTen">
                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
                Who do you lend money to?
                </h2>
            </div>
            <div id="collapseTen" className="collapse" aria-labelledby="headingTen" data-parent="#accordionBefore">
                <div className="card-body">
                LoanTube is a registered broker and not a lender. We deal with a wide network of regulated lenders who would be lending money to our customers.
                </div>
            </div>
            </div>
    </div>
        