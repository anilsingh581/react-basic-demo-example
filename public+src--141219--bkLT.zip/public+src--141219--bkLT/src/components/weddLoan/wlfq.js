import React from 'react'

export default () => 
<div className="accordion" id="accordionBefore">
<div className="card">
  <div id="headingOne">
    <h2 className="mb-0" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
        Can you accept applications from people under the age of 18?
    </h2>
  </div>
  <div id="collapseOne" className="collapse show" aria-labelledby="headingOne" data-parent="#accordionBefore">
    <div className="card-body">
        No. Our lenders lend only to customers who are aged 18 or above.
    </div>
  </div>
</div>
<div className="card">
  <div id="headingTwo">
    <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
        Do I need to have a job?
    </h2>
  </div>
  <div id="collapseTwo" className="collapse" aria-labelledby="headingTwo" data-parent="#accordionBefore">
    <div className="card-body">
        Yes – our lenders will need you to be in a full-time, permanent, employed role. If you are unemployed, you may not be able to pass the lender’s affordability assessments. The exception is if you have other good sources of incomes like rental income and you can convince lenders that you can afford to pay the loan with those other incomes.
    </div>
  </div>
</div>
<div className="card">
    <div id="headingThree">
      <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
        Can I make a joint application with my spouse/civil partner-to-be?
      </h2>
    </div>
    <div id="collapseThree" className="collapse" aria-labelledby="headingThree" data-parent="#accordionBefore">
      <div className="card-body">
        Sorry, but that’s not possible at the moment. However, there is nothing to stop both of you taking individual wedding loans if needed. You will have to make two separate applications to do this.
      </div>
    </div>
  </div>
<div className="card">
    <div id="headingFour">
      <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
        Can you work with people who have been declared bankrupt, who are in an Individual Voluntary Arrangement, or who are on a debt management arrangement?
      </h2>
    </div>
    <div id="collapseFour" className="collapse" aria-labelledby="headingFour" data-parent="#accordionBefore">
      <div className="card-body">
        We’re really sorry, we can’t help you at this moment. People on IVA, Debt Management Plan and on Bankruptcy are considered as negative customers by lenders. It is a sign that you can’t really manage your finances. Due to this, we are very sure we won’t be able to find you a loan if you are on IVA or Debt Management Plan or have filed a bankruptcy in past.
      </div>
    </div>
  </div>
  
<div className="card">
    <div id="headingFive">
      <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
        What information will I need to provide you for my wedding loan?
      </h2>
    </div>
    <div id="collapseFive" className="collapse" aria-labelledby="headingFive" data-parent="#accordionBefore">
      <div className="card-body">
        There are some personal details (like date of birth and where you’ve lived for the last few years) but most of the information we’ll need is financial, for example, who you work for, how much you earn, your monthly earnings & spendings, etc.
      </div>
    </div>
  </div>
  
<div className="card">
    <div id="headingSix">
      <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
        Do I need to find someone else who will pay off my loan if I can’t do so?
      </h2>
    </div>
    <div id="collapseSix" className="collapse" aria-labelledby="headingSix" data-parent="#accordionBefore">
      <div className="card-body">
        No.
      </div>
    </div>
  </div>
  <div className="card">
      <div id="headingSeven">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
            Will you give me an answer as quickly as my other half when I popped the question?
        </h2>
      </div>
      <div id="collapseSeven" className="collapse" aria-labelledby="headingSeven" data-parent="#accordionBefore">
        <div className="card-body">
            We don’t know how quickly they said “yes” to your proposal! However, your spouse-to-be or your civil partner-to-be will have to have said “yes” fast to beat LoanTube’s speed at giving you an answer.
            <p>If we have all the information we and our lenders need, a “yes” or “no” answer from lenders who are willing to lend you with their APRs/quotes will be displayed on your screen on a real-time basis.</p>
        </div>
      </div>
    </div>
    <div className="card">
        <div id="headingEight">
          <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
            Does LoanTube lend me the money?                                            
          </h2>
        </div>
        <div id="collapseEight" className="collapse" aria-labelledby="headingEight" data-parent="#accordionBefore">
          <div className="card-body">
            No – we are a credit broker. We’re licensed by the Financial Conduct Authority to match borrowers with lenders. We arrange your loan but we don’t transfer you the money and you don’t pay the money back to us – you do that for your lender. And to ensure the highest levels of industry practice across the board, we only work with lenders who have been inspected and given their licence by the Financial Conduct Authority.
          </div>
        </div>
      </div>
      <div className="card">
          <div id="headingNine">
            <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
                Can you tell me about how you actually match a lender with me?
            </h2>
          </div>
          <div id="collapseNine" className="collapse" aria-labelledby="headingNine" data-parent="#accordionBefore">
            <div className="card-body">
                When we become partners with a lender, one of the first things they do is to send us a list of the types of borrowers they would like to work with. You might be just the type of borrower one lender is looking for but another might not consider you. Our job is to pair you with the right lenders based on the information you give us.
            </div>
          </div>
        </div>
        <div className="card">
            <div id="headingTen">
              <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
                How much does the LoanTube service cost me?
              </h2>
            </div>
            <div id="collapseTen" className="collapse" aria-labelledby="headingTen" data-parent="#accordionBefore">
              <div className="card-body">
                Zero. LoanTube’s mission is to bring down the cost of borrowing by trying to find the cheapest rates for you. All of our hard work would be undone if we found you a great loan and then slapped a fee on top for our service. You never pay us a penny.
              </div>
            </div>
          </div>
          <div className="card">
            <div id="headingEve">
              <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseEve" aria-expanded="false" aria-controls="collapseEve">
                How does LoanTube make money?
              </h2>
            </div>
            <div id="collapseEve" className="collapse" aria-labelledby="headingEve" data-parent="#accordionBefore">
              <div className="card-body">
                We get paid with a commission by a lender when our customer agrees to take a loan from one of our lenders we showed them and when the loan amount has been transferred to the customer’s bank account.
              </div>
            </div>
          </div>
          <div className="card">
            <div id="headingTwe">
              <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwe" aria-expanded="false" aria-controls="collapseTwe">
                Do you offer wedding loans with no credit check?
              </h2>
            </div>
            <div id="collapseTwe" className="collapse" aria-labelledby="headingTwe" data-parent="#accordionBefore">
              <div className="card-body">
                No, sorry, we don’t. We’re licensed by the Financial Conduct Authority and so are the lenders on our panel. Please note that no credit check is a marketing gimmick.
              </div>
            </div>
          </div>
          <div className="card">
            <div id="headingThr">
              <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseThr" aria-expanded="false" aria-controls="collapseThr">
                Am I obliged to take any offer your lenders make to me?
              </h2>
            </div>
            <div id="collapseThr" className="collapse" aria-labelledby="headingThr" data-parent="#accordionBefore">
              <div className="card-body">
                No. You can always say no if you feel like.
              </div>
            </div>
          </div>
</div>
    