import React from 'react'

export default () => 
<>
<p>We always aim to be fair and honest in everything we do and we pride ourselves at providing the highest level of service, but we understand that sometimes this level of service could slip. So if you are unhappy with our services, for any reason, please contact us, and allow us the opportunity to put the things right.</p>
<p>You can contact us in any of the following ways to make a complaint: </p>
<p><b>By Post</b>:</p>
<p>The Compliance Manager</p>
<p>Tiger Lion Financial Limited, </p>
<p>71-75 Shelton Street</p>
<p>Covent Garden</p>
<p>London</p>
<p>WC2H 9JQ</p>
<p><b>By email:</b> <a href="mailto:complaints@loantube.com">complaints@loantube.com</a></p>
<p>Please send us your details, a description of your complaint and how you think we can resolve it, and any other relevant information which you think can help us understand your complaint. The better we understand your complaint, the easier it will be for us to resolve your complaint sooner.</p>
<p>Your complaint will be acknowledged promptly in writing and we will do our best to resolve your complaint as quickly as possible. </p>
<p>Sometimes it may take longer to fully investigate and If a complaint is particularly complex, it may take longer to resolve. We will always try our best to respond to your complaint as quickly as possible and we’ll send you our final response no later than 8 weeks from when you first complained. If we can’t complete our investigation in this time, we’ll contact you to explain the delay and give you an indication of when to expect our response. </p>
<p>If you’re not happy with our final response or if your complaint is not resolved within 8 weeks, at this point, you can refer it to the Financial Ombudsman Service.</p>
<p>The Financial Ombudsman Service will only deal with your complaint if you have given us the opportunity to put matters right, so please contact us first and we will do all we can to help you.</p>
<h2><b>Financial Ombudsman Service (FOS)</b></h2>
<p>If you want the FOS to consider your complaint, you must send your complaint to them within 6 months of the date of our final response. Their contact details are:</p>
<p>The Financial Ombudsman Service</p>
<p>Service Exchange Tower</p>
<p>London</p>
<p>E14 9SR</p>
<p><strong>Telephone:</strong></p>
<p>0300 1239 123, calls to this number cost no more than calls to 01 and 02 numbers.</p>
<p>0800 023 4567, calls to this number are now free on mobile phones and landlines.</p>
<p>+44 20 7964 0500, if you are calling from outside the UK.</p>
<p>Email: <a href="mailto:complaint.info@financial-ombudsman.org.uk">complaint.info@financial-ombudsman.org.uk</a></p>
<p>Information regarding the service can be found on the Financial Ombudsman website:</p>
<p><a href="https://www.financial-ombudsman.org.uk/publications/consumer-leaflet.htm">https://www.financial-ombudsman.org.uk/publications/consumer-leaflet.html</a></p>
<h2><b>European Online Dispute Resolution Platform</b></h2>
<p>In relation to your complaint you can also request a review from the European Online Dispute Resolution platform:</p>
<p><a href="https://ec.europa.eu/consumers/odr/">https://ec.europa.eu/consumers/odr/</a></p>
</>    