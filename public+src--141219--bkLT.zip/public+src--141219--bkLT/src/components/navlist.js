import React from 'react'
import {Link} from 'react-router-dom'

export default (props) => {
    const renderSubMenu = () => props.subMenu.map((item, i) =><Link to={item.href} key={i} className="dropdown-item">{item.name}</Link>);
    return(
        <>
            <li>
                <Link to={props.href} className={typeof props.subMenu =="object" && 'dropdown-toggle'} data-toggle="dropdown">{props.name}</Link>
                {props.subMenu ? (typeof props.subMenu =="object" ? <div className="dropdown-menu">{renderSubMenu()}</div> : null) : null}
            </li>
        </>
    )
}
