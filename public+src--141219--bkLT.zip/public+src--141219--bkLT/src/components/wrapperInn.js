import React from 'react'

export default (props) => 
<section className="ourPartnerSec">
    <div className="container">
        {props.children}
    </div>
</section>
       