import React, { Component } from 'react'
import CategoryC from './blogCategoryC'
import SidebarWarning from './sidebarWarning'
import {apiBaseUrl} from '../assets/js/helpers'


export default class MySidebar extends Component {
    state = {
        error: null,
        isloaded: false,
        Loantype: []
    }

    loanList =[];
    constructor(props) {
        super(props);
        this.getLoanTypeList();
    }

    getLoanTypeList() {
        fetch(apiBaseUrl+'api/Loantype')
             .then(response => response.json())
            .then(result => {
                this.loanList = result.data;
                this.setState({
                    isloaded: false,
                    Loantype: result.data
                })
            })
            .catch(error => {
                this.setState({
                    isloaded: true,
                    error
                })
            })
    }
    
    renderBlogCategory = () => {
        return this.loanList.map((item, i) =>
            <CategoryC key={i} blgCategoryURL={item.loanpageurl} blgCategory={item.loantype} id ={item.id} />
        )
    }
    render() {
        return (
            <>
                <div className="blgRightSidebar">
                    <SidebarWarning />
                    <div className="blgCategory">
                        <h3>Categories</h3>
                        <ul>
                            {this.renderBlogCategory()}
                        </ul>
                    </div>
                </div>
            </>
        )
    }
}