import React from 'react'

export default () => {
    const aboutBtmText = {
        abtBtmText : [
            {abttext:'So-called comparison sites don’t really compare lenders’ actual APR – you could apply for a loan thinking you’re going to get one rate but what you’re offered is something else (and usually higher).'},
            {abttext:'Loan sharks are hounding innocent borrowers with astronomical interest rates and, if they don’t meet their repayments, they’re getting threatened and harassed by their lenders.'},
            {abttext:'The Financial Conduct Authority, the body which polices loan companies, is really trying hard – they’re good people. But as soon as they plug one leak, another one takes its place.'},
            {abttext:'Doesn’t it all feel like the personal loan market is being run for everyone except the borrower?'},
            //{abttext:'My team and I set up <a href="https://www.loantube.com/guides/launch-news-loantube/">LoanTube</a> to do something about it – it’s something we all feel very strongly about. It should be much easier for those who need money to cover an emergency bill when one arises and not pay over the odds for the privilege.<br /><br /> The right to live free of financial worry is a human right!'}
        ]
    }
    
 const renderaboutBtmText = () => {
     return aboutBtmText.abtBtmText.map((item, i) => <div className="abtBxx" key={i}>{item.abttext}</div>)
 }

    return(
           <> {renderaboutBtmText()}</>
    )
}