import React from 'react'

export default () => {
    const aboutText = {
            abouttopBox : [
                {clsName:'abtBox abt1', abtTpText:'Customers have always been the KING, right?'},
                {clsName:'abtBox abt2', abtTpText:'Well, that’s the theory. But when it comes to getting a loan, is that really true?'},
                {clsName:'abtBox abt3', abtTpText:'Have you heard the old saying that banks are happy to lend you an umbrella but they want it back as soon as it starts raining?'},
                {clsName:'abtBox abt4', abtTpText:'Well, it’s true and, as a financial specialist, I’m not very happy about it. I’m here to change things – to shake things up. I’m here to make you KING or QUEEN again.'},
                {clsName:'abtBox abt5', abtTpText:'My name is Gurprit and I’m going to move heaven and Earth to make sure that, when you apply for loans, you’ll be number one from now on.'}
            ]
    }

    const renderaboutText = () => {
        return aboutText.abouttopBox.map((item, i) => <div key={i}><div className={item.clsName}><div className="bar"></div><div>{item.abtTpText}</div></div><div className="clr"></div></div>)
    }

    return (
        <>
            {renderaboutText()}
        </>
    )
}