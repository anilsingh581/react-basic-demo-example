import React from 'react'
import {Link} from 'react-router-dom'

export default () => {
    return(
        <>
            <div className="warning">
                            <p>Warning: Late repayment can cause you serious money problems. For more information, go to<br/>
                                <Link to="https://www.moneyadviceservice.org.uk/en" target="_blank"
                                    rel="noopener noreferrer">MONEYADVICESERVICE.ORG.UK</Link><br/>
                                Credit subject to status & affordability assessment by Lenders.<br/>
                                LoanTube is a credit broker and not a lender</p>
                                <p>Think carefully before securing debts against your home. Your home may be repossessed if you do not keep up repayments on any debt secured against it.</p>
                        </div>
        </>
    )
}