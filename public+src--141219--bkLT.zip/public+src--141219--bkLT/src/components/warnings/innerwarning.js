import React from 'react'

export default () => 
<div className="warningInner">
<p><strong>Representative APR Example</strong></p>

<p>The rate you are offered will depend on your individual circumstances. All loans are subject to status. The interest rate offered will vary depending on our assessment of your financial circumstances and your chosen loan amount. Representative APR Example: for comparison purposes 12.9% APR Representative Fixed based on a loan of £10,000 repayable over 60 Months. Monthly payment of £223.43 total amount repayable £13,405.80.</p>

<strong>Warning:</strong> Late repayment can cause you serious money problems. For more information, go to <a href="https://www.moneyadviceservice.org.uk/en" target="_blank" rel="noopener noreferrer">MONEYADVICESERVICE.ORG.UK</a> Credit subject to status & affordability assessment by Lenders. LoanTube is a credit broker and not a lender
<p>Think carefully before securing debts against your home. Your home may be repossessed if you do not keep up repayments on any debt secured against it.</p>
</div>