import React from 'react'
const images = require.context('../../assets/images')

export default () => 
        <>
            <div className="brdCenterText">A secured loan – often referred to as a homeowner loan – allows individuals to borrow money while using their property as security against the amount they owe. It is often used by those who need to borrow a large sum of money but has a poor credit rating. Your property, or asset, is used by the lender as security so that they can sell the property if you do not keep up with the repayments. Due to this security, the loans are relatively low in interest and it is normally easy to qualify if you own a property. Three key things to know about Secured Loans:</div>
                            <div className="threeText"><div className="threeimg"><img src={images('./secured31.png')} alt="Secured Loans" /></div>
                            <div>Lenders take into account a number of factors when looking at secured loan applications. These include the value of your home, your income, your personal credit score and any existing debts.</div></div>
                            <div className="threeText"><div className="threeimg"><img src={images('./secured32.png')} alt="Secured Loans" /></div><div>Interest rates for secured loans tend to be lower due to the security offered to the bank. The rates can be fixed or variable depending on the type of loan you opt for. As long as the repayments are made in full each month, you will not lose your home.</div></div>
                            <div className="threeText"><div className="threeimg"><img src={images('./secured33.png')} alt="Secured Loans" /></div><div>If you default on a secured loan, your home may be at risk of being repossessed. This means the bank can forcibly sell your property in order to receive the money that is owed. While these loans are beneficial to many individuals, it is worth considering this fact before taking one out.</div></div>
        </>
    