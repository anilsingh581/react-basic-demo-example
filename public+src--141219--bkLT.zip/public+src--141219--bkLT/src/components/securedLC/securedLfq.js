import React from 'react'

export default () => 
<div className="accordion" id="accordionBefore">
                        <div className="card">
                            <div id="headingOne">
                                <h2 className="mb-0" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    Why are interest rates lower for secured loans?
                                </h2>
                            </div>
                            <div id="collapseOne" className="collapse show" aria-labelledby="headingOne" data-parent="#accordionBefore">
                                <div className="card-body">
                                    Lenders offer a lower interest rate on secured loans because they have the security of your property if you do not repay the debt. This means they are happier to reduce the interest rate because there is less risk for the lender.
                                </div>
                            </div>
                        </div>
                        <div className="card">
                            <div id="headingTwo">
                                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                    Can I apply for a secured loan if my credit history isn’t good?
                                </h2>
                            </div>
                            <div id="collapseTwo" className="collapse" aria-labelledby="headingTwo" data-parent="#accordionBefore">
                                <div className="card-body">
                                    Yes, which is good news for those with poor or no credit history.The interest rates are lower, lenders will offer this loan to those with poor credit due to the security of your home.
                                </div>
                            </div>
                        </div>
                        <div className="card">
                            <div id="headingThree">
                                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                    Can I lose my home with a secured loan?
                                </h2>
                            </div>
                            <div id="collapseThree" className="collapse" aria-labelledby="headingThree" data-parent="#accordionBefore">
                                <div className="card-body">
                                    Yes, your home could be at risk if you do not keep up with the monthly repayments. Lenders use your home as security in case you do not repay the debt. This means the lender can apply to the courts and force you to sell your property to get their money
                                    back.
                                </div>
                            </div>
                        </div>
                        <div className="card">
                            <div id="headingFour">
                                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                    I have a secured loan but I’m moving house – is this a problem?
                                </h2>
                            </div>
                            <div id="collapseFour" className="collapse" aria-labelledby="headingFour" data-parent="#accordionBefore">
                                <div className="card-body">
                                    This isn’t necessarily an issue, though there are a few options that you may wish to consider. If you have enough money from the house sale, then you can potentially pay off the loan in one go. The other option would be to transfer the loan to the house
                                    you have bought. However, not all lenders will allow this and it is worth double-checking first.
                                </div>
                            </div>
                        </div>

                        <div className="card">
                            <div id="headingFive">
                                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                    Can I repay the loan early?
                                </h2>
                            </div>
                            <div id="collapseFive" className="collapse" aria-labelledby="headingFive" data-parent="#accordionBefore">
                                <div className="card-body">
                                    Again, this varies from lender to lender. Most of the lenders we work with will have an early repayment charge. For example, for some lenders, this can equate to eight weeks interest on any outstanding debt you have at the time you wish to settle. This
                                    can change lender to lender and it is always wise to read their terms and conditions in their agreement.
                                </div>
                            </div>
                        </div>

                        <div className="card">
                            <div id="headingSix">
                                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                                    Do I need to provide a guarantor for this loan?
                                </h2>
                            </div>
                            <div id="collapseSix" className="collapse" aria-labelledby="headingSix" data-parent="#accordionBefore">
                                <div className="card-body">
                                    No, you do not. Your home is the security for this loan.
                                </div>
                            </div>
                        </div>
                        <div className="card">
                            <div id="headingSeven">
                                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                                    Are you licensed to lend me money?
                                </h2>
                            </div>
                            <div id="collapseSeven" className="collapse" aria-labelledby="headingSeven" data-parent="#accordionBefore">
                                <div className="card-body">
                                    LoanTube doesn’t lend you the money- we’re a credit broker and not a lender. As a credit broker, we act as a bridge between lenders and borrowers. We connect you with the lenders (all licensed by the Financial Conduct Authority) who will consider your
                                    loan application. Applying through LoanTube means you don’t have to submit dozens of applications individually to each lender to get your loan decision.
                                </div>
                            </div>
                        </div>
                        <div className="card">
                            <div id="headingEight">
                                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
                                    How do you know which companies will lend me money and which ones will not?
                                </h2>
                            </div>
                            <div id="collapseEight" className="collapse" aria-labelledby="headingEight" data-parent="#accordionBefore">
                                <div className="card-body">
                                    When we become partners with a lender, one of the first things they do is to send us a list of the types of borrowers they would like to work with. You might be just the type of borrower one lender is looking for but another might not consider you. Our
                                    job is to pair you with the right lenders based on the information you give us.
                                </div>
                            </div>
                        </div>
                        <div className="card">
                            <div id="headingNine">
                                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
                                    If I get an offer, do I have to take the loan?
                                </h2>
                            </div>
                            <div id="collapseNine" className="collapse" aria-labelledby="headingNine" data-parent="#accordionBefore">
                                <div className="card-body">
                                    No. You’re never under any obligation to accept an offer that you receive from LoanTube. Even if we say “yes” then you turn around and tell us “no”, there’s no charge for our service.
                                </div>
                            </div>
                        </div>
                    </div>
    