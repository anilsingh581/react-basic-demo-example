import React, { Component } from 'react'
import axios from 'axios';
import { apiBaseUrl } from '../../assets/js/helpers'

export default class ContactFrm extends Component {
    contactObject = {
        name: "",
        email: "",
        phone: "",
        message: ""
    }

    state = this.contactObject;

    handleChange = (propertyName, event) => {
        const state = this.state;
        state[propertyName] = event.target.value;
        this.setState({ state: state });
    }

    submitContact = () => {
        let contactInfo = {
            "name": this.state.name,
            "email": this.state.email,
            "phone": this.state.phone,
            "message": this.state.message
        }
        console.log(contactInfo);
        axios.post(apiBaseUrl+'api/nodemailer', contactInfo)
            .then(result => {
                this.setState({
                    name: "",
                    email: "",
                    phone: "",
                    message: ""
                });
            })
            .catch(function (error) {
                console.log(error);
            });

    }

    render() {
        return (
            <>
                <h3>Drop Your Message</h3>
                <div className="smoothFrm">
                    <div className="frmGroup">
                        <input type="text" name="Email" className="form-control placeholderfrm" required="" id="name" aria-invalid="true" value={this.state.name} onChange={this.handleChange.bind(this, 'name')} />
                        <span className="smoothLabel">Name</span>
                    </div>
                    <div className="frmGroup">
                        <input type="email" name="email" className="form-control placeholderfrm" required="" id="email" aria-invalid="true" value={this.state.email} onChange={this.handleChange.bind(this, 'email')} />
                        <span className="smoothLabel">Email</span>
                    </div>
                    <div className="frmGroup">
                        <input type="text" name="phone" className="form-control placeholderfrm" required="" id="phone" aria-invalid="true" value={this.state.phone} onChange={this.handleChange.bind(this, 'phone')} />
                        <span className="smoothLabel">Phone Number</span>
                    </div>
                    <div className="frmGroup">
                        <textarea name="message" className="form-control placeholderfrm" required="" id="message" aria-invalid="true" value={this.state.message} onChange={this.handleChange.bind(this, 'message')} ></textarea>
                        <span className="smoothLabel">Message</span>
                    </div>
                    <div className="text-center"><input type="submit" value="Send" className="btn btnsend" onClick={this.submitContact} /></div>
                </div>
            </>
        )
    }
}
