import React from 'react'
const images = require.context('../../assets/images')

export default () => 
        <>
            <div className="brdCenterText">People are refused loans all the time, and it often leaves them feeling stuck or trapped with nowhere else to turn. Luckily, those who have been refused a loan have a solution, through a little help from their family and friends. Guarantor loans are perfect for those who believe they will be refused a loan on the basis of their own credit history. Lenders are guaranteed that the repayments will be paid by the guarantor if the original borrower fails to do so. Three key things to know about Guarantor Loans are:</div>
                            <div className="threeText"><div className="threeimg"><img src={images('./guarantor31.png')} alt="Guarantor Loans" /></div>
                            <div>Guarantor loans generally have a higher rate of interest than standard loans. This is due to the borrower’s poor credit or lack of credit score. The lender increases the interest rate due to the level of risk they are taking on.</div></div>
                            <div className="threeText"><div className="threeimg"><img src={images('./guarantor31.png')} alt="Guarantor Loans" /></div><div>The guarantor needs to be aged between 21 and 75 and needs to have a good credit rating and a regular income for the application to be approved. They will need to show proof of income and proof of ID. The guarantor also needs to show their relationship with the borrower. Ideally, this will be someone who has a strong connection to the borrower but is not financially involved with them. For example, the borrower cannot have their spouse or partner as their guarantor.</div></div>
                            <div className="threeText"><div className="threeimg"><img src={images('./guarantor31.png')} alt="Guarantor Loans" /></div><div>Guarantor loans are unsecured, meaning you do not need to own a property or car to be accepted. This means your personal assets are not at risk when taking out this type of loan.</div></div>
        </>
    