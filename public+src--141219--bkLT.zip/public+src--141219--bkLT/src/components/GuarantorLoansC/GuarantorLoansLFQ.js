import React from 'react'

export default () =>
<div className="accordion" id="accordionBefore">
<div className="card">
    <div id="headingOne">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
            Who can be my guarantor?
        </h2>
    </div>
    <div id="collapseOne" className="collapse" aria-labelledby="headingOne" data-parent="#accordionBefore">
        <div className="card-body">
            Your guarantor needs to be aged between 21 and 75, have a good credit rating and have a regular income. They need to be someone who is close to you, like a close friend or family member. You need to trust that they will help you repay the loan if for
            any reason you cannot. In addition to this, your guarantor cannot be financially involved with you. For example, the borrower cannot have their spouse or partner as their guarantor.
        </div>
    </div>
</div>
<div className="card">
    <div id="headingTwo">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
            Why are guarantor loans’ interest rates higher than standard loans?
        </h2>
    </div>
    <div id="collapseTwo" className="collapse" aria-labelledby="headingTwo" data-parent="#accordionBefore">
        <div className="card-body">
            Guarantor loans are given to those who cannot take out a personal loan due to their poor credit rating. This means that the lender is taking on an increased risk. The lender increases the interest rate due to this risk.
        </div>
    </div>
</div>
<div className="card">
    <div id="headingThree">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
            Will my credit rating be affected as a guarantor?
        </h2>
    </div>
    <div id="collapseThree" className="collapse" aria-labelledby="headingThree" data-parent="#accordionBefore">
        <div className="card-body">
            The lender will carry out a search and list you as a guarantor, not a borrower. However, in the short term, becoming a guarantor may affect your credit score as the search will remain on your credit report for 12 months. As always, making regular monthly
            repayments will always improve your credit rating.
        </div>
    </div>
</div>
<div className="card">
    <div id="headingFour">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
            What if the borrower does not pay?
        </h2>
    </div>
    <div id="collapseFour" className="collapse" aria-labelledby="headingFour" data-parent="#accordionBefore">
        <div className="card-body">
            If you are the guarantor and the borrower does not pay back their debt, the lender would contact you. As a guarantor, you are then expected to cover the monthly payments for them if they cannot.
        </div>
    </div>
</div>

<div className="card">
    <div id="headingFive">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
            As a guarantor, can I help pay the loan each month?
        </h2>
    </div>
    <div id="collapseFive" className="collapse" aria-labelledby="headingFive" data-parent="#accordionBefore">
        <div className="card-body">
            While it is not expected for you to help repay the debt (provided the borrower makes the monthly repayments), you are free to assist them with the repayments if you wish to do so.
        </div>
    </div>
</div>

<div className="card">
    <div id="headingSix">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
            Do I need to provide a guarantor for this loan?
        </h2>
    </div>
    <div id="collapseSix" className="collapse" aria-labelledby="headingSix" data-parent="#accordionBefore">
        <div className="card-body">
            Yes, you are required to provide a guarantor for this type of loan. LoanTube does not source the guarantor for you.
        </div>
    </div>
</div>
<div className="card">
    <div id="headingSeven">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
            Does my Guarantor need to own a property?
        </h2>
    </div>
    <div id="collapseSeven" className="collapse" aria-labelledby="headingSeven" data-parent="#accordionBefore">
        <div className="card-body">
            This can vary from lender to lender. However, your guarantor does not need to own a property in all instances. If, for example, your guarantor has a strong credit rating and a good income they may not need to own a property. This is also dependent on
            the loan amount.
        </div>
    </div>
</div>
<div className="card">
    <div id="headingEight">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
            How do you know which companies will lend me money and which ones will not?
        </h2>
    </div>
    <div id="collapseEight" className="collapse" aria-labelledby="headingEight" data-parent="#accordionBefore">
        <div className="card-body">
            LoanTube works with lenders and helps match them up with their perfect borrower. Some of these lenders might not consider you, while others might think you are the ideal customer. It is our job to pair you with the right lenders based on the information
            you give us.
        </div>
    </div>
</div>
<div className="card">
    <div id="headingNine">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
            Are you licensed to lend me money?
        </h2>
    </div>
    <div id="collapseNine" className="collapse" aria-labelledby="headingNine" data-parent="#accordionBefore">
        <div className="card-body">
            No. LoanTube doesn’t lend you the money- we’re a credit broker, not a lender. As a credit broker, we act as a bridge between lenders and borrowers. We connect you with the lenders (all licensed by the Financial Conduct Authority) who will consider your
            loan application. Applying through LoanTube means you don’t have to submit dozens of applications individually to each lender to get your loan decision.
        </div>
    </div>
</div>
<div className="card">
    <div id="headingTen">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
            How do I start?
        </h2>
    </div>
    <div id="collapseTen" className="collapse" aria-labelledby="headingTen" data-parent="#accordionBefore">
        <div className="card-body">
            You can start here at LoanTube. You can begin your application for the long term by inputting a few details into our loan application form. This includes how much you want to borrow, how long for, and what the loan is for. We then search through our partners
            and try to match you with the perfect
        </div>
    </div>
</div>
<div className="card">
    <div id="headingEve">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseEve" aria-expanded="false" aria-controls="collapseEve">
            If I get an offer, do I have to take the loan?
        </h2>
    </div>
    <div id="collapseEve" className="collapse" aria-labelledby="headingEve" data-parent="#accordionBefore">
        <div className="card-body">
            No. You’re never under any obligation to accept an offer that you receive from LoanTube. Even if we say “yes” then you turn around and tell us “no”, there’s no charge for our service.
        </div>
    </div>
</div>
</div>