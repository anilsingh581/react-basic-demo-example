import React from 'react'

export default () =>
    <>
        <h4>Our comparison service is free for you to use. Yes it’s free!!</h4>
        <p>Are you thinking how we make money then? – We receive a fee or commission from lenders whenever you obtain a loan through LoanTube.</p>
    </>