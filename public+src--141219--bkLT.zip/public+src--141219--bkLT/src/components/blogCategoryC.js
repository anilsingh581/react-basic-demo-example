import React, { Component } from 'react'
import { Link } from 'react-router-dom'

export default class CategoryC extends Component {

    render() {
        return (
            <>
                <li>
                    <Link id={this.props.id} to={{ pathname: '/guides'+this.props.blgCategoryURL, search: this.props.blgCategoryURL, state: { id: this.props.id } }}>{this.props.blgCategory}</Link>
                </li>

            </>
        )
    }
}