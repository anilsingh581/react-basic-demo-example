import React from 'react'

export default () => {
    return (
        <>
            <div id="rightSideCookies">
                <p>Generally, Terms and conditions is a statement which includes rules by which one must agree to abide in order to use the services offered. These statement of agreement is very long. Hence, we have prepared a gist of the agreement for your convenience. Customer Satisfaction is our top priority.</p>
                <p>Please find below some key points of the agreement:</p>
                <ul>
                    <li>This website is for your personal use only and may not be used for any commercial purposes.</li>
                    <li>Use of this website is subject to all of the Terms set out below – if you don’t agree to the terms, please stop using the website immediately.</li>
                    <li>It’s your sole responsibility to ensure that the information you provide us when using any of our websites is accurate and complete. List of all of our group websites is mentioned at the end of the page.</li>
                    <li>We may amend these Terms and conditions at any time and without notice, by changing this page, so you are requested to check these Terms and conditions each time you use the website.</li>
                </ul>
                <h2 id="lftSide1">1. Introduction</h2>
                <p>LoanTube is a trading style of Tiger Lion Financial Limited. Tiger Lion Financial Limited is based in London as a credit broker.</p>
                <ul>
                    <li>Our registered office address is 71-75 Shelton Street, Covent Garden, London, WC2H 9JQ.</li>
                    <li>We are authorised and regulated by the financial regulatory body of UK which is Financial Conduct Authority, usually called as FCA. Our FCA Firm Reference Number is 753151.</li>
                    <li>We are also registered with the Information Commissioners Office and our registration number is ZA185613.</li>
                    <li>We are registered in England &amp; Wales and our Company Number is 10189367.</li>
                </ul>
                <p>We carry out the business of credit brokerage in the United Kingdom. Our Company does not provide any loans or make any credit decisions.</p>
                <h2 id="lftSide2">2. Our Service</h2>
                <p>LoanTube is one-of-a-kind loan brokering firm which operates in the United Kingdom. It compares actual APRs (Annual Percentage Rate) and monthly repayments to ensure that you are not opting for any loan under a deception. This real-time loans comparison marketplace has a proprietary loan matching engine which connects the right borrower with the right lender. Any match made by us with any lender does not constitute any obligation on your side to accept the quotes offered by such lender/s. After receiving the quotes on the screen, it is totally your decision to accept any of them post reading the subjected conditions for such offered APRs and the features associated with such lender’s loan quote offer. Post acceptance of the quote, the processing of your loan application is between your and the lender’s control. You still have the chance to cancel or deny to proceed with that lender before you have signed any agreement or contract with that lender.</p>
                <p>The APRs and monthly repayments showed on our website post processing of your loan application by us, are the rates which we guarantee will remain same post completion of your application with the lender unless otherwise the lender find some substantial information or any variance in the information provided which can make you look more riskier to the lender/s and thus they have to increase the rates/APRs to justify the additional risk found. At this stage, you can opt to not to proceed with such lender. You are free to do that. In adverse cases where your application looks very riskier to lender at the time of making final checks, they can decline it and deny to give you the loan.</p>
                <p>In short, what you see on our website is what you get in real. Only exception to this is the adverse or hidden information which lender may find, about you, your financial associate or any linked person, during the detailed processing of loan application.</p>
                <p>Beyond offering you the initial quote on our website and your acceptance to it, lender may still perform a detailed credit check to see your credit history, verify income &amp; expenses, check eligibility, affordability and credit worthiness, check your detailed information, your financial associates’ and any person linked to you in any way on all addresses you have resided on or linked to or associated to in any way. Your acceptance to use our service and to proceed with/acceptance to any quote gives us the right to authorise our partners to do so. We do not accept any responsibility for any of our partners or third party websites for any loss or damage that may arise from your use of their products &amp; services, either directly or indirectly through us or independently.</p>
                <p>Our comparison service is free for you to use. We receive a fee or commission from lenders when you use us to find you a loan. Our customer service team is available to support you with any queries.</p>
                <p>The Company does not promise that completing an Application Form will result in you receiving a loan offer. Your request is not an application for credit from a specific lender or lenders but an expression of your interest in our service to compare the real rates from our partner lenders in order to find a good loan deal.</p>
                <p>Any Representative APR examples of loan terms on our website and on our partners’ websites are for demonstrative purposes only. They may or may not be available to you.</p>
                <h2 id="lftSide3">3. Changes to Terms and conditions</h2>
                <p>We reserve the right to amend, revise or update these Terms and conditions from time to time by revising this page. The amended, revised or updated Terms and conditions will be effective from the date they are posted on our website.</p>
                <p>Post any amendment, revision or update, if you continue using our website, it will indicate that you have accepted the revised Terms and conditions .</p>
                <h2 id="lftSide4">4. Accessing our Website</h2>
                <p>We reserve the right to withdraw or amend the service we provide on our Site without notice. We will not be liable if for any reason our website is unavailable at any time or for any period.</p>
                <p>Our website is for your personal use only and you must not use it in any unlawful or fraudulent manner.</p>
                <h2 id="lftSide5">5. Credit Checks &amp; References</h2>
                <p>By completing the Application Form you authorise us to transmit your Application Form to our Partners to process your personal information and perform the checks necessary to find a loan quote.</p>
                <p>You understand that these checks may include contacting Credit Reference Agencies (CRAs), fraud and money laundering preventing agencies and the electoral register as well as providing them information about you.</p>
                <p>We and our partner lenders carry out “soft credit search” on your personal information which you provide us. A ‘soft credit search’ or, as it is sometimes referred to, ‘quotation search’ is a search conducted by us or lender with a credit reference agency, such as Equifax, Experian or Call Credit. This helps us to identify and match you to the right lender/s and it helps the lender to determine whether or not they would be able to provide the loan product or service. Unlike a ‘hard’ credit search, a soft credit search is recorded on your credit file, but only you can see it, rather than any other finance provider. A ‘soft credit search’ does not impact your credit worthiness.</p>
                <p>Any misleading or fabricated information provided by you during opting for our services will be considered as a breach of our Terms and conditions and Privacy Policy. And this also may result in a legal investigation against you and your details will be passed to fraud prevention agencies to prevent fraud and money laundering.</p>
                <h2 id="lftSide6">6. Intellectual Property</h2>
                <p>Our website, the content, any materials downloaded, and all intellectual property pertaining to or contained on our website (including but not limited to copyrights, patents, database rights, graphics, designs, text, logos, videos, illustrations, trade dress, trademarks, patents and service marks, (collectively ‘the Content’) is owned by Tiger Lion Financial Limited and all such rights are reserved.</p>
                <h4>Details of our Trademark:</h4>
                <p>Trade Mark Application No. UK00003238786</p>
                <h4>Details of our Patents filed:</h4>
                <p>UK Patent: GB1709524.1</p>
                <p>International Patent: PCT/IB2017/053568</p>
                <p><b>Without our written expressed permission or authorisation,</b></p>
                <p>You are not allowed &amp; not authorised to:</p>
                <ul>
                    <li>Duplicate, publish and modify any portion of our website for any public or commercial use without the express written consent from us.</li>
                    <li>Remove or alter any author, trademark or other proprietary notice or legend displayed on our website or printed pages produced from our website.</li>
                    <li>Make any other modifications to any documents obtained from our website other than in connection with completing information required to transact business with us.</li>
                    <li>Create derivative works, participate in the transfer of or in any way exploit our website for public or commercial use.</li>
                </ul>
                <p>You are allowed &amp; authorised to:</p>
                <ul>
                    <li>View or retain a copy of the pages from our website for personal but non-commercial use.</li>
                    <li>View and make copies of relevant documents, pages or other documents for the purpose of transacting business with us.</li>
                </ul>
                <p>Any act done by you, for which you were required to seek written expressed permission and authorisation, if done without our written authorisation and permission, can result in a legal action against you.</p>
                <p>Requests for permissions and authorisation should be directed to <a href="mailto:info@loantube.com">info@loantube.com</a> or Tiger Lion Financial Limited, 71-75 Shelton Street, Covent Garden, London, England – WC2H 9JQ, United Kingdom.</p>
                <h2 id="lftSide7">7. Our Partners &amp; Third Party Websites</h2>
                <p>Your use of any of our Partner/s or Provider/s or Third Party websites and your obtaining of any services will be subject to the Provider’s, Partner’s &amp; Third Party’s own terms and conditions, privacy &amp; cookies policies (which may be different from ours).</p>
                <p>In order to familiarise yourself with the details of the service, it is advisable to go through the Terms and Conditions, Privacy &amp; Cookies Policy of the provider/lender/partner/third party.</p>
                <p>If you leave our website to complete the loan application on one of our Providers/Lenders websites, it is very important that you carefully read their terms and to make sure you fully understand and accept them.</p>
                <p>When you use our service to find or compare a financial product or service, you may be contacted by the Provider(s)/Lender(s) whom you have agreed to proceed with, by clicking on the Accept Quote/Process/Proceed icon. They may contact you by telephone, SMS, email and/or post in order to provide you with loan. We advise that you read their Privacy policy, Cookies policy and Terms and Conditions prior to completing your loan application.</p>
                <p>We do not accept any responsibility for any of our partners or third party websites for any loss or damage that may arise from your use of them. Therefore, you are advised to use any of our partners or third party websites after carefully reading their Terms &amp; Conditions, Privacy &amp; Cookies Policies. We do not have any control on any content or resources for such third parties, their products or services, their websites or for any information, opinions or views given or advice provided by such third parties.</p>
                <p>To see the list of our partners, please click here <a href="/our-partners/">Our Partners</a></p>
                <h2 id="lftSide8">8. Linking to and from our Website</h2>
                <p>The following organizations may link to our website without prior written approval:</p>
                <ol>
                    <li>Government agencies;</li>
                    <li>Search engines;</li>
                    <li>News organizations;</li>
                    <li>Online directory distributors</li>
                </ol>
                <p>Other third party websites are required either expressed, implied or written approval from us to link to our website.</p>
                <p>Any links to third party websites on our websites or in our emails are provided for your information, for your interest and convenience only.</p>
                <p>Any link to our website from any third party website is controlled by such third party only. You are advised to use any of our partners or third party websites after carefully reading their Terms &amp; Conditions, Privacy &amp; Cookie Policies. We do not have any control on any content or resources for such third parties, their products or services, their websites or for any information, opinions or views given or advice provided by such third parties. We do not accept any responsibility for any of our partners or third party websites for any loss or damage that may arise from your use of them.</p>
                <h2 id="lftSide9">9. Privacy</h2>
                <p>The Company’s Privacy Policy applies to use of our website, and its terms are made a part of these Terms and conditions by this reference.</p>
                <p>For detailed information, please read our <a href="https://www.loantube.com/privacy-policy/">Privacy Policy</a>.</p>
                <h2 id="lftSide10">10. Our Liability</h2>
                <p>The material displayed on our website is provided without any guarantees, conditions or warranties as to its accuracy. To the extent permitted by law, we, our partners and third parties connected to us hereby expressly exclude:</p>
                <ul>
                    <li>All conditions, warranties and other terms which might otherwise be implied by statute, common law or the law of equity.</li>
                    <li>Any liability for any direct, indirect or consequential loss or damage incurred by any user in connection with our website or in connection with the use, inability to use, or results of the use of our website, any websites linked to it and any materials posted on it, including, without limitation any liability for loss of income or revenue; loss of business; loss of profits or contracts; loss of anticipated savings; loss of data; loss of goodwill; wasted management or office time; and for any other loss or damage of any kind, however arising and whether caused by tort (including negligence), breach of contract or otherwise, even if foreseeable, provided that this condition shall not prevent claims for loss of or damage to your tangible property or any other claims for direct financial loss that are not excluded by any of the categories set out above.</li>
                </ul>
                <p>In simpler words, we do not accept responsibility or liability for any loss or damage you may incur (whether directly or indirectly) in the following circumstances:</p>
                <ul>
                    <li>If the information you provide to us is incorrect, incomplete or misleading;</li>
                    <li>If the product or service you apply for is not appropriate for you;</li>
                    <li>As a result of any acts or omissions of Our Partners &amp; Third Party Websites regarding the product or service you are applying for, and</li>
                    <li>As a result of your use, or inability to use our website due to circumstances beyond our reasonable control.</li>
                </ul>
                <p>This does not affect our liability for death or personal injury arising from our negligence, nor our liability for fraudulent misrepresentation or misrepresentation as to a fundamental matter, nor any other liability which cannot be excluded or limited under applicable law including but not limited to the Financial Services and Markets Act 2000, as amended, (“FSMA”) or any conduct of business rules developed pursuant to FSMA.</p>
                <p>We do not give any warranty that ours’, our partners’ or third party’s websites are free from viruses or worms which may have a harmful effect on any technology or device being used while browsing through our website.</p>
                <h2 id="lftSide11">11. Indemnity</h2>
                <p>By using our website, you agree to defend, indemnify, and hold harmless our company from and against any and all losses, claims, damages, costs and expenses (including reasonable legal and accounting fees) that we may become obligated to pay arising or resulting from your use of Our Website, Our Partners’ websites &amp; Third Party’s Websites, the Content, or your breach of these Terms and conditions .</p>
                <p>We reserve the right to assume or participate, at your expense, in the investigation, settlement, and defence of any such action or claim.</p>
                <h2 id="lftSide12">12. Personal Information and User Content</h2>
                <p>Our service allows you to search &amp; compare various type of loan products provided by Our Partners. You will need to answer a number of questions on the websites in order to compare or obtain a quote for any desired product. These questions are designed to ensure that we and all relevant partners/providers have all the information necessary to deliver you with appropriate and timely information relating to the products.</p>
                <p>It is therefore very important that you answer all of the questions truthfully, completely and accurately and that you disclose all relevant facts.</p>
                <p>In case, you have provided wrong information unintentionally, we request you to send us an email at <a href="mailto:info@loantube.com">info@loantube.com</a> and we will update your corrected information with your consent.</p>
                <p>For detailed information on how we collect personal information, its usage, and all such related activities, please read our <a href="https://www.loantube.com/privacy-policy/">Privacy Policy</a>.</p>
                <p>You must take all reasonable precautions (including using appropriate virus checking software) to ensure that any information, content, material or data you provide (including User Content) is free from viruses and worms which may have a harmful effect on any part of our website or the websites of our partners &amp; third parties or any other technology.</p>
                <p>If you create any usernames and passwords when using our website, they must be kept confidential by you and must not be shared with anyone. You are solely responsible for any activity or activities undertaken on our website using your usernames and passwords. It is a sincere request to keep it safe and secured.</p>
                <h2 id="lftSide13">13. Financial Information</h2>
                <p>The information on our website is not intended to be construed as financial or other advice. It is provided to help you find the product or service that you consider the most appropriate for your circumstances. If you think you need financial advice, you should contact a registered and qualified Independent Financial Adviser (IFA).</p>
                <h2 id="lftSide14">14. Viruses, Hacking and Other Offences</h2>
                <p>You must not misuse our website by knowingly introducing viruses, trojans, worms, logic bombs or other material which is malicious or technologically harmful. You must not attempt to gain unauthorised access to our website, the server on which our website is stored or any server, computer or database connected to our website. You must not attack our website via a denial-of-service attack or a distributed denial-of service attack.</p>
                <p>By breaching this provision, you would commit a criminal offence under the Computer Misuse Act 1990. We will report any such breach to the relevant law enforcement authorities and we will co-operate with those authorities by disclosing your identity to them. In the event of such a breach, your right to use our website will cease immediately.</p>
                <p>We will not be liable for any loss or damage caused by a distributed denial-of-service attack, viruses or other technologically harmful material that may infect your computer equipment, computer programs, data or other proprietary material due to your use of our website or to your downloading of any material posted on it, or on any website linked to it.</p>
                <p>You must not establish a link from any website that is not owned by you.</p>
                <p>Our website must not be framed on any other site, nor may you create a link to any part of our website other than the home page. We reserve the right to withdraw linking permission without notice.</p>
                <p>If you wish to make any use of material on our website other than that set out above, please contact us on our contact us on any of the following methods:</p>
                <p>Email: <a href="mailto:info@loantube.com">info@loantube.com</a></p>
                <p>Telephone: 0208 088 1313</p>
                <p>Post: Tiger Lion Financial Limited, 71-75 Shelton Street, Covent Garden, London, WC2H 9JQ.</p>
                <h2 id="lftSide15">15. Age</h2>
                <p>The services and products that we provide on our website are intended for those over 18 years of age only, and information contained on our website does not amount to an invitation to clients who are under 18 to buy any services or products. All transactions for the supply of services concluded through our website are governed by the Terms and conditions .</p>
                <h2 id="lftSide16">16. Law and Jurisdiction</h2>
                <p>Your use of our website and these Terms and conditions (including any dispute or claim arising out of or in connection with our website, our partners &amp; third parties) are governed &amp; interpreted by the Laws of England and Wales whose courts have exclusive jurisdiction of any disputes that may arise under or in connection with the Terms and conditions .</p>
                <p>You agree to submit to exclusive jurisdiction if you violate or breach any Terms and conditions while accessing our website.</p>
                <p>We retain the right to bring proceedings against you for breach of these Terms and conditions in your country of residence or another relevant country.</p>
                <h2 id="lftSide17">17. General</h2>
                <p>This agreement is in English and all communications between you and us will be in English.</p>
                <p>If any provision of these terms and conditions is found to be unlawful, invalid or unenforceable, that provision shall be deemed deleted from these terms and conditions and shall not affect the validity or enforceability of the remaining terms and conditions.</p>
                <p>Our Terms and conditions, Privacy Policy and Cookie Policy, constitute the entire agreement between you and us, relating to your use of our website.</p>
                <p>No failure or delay by us in exercising any of our rights under these terms and conditions shall constitute a waiver of that right nor will any single or partial exercise by us of any right preclude any further exercise of any right.</p>
                <h2 id="lftSide18">18. List of Our Websites</h2>
                <p>We own and operate the following websites under Tiger Lion Financial Limited:</p>
                <ol>
                    <li><a href="http://www.tigerlionfinancial.co.uk">www.tigerlionfinancial.co.uk</a></li>
                    <li><a href="http://www.786loans.uk">www.786loans.uk</a></li>
                    <li><a href="http://www.oysterloan.co.uk">www.oysterloan.co.uk</a></li>
                    <li><a href="http://www.loan-broker.uk">www.loan-broker.uk</a></li>
                    <li><a href="http://www.loan-princess.uk">www.loan-princess.uk</a></li>
                    <li><a href="https://www.loantube.com">www.loantube.com</a></li>
                </ol>
                <p>You can also check us on FCA register by clicking on Tiger Lion Financial Limited.</p>
                <h2 id="lftSide19">19. Your Complaints &amp; Other Queries</h2>
                <p>We are constantly evolving and learning. Hence, we would request you to drop your feedback, suggestions to us so that we can improve our services. If you are not happy with our services, please contact us, and allow us to offer you a concrete resolution.</p>
                <p>Email: <a href="mailto:info@loantube.com">info@loantube.com</a></p>
                <p>Telephone: 0208 088 1313</p>
                <p>Post: Tiger Lion Financial Limited, 71-75 Shelton Street, Covent Garden, London, England – WC2H 9JQ, United Kingdom.</p>
                <p>We’d love to serve you!</p>
                <p>__________________________________</p>
                <p>Last Updated: July 2019</p>

            </div>
        </>
    )
}