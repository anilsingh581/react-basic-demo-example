import React from 'react'

export default () => {
    return (
        <>
           <div id="fixedLeftSidebar">
                        <h3>Content</h3>
                        <a href="#lftSide1" className="nav-link">1 : Introduction</a>
                        <a href="#lftSide2" className="nav-link">2 : Our Service</a>
                        <a href="#lftSide3" className="nav-link">3 : Changes to Terms and conditions</a>
                        <a href="#lftSide4" className="nav-link">4 : Accessing our website</a>
                        <a href="#lftSide5" className="nav-link">5 : Credit Checks & References</a>
                        <a href="#lftSide6" className="nav-link">6 : Intellectual Property</a>
                        <a href="#lftSide7" className="nav-link">7 : Our Partners & Third Party Websites</a>
                        <a href="#lftSide8" className="nav-link">8 : Linking to and from our Website</a>
                        <a href="#lftSide9" className="nav-link">9 : Privacy</a>
                        <a href="#lftSide10" className="nav-link">10 : Our Liability</a>
                        <a href="#lftSide11" className="nav-link">11 : Indemnity</a>
                        <a href="#lftSide12" className="nav-link">12 : Personal Information and User Content</a>
                        <a href="#lftSide13" className="nav-link">13 : Financial Information</a>
                        <a href="#lftSide14" className="nav-link">14 : Viruses, Hacking and Other Offences</a>
                        <a href="#lftSide15" className="nav-link">15 : Age</a>
                        <a href="#lftSide16" className="nav-link">16 : Law and Jurisdiction</a>
                        <a href="#lftSide17" className="nav-link">17 : General</a>
                        <a href="#lftSide18" className="nav-link">18 : List of our websites</a>
                        <a href="#lftSide19" className="nav-link">19 : Your Complaints & Other Queries</a>
                    </div>
        </>
    )
}