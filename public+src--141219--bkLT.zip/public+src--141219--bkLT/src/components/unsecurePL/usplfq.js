import React from 'react'

export default () => {
    return(
        <>
            <div className="accordion" id="accordionBefore">
                                    <div className="card">
                                      <div id="headingOne">
                                        <h2 className="mb-0" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                          What should my minimum age while applying for a loan?
                                        </h2>
                                      </div>
                                      <div id="collapseOne" className="collapse show" aria-labelledby="headingOne" data-parent="#accordionBefore">
                                        <div className="card-body">
                                          Our lenders lend only to customers who are aged 18 or above.
                                        </div>
                                      </div>
                                    </div>
                                    <div className="card">
                                      <div id="headingTwo">
                                        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                          Do I need an active employment status?
                                        </h2>
                                      </div>
                                      <div id="collapseTwo" className="collapse" aria-labelledby="headingTwo" data-parent="#accordionBefore">
                                        <div className="card-body">
                                          Yes, it is preferred by lenders. You need to be in a permanent and paid employment. If you are unemployed, you may not be able to pass the lender’s affordability assessments. The exception is if you have other good sources of incomes like rental income and you can convince lenders that you can afford to pay the loan with those other incomes.
                                        </div>
                                      </div>
                                    </div>
                                    <div className="card">
                                        <div id="headingThree">
                                          <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                            I am bankrupt / I am in an Individual Voluntary Arrangement (IVA) / I am in a debt management arrangement. Can I apply?
                                          </h2>
                                        </div>
                                        <div id="collapseThree" className="collapse" aria-labelledby="headingThree" data-parent="#accordionBefore">
                                          <div className="card-body">
                                            People on IVA, Debt Management Plan and on Bankruptcy are considered as negative customers by lenders. It is a sign that you can’t really manage your finances. Due to this, we are very sure we won’t be able to find you a loan if you are on IVA or Debt Management Plan or have filed a bankruptcy in past.
                                          </div>
                                        </div>
                                      </div>
                                    <div className="card">
                                        <div id="headingFour">
                                          <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                            What information will you ask me when I apply?
                                          </h2>
                                        </div>
                                        <div id="collapseFour" className="collapse" aria-labelledby="headingFour" data-parent="#accordionBefore">
                                          <div className="card-body">
                                            We will need to know how much you earn annually, your monthly outgoings, employment details, where you’re living and what is your residential status.
                                          </div>
                                        </div>
                                      </div>
                                      
                                    <div className="card">
                                        <div id="headingFive">
                                          <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                            Do I need to provide a guarantor for this loan?
                                          </h2>
                                        </div>
                                        <div id="collapseFive" className="collapse" aria-labelledby="headingFive" data-parent="#accordionBefore">
                                          <div className="card-body">
                                            No, you do not.
                                          </div>
                                        </div>
                                      </div>
                                      
                                    <div className="card">
                                        <div id="headingSix">
                                          <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                                            How long will I have to wait for an answer?
                                          </h2>
                                        </div>
                                        <div id="collapseSix" className="collapse" aria-labelledby="headingSix" data-parent="#accordionBefore">
                                          <div className="card-body">
                                            It depends. If we have all the information we and our lenders need, a “yes or a no” answer from lenders who are willing to lend you and the quotes/APRs they want to offer you will be displayed on your screen on a real-time basis.
                                          </div>
                                        </div>
                                      </div>
                                      <div className="card">
                                          <div id="headingSeven">
                                            <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                                              Are you licensed to lend me money?
                                            </h2>
                                          </div>
                                          <div id="collapseSeven" className="collapse" aria-labelledby="headingSeven" data-parent="#accordionBefore">
                                            <div className="card-body">
                                              LoanTube doesn’t lend you the money- we’re a credit broker and not a lender. As a credit broker, we act as a bridge between lenders and borrowers. We connect you with the lenders (all licensed by the Financial Conduct Authority) who will consider your loan application. Applying through LoanTube means you don’t have to submit dozens of applications individually to each lender to get your loan decision.
                                            </div>
                                          </div>
                                        </div>
                                        <div className="card">
                                            <div id="headingEight">
                                              <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
                                                How do you know which companies will lend me money and which ones will not?                                            
                                              </h2>
                                            </div>
                                            <div id="collapseEight" className="collapse" aria-labelledby="headingEight" data-parent="#accordionBefore">
                                              <div className="card-body">
                                                When we become partners with a lender, one of the first things they do is to send us a list of the types of borrowers they would like to work with. You might be just the type of borrower one lender is looking for but another might not consider you. Our job is to pair you with the right lenders based on the information you give us.
                                              </div>
                                            </div>
                                          </div>
                                          <div className="card">
                                              <div id="headingNine">
                                                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
                                                  Does that make my loan more expensive? Will I have to pay a higher rate of interest? Will I have to pay LoanTube?
                                                </h2>
                                              </div>
                                              <div id="collapseNine" className="collapse" aria-labelledby="headingNine" data-parent="#accordionBefore">
                                                <div className="card-body">
                                                  No – to all three questions. You do not pay LoanTube anything for applying and the cost of your loan does not go up. If you’re approved, you’ll pay the lender exactly what you’d have paid them had you approached them directly.
                                                </div>
                                              </div>
                                            </div>
                                            <div className="card">
                                                <div id="headingTen">
                                                  <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
                                                    Will you run a credit check on my report?
                                                  </h2>
                                                </div>
                                                <div id="collapseTen" className="collapse" aria-labelledby="headingTen" data-parent="#accordionBefore">
                                                  <div className="card-body">
                                                    When we’re searching around for the best deal for you, we only carry out a soft credit check. Soft credit checks have no effect at all on your credit score. By carrying out the soft check, it gives us a better idea of which lender to propose your personal loan to because, when they make a decision, they consider both what’s on your application and what’s in your credit report.
                                                  </div>
                                                </div>
                                              </div>
                                              <div className="card">
                                                <div id="headingEve">
                                                  <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseEve" aria-expanded="false" aria-controls="collapseEve">
                                                    If I get an offer, do I have to take the loan?
                                                  </h2>
                                                </div>
                                                <div id="collapseEve" className="collapse" aria-labelledby="headingEve" data-parent="#accordionBefore">
                                                  <div className="card-body">
                                                    No. You’re never under any obligation to accept an offer that you receive from LoanTube. Even if we say “yes” then you turn around and tell us “no”, there’s no charge for our service.
                                                  </div>
                                                </div>
                                              </div>
                                  </div>
        </>
    )
}