import React from 'react'
const images = require.context('../../assets/images')

export default () => {
    return (
        <>
            <h4>Unsecured personal loans are flexible type of finance and three major benefits of this are:</h4>
            <div className="threeText"><div className="threeimg"><img src={images('./unsec31.png')} alt="Unsecured Personal Loans" /></div>
            <div>You do not need to have a perfect credit record for a lender to offer you an <a href="unsecured-personal-loans-guide.html">unsecured personal loan</a>. LoanTube works with multiple lenders, some of them may focus on your current situation rather than on any missed payments that might be on your credit record from three years ago.*</div></div>
            <div className="threeText"><div className="threeimg"><img src={images('./unsec32.png')} alt="Unsecured Personal Loans" /></div><div>You don’t have to be a big earner to be considered for an unsecured personal loan. If you earn enough and you think you can afford to repay the monthly instalments, you’re welcome to apply. We’d love to process your application.</div></div>
            <div className="threeText"><div className="threeimg"><img src={images('./unsec33.png')} alt="Unsecured Personal Loans" /></div><div>No collateral or security is required for unsecured personal loans which means you can apply for it irrespective of your residential status. Tenants & Home Owners both are equally eligible for it.</div></div>
        </>
    )
}