import React from 'react'

export default (props) =>
    <section className={props.cls}>
        <div className="container">
            <div className="row">
                <div className="col">
                    {props.children}
                </div>
            </div>
        </div>
    </section>
