import React from 'react'
const images = require.context('../../assets/images')

export default () => 
        <>
            <div className="brdCenterText">If you have multiple debts in different places, a debt consolidation loan could be for you. If you’ve multiple monthly repayments, it may help you save money in the long run by lowering the interest rate you are paying. Lenders can offer a new personal loan to repay all or most, outstanding debts through a single monthly repayment. This means you can move all of your debts from a variety of locations into one place. Three key things to know about Debt Consolidation Loans:</div>
                            <div className="threeText"><div className="threeimg"><img src={images('./Holiday31.png')} alt="holiday loan" /></div>
                            <div>Generally, interest rates for this sort of loan are lower, the more you borrow. This could mean that you end up paying less interest than on all of your other debts combined.</div></div>
                            <div className="threeText"><div className="threeimg"><img src={images('./Holiday32.png')} alt="holiday loan" /></div><div>There are two types of debt consolidation loans – Secured and Unsecured. If you opt for a secured debt consolidation loan the amount you borrow is secured against an asset, usually your home. This may be offered by lenders if you owe a significant amount of money or if you have a poor credit history.</div></div>
                            <div className="threeText"><div className="threeimg"><img src={images('./Holiday33.png')} alt="holiday loan" /></div><div>You can lower your monthly repayments by spreading the debt over a longer period. This works well when consolidating short-term debts such as payday loans.</div></div>
        </>
    