import React from 'react'

export default () =>
    <div className="accordion" id="accordionBefore">
        <div className="card">
            <div id="headingOne">
                <h2 className="mb-0" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                    What loans and debts can be consolidated?
                                </h2>
            </div>
            <div id="collapseOne" className="collapse show" aria-labelledby="headingOne" data-parent="#accordionBefore">
                <div className="card-body">
                    Different lenders will have different criteria in relation to which loans can and can’t be consolidated. Generally, things like credit cards, store cards and personal loans can be consolidated into one loan.
                                </div>
            </div>
        </div>
        <div className="card">
            <div id="headingTwo">
                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                    Will I have only one monthly repayment?
                                </h2>
            </div>
            <div id="collapseTwo" className="collapse" aria-labelledby="headingTwo" data-parent="#accordionBefore">
                <div className="card-body">
                    If you manage to pay off all other debts with the debt consolidation loan, then yes, you will have one manageable monthly repayment. If, however, you still have debt from other sources after the consolidation loan, you will still have existing monthly
                    repayments as well as the consolidation debt.
                                </div>
            </div>
        </div>
        <div className="card">
            <div id="headingThree">
                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                    Is there an early repayment charge?
                                </h2>
            </div>
            <div id="collapseThree" className="collapse" aria-labelledby="headingThree" data-parent="#accordionBefore">
                <div className="card-body">
                    Many of the lenders we work with do have an early repayment charge on debt consolidation loans. An example of this may be a 28 days’ notice period, with an additional 30 days interest on the debt that is owed. Each lender is different, however, and it
                    is worth reading through the terms and conditions of the specific loan before agreeing to it.
                                </div>
            </div>
        </div>
        <div className="card">
            <div id="headingFour">
                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                    Can debt consolidation save me money?
                                </h2>
            </div>
            <div id="collapseFour" className="collapse" aria-labelledby="headingFour" data-parent="#accordionBefore">
                <div className="card-body">
                    In short, yes, debt consolidation can save money for those with multiple debts in various places. This is not guaranteed, but it does happen very often. This is due to consolidating all of your monthly repayments into one manageable repayment every month,
                    meaning you may end up paying back less each month.
                                    <br />These types of loans often have lower interest rates than those of credit cards or payday loans. This means you may also end up paying less interest each month.
                                </div>
            </div>
        </div>

        <div className="card">
            <div id="headingFive">
                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                    Is debt consolidation guaranteed to get me out of debt?
                                </h2>
            </div>
            <div id="collapseFive" className="collapse" aria-labelledby="headingFive" data-parent="#accordionBefore">
                <div className="card-body">
                    No, this sort of loan isn’t guaranteed to get you out of debt and you shouldn’t believe anyone that says otherwise. Debt consolidation loans do make getting out of debt a lot easier, but it is down to you to get yourself out of debt by keeping up with
                    the repayments. If you can keep on top of the monthly repayments, then a debt consolidation loan can help you on the way to becoming debt-free.
                                </div>
            </div>
        </div>

        <div className="card">
            <div id="headingSix">
                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                    What should my minimum age while applying for a debt consolidation loan?
                                </h2>
            </div>
            <div id="collapseSix" className="collapse" aria-labelledby="headingSix" data-parent="#accordionBefore">
                <div className="card-body">
                    Our lenders lend only to customers who are aged 18 or above.
                                </div>
            </div>
        </div>
        <div className="card">
            <div id="headingSeven">
                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                    How do you know which companies will lend me money and which ones will not?
                                </h2>
            </div>
            <div id="collapseSeven" className="collapse" aria-labelledby="headingSeven" data-parent="#accordionBefore">
                <div className="card-body">
                    LoanTube works with lenders and helps match them up with their perfect borrower. Some of these lenders might not consider you, while others might think you are the ideal customer. It is our job to pair you with the right lenders based on the information
                    you give us.
                                </div>
            </div>
        </div>
        <div className="card">
            <div id="headingEight">
                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
                    If I get an offer, do I have to take the loan?
                                </h2>
            </div>
            <div id="collapseEight" className="collapse" aria-labelledby="headingEight" data-parent="#accordionBefore">
                <div className="card-body">
                    No. You’re never under any obligation to accept an offer that you receive from LoanTube. Even if we say “yes” then you turn around and tell us “no”, there’s no charge for our service.
                                </div>
            </div>
        </div>
        <div className="card">
            <div id="headingNine">
                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
                    Are you licensed to lend me money?
                                </h2>
            </div>
            <div id="collapseNine" className="collapse" aria-labelledby="headingNine" data-parent="#accordionBefore">
                <div className="card-body">
                    LoanTube doesn’t lend you the money- we’re a credit broker and not a lender. As a credit broker, we act as a bridge between lenders and borrowers. We connect you with the lenders (all licensed by the Financial Conduct Authority) who will consider your
                    loan application. Applying through LoanTube means you don’t have to submit dozens of applications individually to each lender to get your loan decision.
                                </div>
            </div>
        </div>
    </div>