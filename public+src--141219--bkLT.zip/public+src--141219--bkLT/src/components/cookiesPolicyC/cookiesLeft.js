import React from 'react'

export default () => {
    return (
        <>
            <div id="fixedLeftSidebar">
                        <h3>Content</h3>
                            <a href="#lftSide1" className="nav-link">1 : What is a cookie?</a>
                            <a href="#lftSide2" className="nav-link">2 : What’s in a cookie?</a>
                            <a href="#lftSide3" className="nav-link">3 : How do we use a cookie?</a>
                            <a href="#lftSide4" className="nav-link">4 : Different types of cookie</a>
                            <a href="#lftSide5" className="nav-link">5 : Usability and Deletion</a>
                            <a href="#lftSide6" className="nav-link">6 : List of our websites</a>
                    </div>
        </>
    )
}