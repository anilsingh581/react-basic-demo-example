import React from 'react'

export default () => {
    return (
        <>
            <div id="rightSideCookies">
                                <p>A satisfied customer is the best source of advertisement, said by G.S. Alag. And we entirely believe in this ideology. To enhance your browsing experience while using our Site, we use cookies.</p>
                                <h2 id="lftSide1">1. What is a cookie?</h2>
                                <p>Oh! We love chocolate chip cookies with honey all over it. Wait? Are we discussing the policy regarding HTTP Cookie?</p>
                                <p>In technical terms, a cookie is a small piece of data sent from a website and is stored on the user’s device (it may be a computer, laptop, or a smartphone) by the web browser a user is using. This allows a server to deliver a tailored page to a particular user. We will simplify it for you (as we believe in simplification, right from loans to everything we deal with). Like many services, we use cookies, to remember things about you so that we can provide you with a better experience.</p>
                                <p>These cookies allow us to distinguish you from other visitors to our website which helps us to provide a personalised experience.</p>
                                <h2 id="lftSide2">2. What’s in a cookie?</h2>
                                <p>Um, we haven’t baked one recently. But we know that a cookie needs graham crackers, sour cream, dried cranberries, cornflakes, ground coffee, milk, cheese and a lot of chocolate chip sprinkles. Yum. No? uh-oh! HTTP Cookie? Okay, let’s get back to the business.</p>
                                <p>An HTTP Cookie contains a string of texts that has information about the browser. Each cookie is effectively a small lookup table containing pairs of values. Once the cookie has been read by the code on the server or client computer, the data can be retrieved and used to customise the web page appropriately.</p>
                                <h2 id="lftSide3"> 3. How do we use a cookie?</h2>
                                <p>We use cookies to identify your browser so we can tailor your browsing experience and keep track of how you use this website and our other websites (mentioned at the end of this page) so that we can improve our services. Also, we require cookies to remember your preferences, maintain authentication and security, enhance service features and performance, research and analytics, and for advertising purpose.</p>
                                <p>Let’s consider the below-mentioned example:</p>
                                <p>A cookie of a shopping cart in an online shop. The online store remembers the articles that a customer has placed in the virtual shopping cart via a cookie. And when the customer finishes the shopping, he can usually check his cart virtually, select and deselect items and proceed.</p>
                                <p>See, it makes jobs of both the customers and the service provider easier and saves a great deal of time which one can invest in munching on a cookie (we are going mad over cookies now).</p>
                                <p>No, we don’t stalk you. Because these small files are required to provide you with the best user experience and also tells us which pages you find most interesting (anonymously). Isn’t that just great?</p>
                                <p>Mostly, people freak out about cookies. But they are not harmful. You know, you can always trust us. We are here to take you out of your problems, and we do so at each and every step. A promise is a promise.</p>
                                <h2 id="lftSide4"> 4. Different types of cookie</h2>
                                <p>We have categorised our cookies into four (4) different sections based on their usage and functionality. The cookies we use may change over the period of time. Any revision in policy will be updated because we don’t want you to miss out on anything.</p>
                                <h3>Firmly Essential Cookies</h3>
                                <p>These cookies are quintessential as it enables you to browse through our website and use different features available on it. You will not be able to use certain features of our website if you disable these cookies.</p>
                                <p>And yes, Milk and Belgian Chocolate cookies are also essential for our existence. Without them, we may not function.</p>
                                <h3>Performance Cookies or Analytics Cookies</h3>
                                <p>As the name suggests, these cookies are used to optimize the performance of the services we provide. The cookies involved in this section collect information about website usage patterns and trends. This will help us to understand your browsing behaviour and will allow us to optimize it further to make it easier for you.</p>
                                <p>Co-founder of Google, Sergey Brin said, “We want Google to be the third half of your brain”. And it has developed some of the most essential tools for the development of the human race. Google Analytics is one of them.</p>
                                <p><b>Did you know?</b></p>
                                <p>Sergey Brin’s actual name is Sergey Mikhaylovich Brin who is an American computer scientist and internet entrepreneur. He is the President of Google’s parent company Alphabet Inc.</p>
                                <p>Google Analytics is a web analytics service of the Google LLC, 1600 Amphitheatre Parkway, Mountain View, CA 94043-1351, United States. Via this technology, we collect and analyse data about our visitor’s behaviour. The data collected is anonymous and we use it for the optimization of our website.</p>
                                <p>We use the function anonymizeIP, which anonymizes your IP-address before the data is transferred to Google’s servers in the United States of America.</p>
                                <p>By setting the cookie, Google may analyse the use of our website. Therefore, Google gains knowledge of information, such as the access time, the location from which the site was accessed and the frequency of visits to our website by the data subject. With each visit to our website, data will be transmitted to Google in the USA. Google may store and pass these personal data collected through the technical procedure on to third parties.</p>
                                <p><em>Please note: Performance cookies DO NOT collect information that identifies you. And information collected by these cookies is anonymous. </em></p>
                                <h3>Functionality Cookies</h3>
                                <p>Functionality Cookies help us to remember your settings, preferences, and all such relevant choices that you make during your browsing experience. In order to make your experience completely exceptional and user-friendly, these cookies are important.</p>
                                <h3>Marketing and Advertising Cookies</h3>
                                <p>The last cookie on our plate is this one. This time we are talking about an HTTP Cookie only. Because our team can never run out of cookies. Thanks to <a href="https://www.linkedin.com/in/gurprit-singh-gujral-a140a820/">Gurprit</a>.</p>
                                <p>We use re-marketing cookies via Google to serve more relevant adverts on third-party sites to users that have visited our site in the past.</p>
                                <p>If you wish to opt out of re-marketing, please visit <a href="http://www.google.com/ads/preferences/">http://www.google.com/ads/preferences/</a> on Google and change the settings of your ad preferences, as per your convenience.</p>
                                <h2 id="lftSide5">5. Usability and Deletion</h2>
                                <p>Cookies are necessary as it allows us to improve the website and performance. Disabling them may restrict you from using certain parts of the website. But if you are still considering to disable these small files, manage your preferences in the browser and “block cookies” in the privacy pane.</p>
                                <p>But, we just love cookies! (Pun intended)</p>
                                <h2 id="lftSide6"> 6. List of our websites owned &amp; operated by Tiger Lion Financial Limited:</h2>
                                <ol>
                                  <li><a href="http://www.tigerlionfinancial.co.uk">www.tigerlionfinancial.co.uk</a></li>
                                  <li><a href="http://www.786loans.uk">www.786loans.uk</a></li>
                                  <li><a href="http://www.oysterloan.co.uk">www.oysterloan.co.uk</a></li>
                                  <li><a href="http://www.loan-broker.uk">www.loan-broker.uk</a></li>
                                  <li><a href="http://www.loan-princess.uk">www.loan-princess.uk</a></li>
                                  <li><a href="https://www.loantube.com">www.loantube.com</a></li>
                                </ol>
                                <p>You can also check us on FCA register by clicking on <a href="https://register.fca.org.uk/ShPo_FirmDetailsPage?id=001b000003RFLpvAAH">Tiger Lion Financial Limited</a>.</p>
                                <p>________________</p>
                                <p>Last Updated: June 2019</p>
                              </div>
        </>
    )
}