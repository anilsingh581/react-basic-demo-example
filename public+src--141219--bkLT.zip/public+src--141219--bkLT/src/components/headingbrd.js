import React from 'react'

export default (props) => 
    <>
        <div className="headingAll">{props.children}</div>
        <div className="brdCenter"></div>           
    </>