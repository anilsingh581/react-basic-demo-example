import React from 'react'

export default () => {
    return (
        <>
            <div id="fixedLeftSidebar">
                        <h3>Content</h3>
                        <a href="#lftSide1" className="nav-link">1 : What is LoanTube?</a>
                        <a href="#lftSide2" className="nav-link">2 : It’s Services</a>
                        <a href="#lftSide3" className="nav-link">3 : Contact Us</a>
                        <a href="#lftSide4" className="nav-link">4 : What is a Privacy Policy</a>
                        <a href="#lftSide5" className="nav-link">5 : How your Personal Information is Collected</a>
                        <a href="#lftSide6" className="nav-link">6 : Information LoanTube Collects</a>
                        <a href="#lftSide7" className="nav-link">7 : Usage of Collected Information</a>
                        <a href="#lftSide8" className="nav-link">8 : Information Retention</a>
                        <a href="#lftSide9" className="nav-link">9 : Third-party Data Disclosure Policy</a>
                        <a href="#lftSide10" className="nav-link">10 : Is your personal information ever transferred outside of EEA</a>
                        <a href="#lftSide11" className="nav-link">11 : Cookie Policy</a>
                        <a href="#lftSide12" className="nav-link">12 : How do we keep your Information secure?</a>
                        <a href="#lftSide13" className="nav-link">13 : Your Legal Rights</a>
                        <a href="#lftSide14" className="nav-link">14 : Details of Data Protection Officer (DPO) for Complaints & Concerns</a>
                        <a href="#lftSide15" className="nav-link">15 : Revision of the Policy</a>
                    </div>
        </>
    )
}