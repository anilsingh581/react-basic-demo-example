import React from 'react'

export default () => {
    return (
        <>
            <div id="rightSideCookies">
                        <p>LoanTube is resolute and earnest to your privacy. Because at the end of the day, we know, everyone is a customer, even we are. We also face issues with a few products or services and it feels really bad when the policies are not transparent. We don’t want to give this feeling to anyone dealing with us. Our mission is to spread smiles and happiness everywhere on this planet Earth. And we ensure you that we will do our level best to put that smile on your face.</p>
                        <p>This Privacy Policy will give you an idea of what, why and how we collect, disclose, store, transfer and use your information.</p>
                        <p>Learn how transparent we are because for us, YOU are the priority. Without you, we do not exist. And, we really mean it.</p>
                        <p><b>Important Information</b>: In compiling this Policy, we have taken steps to ensure we have integrated the standards and principles outlined in data collection and privacy frameworks, including the European Union’s General Data Protection Regulation (“GDPR”).</p>
                        <h2 id="lftSide1">1. What is LoanTube?</h2>
                        <p>LoanTube is a trading style of Tiger Lion Financial Limited. Tiger Lion Financial Limited is based in London as a credit broker. There are a few important information about us which we will simplify and write in bullet points for an easy read. We have a lot of missions, one among them is a simplification. We are already making loans simplified, but apart from services, there are other things too. We will take care of everything.</p>
                        <ul>
                          <li>Our registered office address is 71-75 Shelton Street, Covent Garden, London, WC2H 9JQ.</li>
                          <li>We are authorised and regulated by the financial regulatory body of UK which is Financial Conduct Authority, usually called as FCA. Our FCA Firm Reference Number is 753151.</li>
                          <li>We are also registered with the Information Commissioners Office and our registration number is ZA185613.</li>
                          <li>We are registered in England &amp; Wales and our Company Number is 10189367.</li>
                        </ul>
                        <p>See, it was easy. Right? We told you, we will make it easier. Now you have all the necessary information about us. Technically, it was an introduction. If you are still reading on, then we would like to convey that we are glad to meet you (even though virtually). What do we do? We are a bunch of simple people with a common interest, that is, to make this world a better place.</p>
                        <p>Moreover, we also carry out the business of credit brokerage in the United Kingdom. Our Company does not provide any loans or make any credit decisions. We are easy people, dealings with us is much easier than it seems.</p>
                        <p>We forgot to tell you! This policy should be read in conjunction with our Terms and conditions into which this Policy is incorporated by reference.</p>
                        <h2 id="lftSide2">2. It’s Services</h2>
                        <p>LoanTube is one-of-a-kind loan brokering firm which operates in the United Kingdom. By calling ourselves “one-of-a-kind”, we mean it (we are not being repetitive here, but we are just ringing a bell). Now, you must be thinking that why are we claiming to be different? You’ve hit the bull’s eye. Everything about us is different in its own way. Right from the website, its content, and the services we offer.</p>
                        <p>We do not operate like other loan comparison sites. Here at LoanTube, we place paramount importance in maintaining transparency and your trust. You are more valuable to us, <a href="https://www.linkedin.com/in/gurprit-singh-gujral-a140a820/">Gurprit</a> has already told you about the <a href="about-us.html">ideology</a> that made him started this evolution.</p>
                        <p>LoanTube compares actual APRs (Annual Percentage Rate) and monthly repayments to ensure that you are not opting for any loan under a deception. This real-time loans comparison marketplace has a proprietary loan matching engine which connects the right borrower with the right lender.</p>
                        <p>In short, <strong>what you see on our website is what you get in real</strong>. Because we are real and our ethics don’t allow us to deceive our customers.</p>
                        <p>Do you need to know more? Please don’t hesitate from checking our <a href="terms-and-conditions.html">Terms and Conditions </a> and <a href="about-us.html">About Us</a> for more information.</p>
                        <h2 id="lftSide3">3. Contact Us</h2>
                        <p>We would be more than happy to help and assist you regarding your queries. We have listed down various ways by which you can reach out to us:</p>
                        <ol>
                          <li><em>Email: <a href="mailto:info@loantube.com">info@loantube.com</a> </em></li>
                          <li><em>Ring a Bell: 0208 088 1313</em></li>
                        </ol>
                        <p><em>Love Vintage? Here’s our postal address: 71-75 Shelton Street, Covent Garden, London, WC2H 9JQ.</em></p>
                        <h2 id="lftSide4">4. What is a Privacy Policy</h2>
                        <p>Before going through the whole Privacy Policy, we would like to educate and inform our users to understand the meaning and role of this policy. We are real people who are trying to help out those who are in need. And for that, we need to make sure that everything that goes on our website has an explanation. A human explanation which is easy to understand and go through.</p>
                        <p>A Privacy Policy is a legal statement that discloses all of the ways a company or an organization accumulate, discloses, manages and uses a customer’s data. When you share your personal information with us, you do it with a certain amount of trust. We don’t want to lose you or your trust. Hence, we will explain how we are safeguarding your personal information.</p>
                        <p>Besides, the right to privacy is a highly developed area of law in Europe. GDPR imposes stringent rules on the collection of personal information belonging to EU residents, including a requirement for privacy policies to be more concise, clearly-worded, and transparent in their disclosure of any collection, processing, storage, or transfer of <a href="https://en.wikipedia.org/wiki/Personally_identifiable_information">personally identifiable information</a>.</p>
                        <p>We hope that you will not face any problems in understanding our Privacy Policy and even if you face issues with it, don’t hesitate to speak to us. We will be happy to hear your voice and assist you.</p>
                        <h2 id="lftSide5">5. How your Personal Information is Collected</h2>
                        <p>Personally identifiable information can be used on its own or with other information to identify, contact, or locate a single person, or to identify an individual in context.</p>
                        <p>Easier Version of the above definition: Personal information is data that can be used to identify or contact a single person.</p>
                        <p>We may collect your personal information directly from you or via your use of our services.</p>
                        <ul>
                          <li>We may collect your personal information when you complete the online form available on our website.</li>
                          <li>We may collect information when you contact or reach out to us by the modes of communication available for your convenience.</li>
                          <li>We may collect information through Our Partners which includes Credit Bureaus, Third party data providers, Banks, brokers, lenders, advertisement networks, introducers, affiliates and others.</li>
                          <li>We also collect data through automated technologies such as Cookies. Please don’t miss to taste our <a href="cookies-policy.html">Cookie Policy</a><i>.</i> Sorry, read our Cookie Policy. Such data about your device that you use to browse through our website, your browsing pattern, and actions.</li>
                          <li>In case, you are required to or you are providing data of another individual, we request you to ask them to go through all our policies which include Terms and Conditions , Use of Cookies and Privacy Policy (these are not boring, we have made these interesting just for YOU).</li>
                          <li>By providing us with information about any other individual, you indicate that the individual has given you their explicit consent for the same.</li>
                        </ul>
                        <p>All the data we collect from you are always in compliance to the following legal requirements under the GDPR:</p>
                        <ul>
                          <li>Article 6 (1) (a) – Consent of the data subject</li>
                          <li>Article 6 (1) (b) – Processing is necessary for the performance of a contract with the data subject or to take steps to enter into a contract</li>
                          <li>Article 6 (1)( c) – Our Legal Obligations</li>
                          <li>Article 6(1) (f) – Our Legitimate Interest</li>
                        </ul>
                        <h2 id="lftSide6">6. Information LoanTube Collects</h2>
                        <p>We sincerely request our users to provide us with the exact and accurate information, as this would be helpful for us to offer you a suitable loan. It is essential that personal information is accurate and kept up to date at all times to effectively conduct our business activities. Please contact us at any time to update your personal information, or to advise us that information held by us is inaccurate or incomplete.</p>
                        <p>Following is the list of information collected by us for You, Your Financial Associate and People Linked to you in any way:</p>
                        <h3>Communication or Contact Related</h3>
                        <p>The first and most basic requirement is a point of contact. So, it includes your address (office or home), email address, contact number. Details in an address include House Number, Country, State or City, Postcode of Residence.</p>
                        <h3>Credit Related</h3>
                        <p>This part of information would help us to carry out our search to present the best deals available for you on LoanTube. It includes monthly/annual income and spends, loan amount required by you, the purpose of the loan and the time period for loan borrowing.</p>
                        <h3>Employment Related</h3>
                        <p>We also need to know where you work, your work profile and all similar information. This helps us in maintaining transparency. This includes employment status (if employed), monthly income, the name of your employer, an estimated amount of income per month (if self-employed).</p>
                        <h4>Identity Related</h4>
                        <p>Let’s know each other. You already know who we are and what we do. We would also be glad to know about you. This information includes your name (first and last), date of birth, age, gender, marital status. Don’t worry, we don’t discriminate. We see all with the same eye and we treat everyone equally. God sees us all equally, so do we.</p>
                        <h4>Marketing Related</h4>
                        <p>This includes your preferences in receiving any marketing information, newsletters, promotional emails, or any similar information that speaks about our services.</p>
                        <h4>Tech Related</h4>
                        <p>For a detailed explanation, please visit our <a href="cookies-policy.html">Cookie Policy</a>. But here, we will explain it to you in short. This includes your online identifiers such as Internet Protocol address, the browser you are using, the source of inquiry, full Uniform Resource Locators (URL) clickstream to, through and from our site, download errors (if any), page interaction information, the search term you have used, etc. This helps us in making your LoanTube experience better and better.</p>
                        <h2 id="lftSide7">7. Usage of Collected Information</h2>
                        <p>We will only collect personal information which is reasonably necessary for, or directly related to, the functioning of our services.</p>
                        <p>The information collected is for the purposes of assessing your application for a loan, establishing your identity, contacting you, managing our risk and to comply with our legal obligations.</p>
                        <ul>
                          <li>We may collect your personal information for the purposes of direct marketing and managing our relationship with you. Improvements in technology also enable us to collect and use the information to get a more integrated view of our customers.</li>
                          <li>We may also process your personal information for the purposes described in thisPrivacy Policy with your consent, for compliance with a legal obligation to which LoanTube is subject or when we have assessed it is necessary for the purposes of the legitimate interests pursued by us or a third party to whom it may be necessary to disclose information.</li>
                          <li>We may also use personal information for internal purposes such as auditing, data analysis, and research to improve our services, and customer communications.</li>
                          <li>From time to time, we may use your personal information to send important notices, such as communications about changes to our terms, conditions, quotations, reviews, feedback, and policies. Because this information is important to your interaction with us, you may not opt out of receiving these communications.</li>
                          <li>Information collected may be used to manage, improve and safeguard our business and this website which includes data analysis, testing, system maintenance, research, support, reporting and hosting of data.</li>
                          <li>Personal Information would help us to create and develop advertisements to you about our services and send you information about our services, any latest update. If you do not wish to receive marketing information, you may at any time decline to receive such information by calling us on 0208 088 1313 or by writing to us at <a href="mailto:info@loantube.com">info@loantube.com</a>.</li>
                        </ul>
                        <ul>
                          <li>Your personal information may be used in answering questions and responding to your requests with an intention to resolve your query/ies.</li>
                        </ul>
                        <h2 id="lftSide8">8. Information Retention</h2>
                        <p>We keep Personal Information obtained about you as set out in this Privacy Policy for no longer than six (6) years after you last used LoanTube website or until you request us to delete it.</p>
                        <p>After the expiration of that period, the corresponding data is routinely deleted, as long as it is no longer necessary for the fulfillment of the purposes outlined in this Privacy Policy for which we obtained your Personal information or if we aren’t required or permitted by law to store it for a longer period.</p>
                        <p>Please note that if you ask us to delete your personal information before then our routine deletion period, it may still remain on our backup systems for only legal or other regulatory reasons.</p>
                        <h2 id="lftSide9">9. Third-party Data Disclosure Policy</h2>
                        <p>When you use our service(s), your information will be shared with the following third parties:</p>
                        <ul>
                          <li><b>Our Partners </b>who will help us to help you find the real rates/actual rates for the financial product or service you have asked us to help you find. Our partners comprise of a panel of lenders, Credit Bureaus, banks, brokers, introducers, affiliates &amp; other data providers who are authorised and regulated by the Financial Conduct Authority to render their services. Our partners also include our other group websites with other trading names mentioned at the end of the page.<br/>
                            To see the list of our partners, please click here <a href="our-partners.html">Our Partners</a></li>
                          <li><b>Other Companies</b> who enable us to provide our services, for example, IT Service Providers (who provide for e.g. technology platforms or other IT services including data storage), and communication providers (who provide for e.g. email and text services for customer contact verification and marketing purposes).</li>
                          <li><b>Advertising Networks and Social Media</b> companies such as Facebook, Google, Instagram, LinkedIn, Twitter, and YouTube so that we can present you with relevant advertisements.</li>
                          <li>In order to facilitate our services, we may need to let them process your personal information. We will make sure that they keep the information secure and in accordance with our instructions, the General Data Protection Regulation 2016 (“GDPR”) and other UK privacy legislation.</li>
                          <li>We may also share your personal information with your consent, or where we are obliged to do so for a legal or regulatory reason, for e.g. to prevent or detect crime, for compliance monitoring or to enforce or apply our Terms and conditions and other such agreements.</li>
                          <li>Also, we may share your personal information with any third parties to whom we may choose to sell, transfer, or merge parts of our business or our assets.</li>
                        </ul>
                        <ul>
                          <li>Alternatively, we may seek to acquire other businesses or merge with them. If a change happens to our business, then the new owners may use your personal information in the same way as set out in this privacy policy.</li>
                        </ul>
                        <h2 id="lftSide10">10. Is your personal information ever transferred outside of EEA</h2>
                        <p>We generally do not permit any of our external third-party suppliers to transfer and store customer data outside of the EEA. Some of our third-party suppliers may have a presence outside of EEA or their data processors may be based outside of EEA. Where this is the case and we are made aware of this, we will take all steps reasonably necessary to ascertain and seek assurance from any such third party that your data will be treated securely and provided no less security and protection than it would if it were stored in the UK. Where this is the case, we will make sure that they agree to: keep your personal information secure; apply the same levels of protection as we are required to apply to information held in the UK, and to use it only for the purpose of providing our services. We will do this by putting in place appropriate safeguards and protections as stated under UK law, for example using a data-transfer agreement incorporating certain standard model protection clauses.</p>
                        <h2 id="lftSide11">11. Cookie Policy</h2>
                        <p>An HTTP Cookie contains a string of texts that has information about the browser. Each cookie is effectively a small lookup table containing pairs of values. Once the cookie has been read by the code on the server or client computer, the data can be retrieved and used to customise the web page appropriately.</p>
                        <p>We use cookies to identify your browser so we can tailor your browsing experience and keep track of how you use our website so that we can improve our services. Also, we require cookies to remember your preferences, maintain authentication and security, enhance service features and performance, research and analytics, and for advertising purpose.</p>
                        <p>Please go through our <a href="cookies-policy.html">Cookie Policy</a> for detailed information.</p>
                        <h2 id="lftSide12">12. How do we keep your Information Secure?</h2>
                        <p>When your privacy is a matter of utmost concern for us then data security also holds the same level of concern. We take proper security measures to prevent your personal information from being accidentally lost, used or accessed in an unauthorised way, altered or disclosed.</p>
                        <p>We will keep Your Personal Data secure in accordance with our legal responsibilities. Also, reasonable steps will be taken to safeguard your Personal Data against it being accessed unlawfully or maliciously by a third party.</p>
                        <p>We expect you to take judicious steps to safeguard your own privacy when transferring information to us, such as not sending confidential information over unprotected email, ensuring email attachments are password protected or encrypted and only using secure methods of postage when original documentation is being sent to us.</p>
                        <p>Your Personal Data will be retained by us either electronically or in paper format for a minimum of six years (as mentioned in the Information Retention), or in instances whereby we have the legal right to such information we will retain records indefinitely.</p>
                        <p>Please note that where it’s appropriate, our sites use HTTPS to help keep information about you secure. However, no data transmission over the internet can be guaranteed to be totally secure. Certain information may also be encrypted to minimise the risk of interception during transit. We also ensure high level of inbuilt security checks while transferring/processing your personal information within our group websites mentioned at the end of the page, to our partners, other companies &amp; advertisement networks.</p>
                        <h2 id="lftSide13">13. Your Legal Rights</h2>
                        <h4>Right of Access</h4>
                        <p>You have the right to obtain from us confirmation as to whether or not personal data concerning you is being processed, and, where that is the case, access to the personal data and the following information:</p>
                        <ol>
                          <li>the purposes of the processing;</li>
                          <li>the categories of personal data concerned;</li>
                          <li>the recipients or categories of recipient to whom the personal data have been or will be disclosed, in particular recipients in third countries or international organisations;</li>
                          <li>where possible, the envisaged period for which the personal data will be stored, or, if not possible, the criteria used to determine that period;</li>
                          <li>the existence of the right to request from us rectification or erasure of personal data or restriction of processing of personal data concerning you or to object to such processing;</li>
                          <li>the right to lodge a complaint with a supervisory authority;</li>
                          <li>where the personal data are not collected from you, any available information as to their source;</li>
                          <li>the existence of automated decision-making, including profiling, referred to in <a href="https://gdpr-info.eu/art-22-gdpr/">Article 22</a>(1) and (4) and, at least in those cases, meaningful information about the logic involved, as well as the significance and the envisaged consequences of such processing for you.</li>
                        </ol>
                        <p>If you wish to avail yourself of this right of confirmation, you may do so, at any time, by sending us an email on <a href="mailto:info@loantube.com">info@loantube.com</a> or by writing to Data Protection Officer at Tiger Lion Financial Limited, 71-75 Shelton Street, Covent Garden, London, WC2H 9JQ.</p>
                        <h4>Right to Object</h4>
                        <ol>
                          <li>You have the right granted by the European legislator to object, on grounds relating to your particular situation, at any time, to the processing of personal data concerning you, which is based on point (e) or (f) of Article 6(1) of the GDPR. This also applies to profile based on these provisions.</li>
                          <li>Tiger Lion Financial Limited shall no longer process the personal data in the event of the objection unless we can demonstrate compelling legitimate grounds for the processing which override your interests, rights, and freedoms, or for the establishment, exercise or defense of legal claims.</li>
                          <li>If Tiger Lion Financial Limited processes personal data for direct marketing purposes, you shall have the right to object at any time to the processing of personal data concerning you for such marketing. This applies to profile to the extent that it is related to such direct marketing. If you object to Tiger Lion Financial Limited to the processing for direct marketing purposes, Tiger Lion Financial Limited will no longer process the personal data for these purposes.</li>
                          <li>In addition, you have the right, on grounds relating to your particular situation, to object to processing of personal data concerning you by Tiger Lion Financial Limited for scientific or historical research purposes, or for statistical purposes pursuant to Article 89(1) of the GDPR, unless the processing is necessary for the performance of a task carried out for reasons of public interest.</li>
                          <li>In order to exercise the right to Object, you may contact us by sending us an email on <a href="mailto:info@loantube.com">info@loantube.com</a> or by writing to Data Protection Officer at Tiger Lion Financial Limited, 71-75 Shelton Street, Covent Garden, London, WC2H 9JQ. In addition, you are free in the context of the use of information society services, and notwithstanding Directive 2002/58/EC, to use your right to object by automated means using technical specifications.</li>
                        </ol>
                        <h4>Right to Rectification</h4>
                        <p>You have the right to obtain from us, without undue delay, the rectification of inaccurate personal data concerning you. Taking into account the purposes of the processing, you have the right to have incomplete personal data completed, including by means of providing a supplementary statement.</p>
                        <h4>Right to Erasure</h4>
                        <p>You have the right granted by the European legislator to obtain from us the erasure of personal data concerning you without undue delay, and we have the obligation to erase personal data without undue delay where one of the following grounds applies, as long as the processing is not necessary:</p>
                        <ol>
                          <li>The personal data are no longer necessary in relation to the purposes for which they were collected or otherwise processed.</li>
                          <li>You withdraw consent to which the processing is based according to the point (a) of Article 6(1) of the GDPR, or point (a) of Article 9(2) of the GDPR, and where there is no other legal ground for the processing.</li>
                          <li>You object to the processing pursuant to Article 21(1) of the GDPR and there are no overriding legitimate grounds for the processing or you object to the processing pursuant to Article 21(2) of the GDPR.</li>
                          <li>The personal data have been unlawfully processed.</li>
                          <li>The personal data must be erased for compliance with a legal obligation in Union or Member State law or any law to which we are subject.</li>
                          <li>The personal data have been collected in relation to the offer of information society services referred to in Article 8(1) of the GDPR.</li>
                        </ol>
                        <p>If one of the aforementioned reasons applies, and you wish to request the erasure of personal data stored by Tiger Lion Financial Limited, you may, at any time, by sending us an email on <a href="mailto:info@loantube.com">info@loantube.com</a> or by writing to Data Protection Officer at Tiger Lion Financial Limited, 71-75 Shelton Street, Covent Garden, London, WC2H 9JQ. Data Protection Officer of Tiger Lion Financial Limited shall promptly ensure that the erasure request is complied with immediately.</p>
                        <p>Where we have made personal data public and are obliged pursuant to Article 17(1) to erase the personal data, we, taking account of available technology and the cost of implementation, shall take reasonable steps, including technical measures, to inform other controllers processing the personal data that you have requested erasure by such controllers of any links to, or copy or replication of, those personal data, as far as processing is not required. Data Protection Officer of Tiger Lion Financial Limited will arrange the necessary measures in individual cases.</p>
                        <h4>Right to Data Portability</h4>
                        <p>You have the right granted by the European legislator, to receive the personal data concerning you, which was provided to us, in a structured, commonly used and machine-readable format. You have the right to transmit those data to another controller without hindrance from us to which the personal data have been provided, as long as the processing is based on consent pursuant to point (a) of Article 6(1) of the GDPR or point (a) of Article 9(2) of the GDPR, or on a contract pursuant to point (b) of Article 6(1) of the GDPR, and the processing is carried out by automated means.</p>
                        <p>Furthermore, in exercising your right to data portability pursuant to Article 20(1) of the GDPR, you have the right to have personal data transmitted directly from one controller to another, where technically feasible and when doing so does not adversely affect the rights and freedoms of others.</p>
                        <p>In order to assert the right to data portability, you may, at any time, contact us by sending an email on <a href="mailto:info@loantube.com">info@loantube.com</a> or by writing to Data Protection Officer at Tiger Lion Financial Limited, 71-75 Shelton Street, Covent Garden, London, WC2H 9JQ.</p>
                        <h4>Right to Restriction of Information Processing</h4>
                        <p>You have the right granted by the European legislator to obtain from us the restriction of processing where one of the following applies:</p>
                        <ol>
                          <li>The accuracy of the personal data is contested by you, for a period enabling us to verify the accuracy of the personal data.</li>
                          <li>The processing is unlawful and you oppose the erasure of the personal data and requests instead of the restriction of their use instead.</li>
                          <li>We no longer need the personal data for the purposes of the processing, but they are required by you for the establishment, exercise or defense of legal claims.</li>
                          <li>You have objected to processing pursuant to Article 21(1) of the GDPR pending the verification whether the legitimate grounds of ours override those of yours.</li>
                        </ol>
                        <p>If one of the aforementioned conditions is met, and you wish to request the restriction of the processing of personal data stored by Tiger Lion Financial Limited, you may at any time contact us by sending us an email on <a href="mailto:info@loantube.com">info@loantube.com</a> or by writing to Data Protection Officer at Tiger Lion Financial Limited, 71-75 Shelton Street, Covent Garden, London, WC2H 9JQ. The Data Protection Office of Tiger Lion Financial Limited will arrange the restriction of the processing.</p>
                        <h4>Right to complain to the Information Commissioner’s Office (ICO) –</h4>
                        <p>We will try to resolve any complaint that you may have in relation to data protection issues. If you are not happy with our response or if you have any concerns or complaints as to how we have handled Your Personal Data you may lodge a complaint with the UK’s data protection regulator, the ICO, who can be contacted through their website at <a href="https://ico.org.uk/global/contact-us/">https://ico.org.uk/global/contact-us/</a> or by writing to Information Commissioner’s Office, Wycliffe House, Water Lane, Wilmslow, Cheshire, SK9 5AF.</p>
                        <h2 id="lftSide14">14. Details of Data Protection Officer (DPO) for Complaints &amp; Concerns</h2>
                        <p>In case you need to understand the mechanism of our data collection, usage, violations, security and any other data security-related information, or if you have any concerns about how we have handled your personal data, you are requested to contact our dedicated Data Protection Officer. A DPO is a nominated officer oversees data protection strategy and implementation to ensure compliance with GDPR requirements.</p>
                        <p>Our Correspondence Address:<br/>
                          The Data Protection Officer<br/>
                          Tiger Lion Financial Limited<br/>
                          71-75 Shelton Street,<br/>
                          Covent Garden,<br/>
                          London,<br/>
                          WC2H 9JQ</p>
                        <p>If you wish to contact our DPO by email, you can send your email on <a href="mailto:info@loantube.com">info@loantube.com</a></p>
                        <h2 id="lftSide15">15. Revision of the Policy</h2>
                        <p>We reserve the right to amend or modify this Privacy Policy at any time and if we change or revise the policy, it will be published on this page. If we make significant changes to this policy, we may also notify you by other means such as sending an email. Where required by law we will obtain your consent to make these changes.</p>
                        <h3></h3>
                        <h3><b>List of our websites owned &amp; operated by Tiger Lion Financial Limited:</b></h3>
                        <ol>
                          <li><a href="https://www.tigerlionfinancial.co.uk">www.tigerlionfinancial.co.uk</a></li>
                          <li><a href="https://www.786loans.uk">www.786loans.uk</a></li>
                          <li><a href="https://www.oysterloan.co.uk">www.oysterloan.co.uk</a></li>
                          <li><a href="https://www.loan-broker.uk">www.loan-broker.uk</a></li>
                          <li><a href="https://www.loan-princess.uk">www.loan-princess.uk</a></li>
                          <li><a href="https://www.loantube.com">www.loantube.com</a></li>
                        </ol>
                        <p>You can also check us on FCA register by clicking on <a href="https://register.fca.org.uk/ShPo_FirmDetailsPage?id=001b000003RFLpvAAH">Tiger Lion Financial Limited</a>.</p>
                        <hr />
                        <p>Last Updated: July 2019</p>
                    </div>
        </>
    )
}