import React from 'react'
import {Link} from 'react-router-dom'

export default (props) => {
    return(
        <>
        <li><Link to={props.href}><div className={props.clsName}></div>{props.loanName}</Link></li>
        </>
    )
}