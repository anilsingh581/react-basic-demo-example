import React from 'react'
import Socialfooter from './socialfooter'

export default () => {

    const footerLinks = {
        socialLinks:[
            {mediaLink:'https://www.facebook.com/loantube', clsName:'fa fa-facebook'},
            {mediaLink:'https://www.linkedin.com/company/loantube/', clsName:'fa fa-linkedin'},
            {mediaLink:'https://www.youtube.com/channel/UCkTOSD5_iHzacb_yC5fspxg', clsName:'fa fa-youtube-play'},
            {mediaLink:'https://twitter.com/Loan_Tube', clsName:'fa fa-twitter'},
        ]

    }

    const renderSocialLinks = () => {
       return footerLinks.socialLinks.map((item, i) => <Socialfooter key={(Math.random()*1000) + i} linkName={item.mediaLink} clsName={item.clsName} />)
    }

    return renderSocialLinks()
    
}