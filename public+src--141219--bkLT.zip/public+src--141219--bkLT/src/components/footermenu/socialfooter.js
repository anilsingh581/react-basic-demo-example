import React from 'react'

export default (props, i) => 
    <li key={Math.floor(Math.random() * 10000) + i}><a href={props.linkName} target="_blank" rel="noopener noreferrer"><i className={props.clsName} aria-hidden="true"></i></a></li>
       