import React from 'react'
import {Link} from 'react-router-dom'

export default (props) => <Link to={props.menuLink} id={props.menuID}>{props.menuName} {props.menuID !== 6 ? '|' : ''} </Link>