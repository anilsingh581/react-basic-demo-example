import React from 'react'
import {Link} from 'react-router-dom'

export default (props, i) => <li key={Math.floor(Math.random() * 10000) + i}><Link to={props.menulink} id={props.menuID}>{props.menuname}</Link></li>