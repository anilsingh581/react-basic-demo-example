import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import renderHTML from 'react-render-html';
import { categoryName } from '../assets/js/helpers'

export default class GuidesMainC extends Component {
    state = {
        blgMainContent: null,
        blogUID: null
    }

    constructor(props) {
        super(props);
        let des = this.props.blgMainContent;
        this.state.blogUID = this.props.blogUID;
        this.state.blgTitleUrl = this.props.blgTitleUrl;

        if (des !== undefined) {
            this.state.blgMainContent = des.substring(0, 200);
        }
    }
    
    render() {
        return (
            <>
                <div className="blgSection" id={this.props.myId}>
                    <div className="blogMainImg">
                        <Link to={{ pathname: '/guides/guidesdetails', search: "/" + this.state.blgTitleUrl, state: { blogUID: this.state.blogUID } }}><img src={this.props.blgImg} alt={this.props.blgAlt} /></Link>
                    </div>
                    <div className="blogHeader">
                        <ul>
                            <li className="blgEntryDate">{this.props.blgTime}</li>
                            <li>|</li>
                            <li className="blgEntryCategory">
                                <Link to={{ pathname: this.props.blgCategoryUrl, search: this.props.blgCategoryUrl, state: { id: this.props.blgCategory } }}>{categoryName(this.props.blgCategory)}</Link>
                            </li>
                        </ul>
                    </div>
                    <div className="blgEntryTitle">
                        <Link to={{ pathname: '/guides/guidesdetails', search: "/" + this.state.blgTitleUrl, state: { blogUID: this.state.blogUID } }}>{this.props.blgTitle}</Link>
                    </div>
                    <div className="blgEntryContent">{renderHTML(`${this.state.blgMainContent}...`)} </div>
                    <div className="blgReadMore">
                        <Link to={{ pathname: '/guides/guidesdetails', search: "/" + this.state.blgTitleUrl, state: { blogUID: this.state.blogUID } }}>Read more</Link>
                    </div>
                </div>
            </>
        )
    }
}