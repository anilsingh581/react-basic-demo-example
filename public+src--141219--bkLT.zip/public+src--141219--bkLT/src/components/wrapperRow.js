import React from 'react'

export default (props) =>
    <section className={props.cls}>
        <div className="container">
            <div className="row">
                {props.children}
            </div>
        </div>
    </section>
