import React from 'react'

export default () => 
<div className="accordion" id="accordionBefore">
    <div className="card">
        <div id="headingOne">
        <h2 className="mb-0" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
            What should be my minimum age while applying for a loan?
        </h2>
        </div>
        <div id="collapseOne" className="collapse show" aria-labelledby="headingOne" data-parent="#accordionBefore">
        <div className="card-body">
            Our lenders lend only to customers who are aged 18 or above.
        </div>
        </div>
    </div>
    <div className="card">
        <div id="headingTwo">
        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
            Can I apply for a holiday loan if I’m unemployed?
        </h2>
        </div>
        <div id="collapseTwo" className="collapse" aria-labelledby="headingTwo" data-parent="#accordionBefore">
        <div className="card-body">
            You need to be in a permanent and paid employment. If you are unemployed, you may not be able to pass the lender’s affordability assessments. The exception is if you have other good sources of incomes like rental income and you can convince lenders that you can afford to pay the loan with those other incomes.
        </div>
        </div>
    </div>
    <div className="card">
        <div id="headingThree">
            <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
            If I am bankrupt, I have an Individual Voluntary Arrangement (IVA), or I am on a debt management arrangement plan, will that affect my chances of getting a holiday loan?
            </h2>
        </div>
        <div id="collapseThree" className="collapse" aria-labelledby="headingThree" data-parent="#accordionBefore">
            <div className="card-body">
            People on IVA, Debt Management Plan and on Bankruptcy are considered as negative customers by lenders. It is a sign that you can’t really manage your finances. Due to this, we are very sure we won’t be able to find you a loan if you are on IVA or Debt Management Plan or have filed a bankruptcy in past.
            </div>
        </div>
        </div>
    <div className="card">
        <div id="headingFour">
            <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
            How much do I need to tell you about myself?
            </h2>
        </div>
        <div id="collapseFour" className="collapse" aria-labelledby="headingFour" data-parent="#accordionBefore">
            <div className="card-body">
            Not as much as you would tell a bank! However, we’ll need you to share with us how much you earn, who you work for, what you spend every month, where are you living and your residential status.
            </div>
        </div>
        </div>
        
    <div className="card">
        <div id="headingFive">
            <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
            Will I need a guarantor to apply for Unsecured Holiday Loan?
            </h2>
        </div>
        <div id="collapseFive" className="collapse" aria-labelledby="headingFive" data-parent="#accordionBefore">
            <div className="card-body">
            No, you don’t.
            </div>
        </div>
        </div>
        
    <div className="card">
        <div id="headingSix">
            <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
            Can I get a quick “yes” or “no”?
            </h2>
        </div>
        <div id="collapseSix" className="collapse" aria-labelledby="headingSix" data-parent="#accordionBefore">
            <div className="card-body">
            If we have all the information we and our lenders need, a “yes” or “no” answer from lenders who are willing to lend you with their APRs/quotes will be displayed on your screen on a real-time basis.
            </div>
        </div>
        </div>
        <div className="card">
            <div id="headingSeven">
            <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                Does LoanTube lend me the money?
            </h2>
            </div>
            <div id="collapseSeven" className="collapse" aria-labelledby="headingSeven" data-parent="#accordionBefore">
            <div className="card-body">
                No – we are a credit broker. We are licensed by the Financial Conduct Authority to match borrowers with lenders. We arrange your loan but we do not transfer you the money and you do not pay the money back to us – you do that to your lender. Moreover, to ensure the highest levels of industry practice across the board, we only work with lenders who have been inspected and given their licence by the Financial Conduct Authority.
            </div>
            </div>
        </div>
        <div className="card">
            <div id="headingEight">
                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
                Who chooses the lenders to forward my application to?                                            
                </h2>
            </div>
            <div id="collapseEight" className="collapse" aria-labelledby="headingEight" data-parent="#accordionBefore">
                <div className="card-body">
                Part us, part you! When we become partners with a lender, one of the first things they do is to send us a list of the types of borrowers they would like to work with. You might be just the type of borrower one company is looking for but another might not consider you. Our intelligent matchmaking system finds the right matching lenders for you which we show you in a list along with their Quotes/APRs. It’s you who decide which one to go with after going through the quotes and subjected conditions of all such lenders.
                </div>
            </div>
            </div>
            <div className="card">
                <div id="headingNine">
                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
                    Does LoanTube charge me for the service?
                </h2>
                </div>
                <div id="collapseNine" className="collapse" aria-labelledby="headingNine" data-parent="#accordionBefore">
                <div className="card-body">
                    No, LoanTube’s mission is to bring down the cost of borrowing by trying to find the cheapest rates for you. All of our hard work would be undone if we found you a great loan and then slapped a fee on top for our service. You never pay us a penny.
                </div>
                </div>
            </div>
            <div className="card">
                <div id="headingTen">
                    <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
                    Will you credit check me?
                    </h2>
                </div>
                <div id="collapseTen" className="collapse" aria-labelledby="headingTen" data-parent="#accordionBefore">
                    <div className="card-body">
                    When we’re searching around for the best deal for you, we only carry out a soft credit check. Soft credit checks have no effect at all on your credit score. By carrying out the soft check, it gives us a better idea of which lender to propose your holiday loan to because, when they make a decision, they consider both what’s on your application and what’s in your credit report.
                    </div>
                </div>
                </div>
                <div className="card">
                <div id="headingEve">
                    <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseEve" aria-expanded="false" aria-controls="collapseEve">
                    What is a soft credit check?
                    </h2>
                </div>
                <div id="collapseEve" className="collapse" aria-labelledby="headingEve" data-parent="#accordionBefore">
                    <div className="card-body">
                    A soft credit check is a type of a credit check which does not leave a footprint on your report, which means, your credit score will not be affected with this. It’s only you who can see the soft credit checks on your credit report. Third party lenders can’t see this. So soft credit checks don’t affect your borrowing capacity.
                    </div>
                </div>
                </div>
                <div className="card">
                <div id="headingTwe">
                    <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwe" aria-expanded="false" aria-controls="collapseTwe">
                    Can I change my mind?
                    </h2>
                </div>
                <div id="collapseTwe" className="collapse" aria-labelledby="headingTwe" data-parent="#accordionBefore">
                    <div className="card-body">
                    Yes. You’re never under any obligation to accept an offer that you receive from LoanTube. Even if we say “yes” then you turn around and tell us “no”, there’s no charge for our service.
                    </div>
                </div>
                </div>
    </div>
    