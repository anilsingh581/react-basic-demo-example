import React from 'react'
const images = require.context('../../assets/images')

export default () => 
        <>
            <div className="brdCenterText">If you know where you’re going and you’ve already mentally packed your suitcases ready to go, what three tips would LoanTube give you about getting a <a href="home-improvement-loans-guide.html">holiday loan</a>?</div>
                            <div className="threeText"><div className="threeimg"><img src={images('./Holiday31.png')} alt="holiday loan" /></div>
                            <div>Make sure that the size of your loan repayment comfortably fits within your monthly budget. You can do this by increasing the number of months of the loan tenure but please remember that this will also increase the overall cost of the loan.</div></div>
                            <div className="threeText"><div className="threeimg"><img src={images('./Holiday32.png')} alt="holiday loan" /></div><div>Your travel agent might offer you the chance to apply for a holiday loan, however, be careful. Most travel agents only work with a particular holiday loan company. And the problem is you might not be getting the best deal. With LoanTube, you can instantly compare offers side-by-side from multiple holiday loan providers. You will see a list of all the rates they are offering you so you can make the right choice. It’s always better to have more options because when companies compete for your business, you’re the biggest winner.</div></div>
                            <div className="threeText"><div className="threeimg"><img src={images('./Holiday33.png')} alt="holiday loan" /></div><div>Be careful before applying for any holiday loan that is secured. If someone offers you a secured loan, there may be a risk of losing your home, your car, or other valuables if you are unable to keep up with the repayments.</div></div>
        </>
    