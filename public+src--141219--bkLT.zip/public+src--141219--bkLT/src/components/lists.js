import React from 'react'

export default (props) => <li>{props.text}</li>
       