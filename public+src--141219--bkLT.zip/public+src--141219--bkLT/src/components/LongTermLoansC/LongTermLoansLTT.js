import React from 'react'
const images = require.context('../../assets/images')

export default () => {
   return( <>
    <div className="brdCenterText">Long term loans can be defined as a debt that is paid off over a period of more than one year. This can range from anywhere between 12 months to 30 years. A long term loan involves borrowing a set amount of money over a specific period of time, with a pre-planned payment schedule. People often opt for longer-term loans when they are struggling with existing debt from various lenders. Often, people can be caught up in debts caused by shorter-term payday loans with high-interest rates. Borrowing for longer terms can remove the burden of repaying the debt immediately, reduce the interest rate you pay overtime, and also consolidate many of your debts into one. Three key things to know about Long Term Loans:</div>
                            <div className="threeText"><div className="threeimg"><img src={images('./home31.png')} alt="Home improvement Loans" /></div>
                            <div>Long term loans are a lot more flexible than most loans. You can decide exactly how much you want to borrow and for how long. This means you can tailor the loan to suit you and your circumstances.</div></div>
                            <div className="threeText"><div className="threeimg"><img src={images('./home32.png')} alt="Home improvement Loans" /></div><div>The individual repayments on long term loans are generally smaller. When you spread the cost of your loan over a longer period of time, the monthly repayments reduce, meaning you have more regular income for saving. You may, however, end up paying more back overall.</div></div>
                            <div className="threeText"><div className="threeimg"><img src={images('./home33.png')} alt="Home improvement Loans" /></div><div>You may be able to get a larger loan. With the repayments being smaller, your income may give you more freedom in requesting a larger loan that meets your requirements. This can be used to finance a big life event such as a home renovation or wedding.</div></div>
    </>
   )
}