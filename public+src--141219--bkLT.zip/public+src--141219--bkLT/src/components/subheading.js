import React from 'react'

export default (props) => 
    <h2>{props.children}</h2>
       