import React from 'react'

export default (props) => <div className={props.cls}><img src={props.mysrc} alt={props.alt} /></div>