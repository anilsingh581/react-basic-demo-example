import React from 'react'

export default (props) => 
<div className="col-lg-6">
        <div className="ourPartnerBox">
        <div className="imgLogo"><img src={props.partLogo} alt={props.partName} /></div>
        <h4>{props.partName}</h4>
        <p>{props.abtPart}</p>
        <div className="registText">
            Company Reg. Number: <span>{props.companyNum}</span>  {props.FCANum !=='' && <label>| FCA Reg. Number: <span>{props.FCANum}</span></label>}
        </div>
        <h5><a href={props.url} target="_blank" rel="noopener noreferrer">Website</a> | <a href={props.terms} target="_blank" rel="noopener noreferrer">T&amp;Cs</a> | <a href={props.privacy} target="_blank" rel="noopener noreferrer">Privacy</a> | <a href={props.cookiesPolicy} target="_blank" rel="noopener noreferrer">Cookies Policy</a></h5>
        </div>
    </div>