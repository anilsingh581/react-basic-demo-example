import React from 'react'

export default (props) => 
            <li><a href={props.href} target="_blank" rel="noopener noreferrer"><img src={props.imgSrc} alt={props.companyName} /></a></li>
       