import React from 'react'

export default () => {
    return (
            <div className="accordion" id="accordionBefore">
                                    <div className="card">
                                      <div id="headingOne">
                                        <h2 className="mb-0" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                            What should be my minimum age while applying for a loan?
                                        </h2>
                                      </div>
                                      <div id="collapseOne" className="collapse show" aria-labelledby="headingOne" data-parent="#accordionBefore">
                                        <div className="card-body">
                                            You must be 18 years of age or above. Our lenders lend only to customers who are aged 18 or above.
                                        </div>
                                      </div>
                                    </div>
                                    <div className="card">
                                      <div id="headingTwo">
                                        <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                            Do I need to have a job to apply for a home improvement loan?
                                        </h2>
                                      </div>
                                      <div id="collapseTwo" className="collapse" aria-labelledby="headingTwo" data-parent="#accordionBefore">
                                        <div className="card-body">
                                            That’s right. We can only consider your application if you’re in permanent or part-time employment. If you are unemployed, you may not be able to pass the lender’s affordability assessments. The exception is if you have other good sources of incomes like rental income and you can convince lenders that you can afford to pay the loan with those other incomes.
                                        </div>
                                      </div>
                                    </div>
                                    <div className="card">
                                        <div id="headingThree">
                                          <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                            If I am bankrupt, I have an Individual Voluntary Arrangement (IVA), or I am on a debt management arrangement plan, should I apply?
                                          </h2>
                                        </div>
                                        <div id="collapseThree" className="collapse" aria-labelledby="headingThree" data-parent="#accordionBefore">
                                          <div className="card-body">
                                            We’re sorry but we can’t accept applications from you. People on IVA, Debt Management Plan and on Bankruptcy are considered as negative customers by lenders. It is a sign that you can’t really manage your finances. Due to this, we are very sure we won’t be able to find you a loan if you are on IVA or Debt Management Plan or have filed a bankruptcy in past.
                                          </div>
                                        </div>
                                      </div>
                                    <div className="card">
                                        <div id="headingFour">
                                          <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                            What do you need to know about me to get a home improvement loan?
                                          </h2>
                                        </div>
                                        <div id="collapseFour" className="collapse" aria-labelledby="headingFour" data-parent="#accordionBefore">
                                          <div className="card-body">
                                            When you apply, we’d really appreciate it if you hand out details of where you are living, your residential status, where do you work (current employment status), your monthly expenditure and your earnings.
                                          </div>
                                        </div>
                                      </div>
                                      
                                    <div className="card">
                                        <div id="headingFive">
                                          <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                            Do I need to provide you with a guarantor?
                                          </h2>
                                        </div>
                                        <div id="collapseFive" className="collapse" aria-labelledby="headingFive" data-parent="#accordionBefore">
                                          <div className="card-body">
                                            No
                                          </div>
                                        </div>
                                      </div>
                                      
                                    <div className="card">
                                        <div id="headingSix">
                                          <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                                            Do I get an instant decision?
                                          </h2>
                                        </div>
                                        <div id="collapseSix" className="collapse" aria-labelledby="headingSix" data-parent="#accordionBefore">
                                          <div className="card-body">
                                            Depends. If we have all the information we and our lenders need, a “yes” or “no” answer from lenders who are willing to lend you with their APRs/quotes will be displayed on your screen on a real-time basis.
                                          </div>
                                        </div>
                                      </div>
                                      <div className="card">
                                          <div id="headingSeven">
                                            <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                                                Does LoanTube lend me the money?
                                            </h2>
                                          </div>
                                          <div id="collapseSeven" className="collapse" aria-labelledby="headingSeven" data-parent="#accordionBefore">
                                            <div className="card-body">
                                                No, we do not. Because we are a credit broker. A broker pairs up borrowers and lenders. It’s important that you know that LoanTube and all the lenders we work with are licensed by the Financial Conduct Authority.
                                            </div>
                                          </div>
                                        </div>
                                        <div className="card">
                                            <div id="headingEight">
                                              <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">
                                                How do you choose which lenders to approach on my behalf?                                            
                                              </h2>
                                            </div>
                                            <div id="collapseEight" className="collapse" aria-labelledby="headingEight" data-parent="#accordionBefore">
                                              <div className="card-body">
                                                When we become partners with a lender, one of the first things they do is to send us a list of the types of borrowers they would like to work with. You might be just the type of borrower one lender is looking for but another might not consider you. Our job is to pair you with the right lenders based on the information you give us.
                                              </div>
                                            </div>
                                          </div>
                                          <div className="card">
                                              <div id="headingNine">
                                                <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">
                                                    How does LoanTube make money? Will it mean that I pay more?
                                                </h2>
                                              </div>
                                              <div id="collapseNine" className="collapse" aria-labelledby="headingNine" data-parent="#accordionBefore">
                                                <div className="card-body">
                                                    We don’t charge you anything to apply for a loan on LoanTube. We don’t even charge if we find you a loan and you decide not to go ahead with it. We receive a “thank-you” payment from the lender when one of our applicants takes out a loan. If you’re approved, you’ll pay the lender exactly what you’d have paid them had you approached them directly.
                                                </div>
                                              </div>
                                            </div>
                                            <div className="card">
                                                <div id="headingTen">
                                                  <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
                                                    Will you credit check me?
                                                  </h2>
                                                </div>
                                                <div id="collapseTen" className="collapse" aria-labelledby="headingTen" data-parent="#accordionBefore">
                                                  <div className="card-body">
                                                    When we’re searching around for the best deal for you, we only carry out a soft credit check. Soft credit checks have no effect at all on your credit score. By carrying out the soft check, it gives us a better idea of which lender to propose your home improvement loan to because, when they make a decision, they consider both what’s on your application and what’s in your credit report.
                                                  </div>
                                                </div>
                                              </div>
                                              <div className="card">
                                                <div id="headingEve">
                                                  <h2 className="mb-0 collapsed" data-toggle="collapse" data-target="#collapseEve" aria-expanded="false" aria-controls="collapseEve">
                                                    Can I change my mind?
                                                  </h2>
                                                </div>
                                                <div id="collapseEve" className="collapse" aria-labelledby="headingEve" data-parent="#accordionBefore">
                                                  <div className="card-body">
                                                    Of course. If you want to stop your application at any point or you receive an offer but you decide that you don’t want to accept it, that’s fine. There’s no obligation to our service and you won’t be charged by us or our lenders.
                                                  </div>
                                                </div>
                                              </div>
                                  </div>
    )
}