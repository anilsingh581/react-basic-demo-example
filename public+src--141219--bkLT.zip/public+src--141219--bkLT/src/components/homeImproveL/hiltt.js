import React from 'react'
const images = require.context('../../assets/images')

export default () => {
   return( <>
    <div className="brdCenterText">Did you know that, once a <a href="home-improvement-loans-guide.html">home improvement project</a> is completed, it makes three-quarters of Brits feel "happy" and "content"? 50% of us have improved our homes in the last five years. However, what should you look at if you are seeking a home improvement loan?</div>
                            <div className="threeText"><div className="threeimg"><img src={images('./home31.png')} alt="Home improvement Loans" /></div>
                            <div>Look for a monthly repayment amount that suits you. By taking out a loan over a longer period, you reduce the size of your repayments (but this also means that you end up paying more interest over the course of the loan).</div></div>
                            <div className="threeText"><div className="threeimg"><img src={images('./home32.png')} alt="Home improvement Loans" /></div><div>Look for a loan yourself via LoanTube instead of using a home improvement finance option presented to you by your installer. An installer will normally present you with one choice but thanks to the way LoanTube works, you can compare multiple lenders’ locked-in APRs instantly and choose the right loan for you. There’s no cost for our service and you’re under no obligation to take any loan that we suggest.</div></div>
                            <div className="threeText"><div className="threeimg"><img src={images('./home33.png')} alt="Home improvement Loans" /></div><div>Look for home improvement loans, which are <a href="#">unsecured</a>. That means you don’t have to put your home, car, or anything else of value as collateral that may stand at risk if you can’t repay the loan*.</div></div>
    </>
   )
}