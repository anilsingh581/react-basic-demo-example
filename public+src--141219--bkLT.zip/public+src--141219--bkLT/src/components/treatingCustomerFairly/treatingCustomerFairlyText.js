import React from 'react'

export default () =>
    <>
        <p>We operate a <b>"Treating Customers Fairly"</b> policy in order to understand the needs and interests of our clients and to serve them best. Treating customers fairly is core to our culture and how we behave and conduct our business.<br />
            <br />
            Treating customers fairly policy takes into account, not only how we use our clients details, but how we deal with them at all stages of our business relationship. This includes:</p>
        <ul>
            <li>Clients can be confident that they are dealing with a firm where the fair treatment of customers is central to the business culture</li>
            <li>The client will receive the best service possible and their details will be referred to a reputable firm who will provide them with a suitable product or service to meet their needs and requirements</li>
            <li>Clients are provided with clear, non-misleading and un-biased information and are kept informed of progress as appropriate</li>
            <li>Clients receive a service which is of an acceptable standard and to a level they would expect</li>
            <li>Clients do not face unreasonable barriers in their dealings with us and are provided with clear communication routes and ability to make a complaint</li>
        </ul>
        <p>All customers should be dealt with in a fair manner throughout their dealings with us.</p>
    </>    