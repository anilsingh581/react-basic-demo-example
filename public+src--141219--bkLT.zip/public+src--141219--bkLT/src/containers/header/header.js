import React from 'react'
import Socialicon from '../../components/footermenu/socialIcon'
import logo from '../../assets/images/loantube.svg'
import { NavLink } from 'react-router-dom'

export default () => {
    return (
        <>
            <section>
                <div className="container">
                    <div className="row py-4">
                        <div className="col">
                            <div className="logo"><NavLink to="/home" ><img src={logo} width="235" alt="Loantube Logo" /></NavLink></div>
                        </div>
                        <div className="col d-flex justify-content-end">
                            <div className="navClick"><span className="bar1"></span><span className="bar2"></span><span className="bar3"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div className="menuWrap"></div>
            <div className="menuContainer">
                <div className="mainMenu">
                    <ul>
                        <li><NavLink to="/about-us">About Us</NavLink></li>
                        <li><a href="#" className="dropdown-toggle" data-toggle="dropdown">Loans</a>
                            <div className="dropdown-menu">
                                <NavLink className="dropdown-item" to="/unsecured-personal-loans">Unsecured Personal Loans</NavLink>
                                <NavLink className="dropdown-item" to="/home-improvement-loans">Home Improvement Loans</NavLink>
                                <NavLink className="dropdown-item" to="/wedding-loans">Wedding Loans</NavLink>
                                <NavLink className="dropdown-item" to="/holiday-loans">Holiday Loans</NavLink>
                                <NavLink className="dropdown-item" to="/payday-loans">Payday Loans</NavLink>
                                <NavLink className="dropdown-item" to="/secured-loans">Secured Loans</NavLink>
                                <NavLink className="dropdown-item" to="/debt-consolidation-loans">Debt Consolidation Loans</NavLink>
                                <NavLink className="dropdown-item" to="/guarantor-loans">Guarantor Loans</NavLink>
                                <NavLink className="dropdown-item" to="/long-term-loans">Long Term Loans</NavLink>
                            </div>
                        </li>
                        <li><NavLink to="/our-partners">Our Partners</NavLink></li>
                        <li><NavLink to="/guides/guides">Guides</NavLink></li>
                        <li><a href="#" className="dropdown-toggle" data-toggle="dropdown">Loan Guides</a>
                            <div className="dropdown-menu">
                                <NavLink className="dropdown-item" id={2} to={{ pathname: '/guides/unsecured-personal-loans', search: 'unsecured-personal-loans', state: { id: 2 } }}>Unsecured Personal Loans</NavLink>
                                <NavLink className="dropdown-item" id={4} to={{ pathname: '/guides/home-improvement-loans', search: 'home-improvement-loans', state: { id: 4 } }}>Home Improvement Loans</NavLink>
                                <NavLink className="dropdown-item" id={5} to={{ pathname: '/guides/payday-loans', search: 'payday-loans', state: { id: 5 } }}>Payday Loans</NavLink>
                                <NavLink className="dropdown-item" id={7} to={{ pathname: '/guides/wedding-loans', search: 'wedding-loans', state: { id: 7 } }}>Wedding Loans</NavLink>
                                <NavLink className="dropdown-item" id={3} to={{ pathname: '/guides/holiday-loans', search: 'holiday-loans', state: { id: 3 } }}>Holiday Loans</NavLink>
                                <NavLink className="dropdown-item" id={8} to={{ pathname: '/guides/others', search: 'others', state: { id: 8 } }}>Others</NavLink>
                            </div>
                        </li>
                        <li><NavLink to="/contact-us">Contact Us</NavLink></li>
                        <li><NavLink to="/faqs">FAQs</NavLink></li>
                    </ul>
                </div>
                <div className="socialSec">
                    <ul>
                        <Socialicon />
                    </ul>
                </div>
            </div>
        </>
    )
}