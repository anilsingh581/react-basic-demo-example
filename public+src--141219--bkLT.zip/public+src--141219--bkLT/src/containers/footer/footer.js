import React from 'react'
import Socialicon from '../../components/footermenu/socialIcon'
import Footermenu from '../../components/footermenu/footermenu'
import FootermenuBtm from '../../components/footermenu/footermenubtm'
const images = require.context('../../assets/images')

export default () => {

    const footerMenus = {
        footercompanymenu : [
            {menuID:1, menuLink:'/home', menuName:'Home'},
            {menuID:2, menuLink:'/guides', menuName:'Guides'},
            {menuID:3, menuLink:'/about-us', menuName:'About Us'},
            {menuID:4, menuLink:'/contact-us', menuName:'Contact Us'},
            {menuID:5, menuLink:'/faqs', menuName:'Faqs'}
        ],

        footerloansmenu : [
            {menuID:1, menuLink:'/unsecured-personal-loans', menuName:'Unsecured Personal Loans'},
            {menuID:2, menuLink:'/home-improvement-loans', menuName:'Home Improvement Loans'},
            {menuID:3, menuLink:'/wedding-loans', menuName:'Wedding Loans'},
            {menuID:4, menuLink:'/holiday-loans', menuName:'Holiday Loans'},
            {menuID:5, menuLink:'/bad-credit-loans', menuName:'Bad Credit Loans'},
            {menuID:6, menuLink:'/payday-loans', menuName:'Payday Loans'}
        ],

        footermenuBtm : [
            {menuID:1, menuLink:'/about-us', menuName:'About Us'},
            {menuID:2, menuLink:'/cookies-policy', menuName:'Cookies Policy'},
            {menuID:3, menuLink:'/privacy-policy', menuName:'Privacy Policy'},
            {menuID:4, menuLink:'/terms-and-conditions', menuName:'Terms and Conditions'},
            {menuID:5, menuLink:'/complaints-policy', menuName:'Complaints Policy'},
            {menuID:6, menuLink:'/treating-customers-fairly', menuName:'Treating Customers Fairly'}
        ]

    }
    const renderfootermenu = (items) => {
        return items.map((item, i) => <Footermenu key={(Math.random()*1000) + i} menulink={item.menuLink} menuname={item.menuName} menuID={item.menuID} />)
    }
    const renderfootermenuBtm = (items) => {
        return items.map((item, i) => <FootermenuBtm key={(Math.random()*1000) + i} menuLink={item.menuLink} menuName={item.menuName} menuID={item.menuID} />)
    }
    
    return (
        <>
            <footer>
        <div className="container">
            <div className="socialSec footerSocial">
                <ul>
                    <Socialicon />
                </ul>
            </div>
            <div className="row mt-5">
                <div className="col-lg-4">
                    <div className="footerMenu">
                        <h4>Company</h4>
                        <ul>
                            {renderfootermenu(footerMenus.footercompanymenu)}
                        </ul>
                    </div>
                </div>
                <div className="col-lg-4">
                    <div className="footerMenu">
                        <h4>Loans</h4>
                        <ul>
                            {renderfootermenu(footerMenus.footerloansmenu)}
                        </ul>
                    </div>
                </div>
                <div className="col-lg-4 text-center">
                    <div className="mt-4">
                        <div id="googleReview"><a href="http://bit.ly/ss"><img src={images('./googleReview.png')} alt="Google Review" /></a></div>
                    </div>
                    <div className="mt-4 mb-2"><img src={images('./btmloantubeLogo.png')} alt="Loantube" /></div>
                    <div className="copyRights">LoanTube ® 2018 All Rights Reserved.</div>
                </div>
            </div>
        </div>
    </footer>
    <section className="footerSec">{renderfootermenuBtm(footerMenus.footermenuBtm)}</section>
    <div className="backtotop"><i className="fa fa-angle-double-up" aria-hidden="true"></i></div>
    </>
    )
}