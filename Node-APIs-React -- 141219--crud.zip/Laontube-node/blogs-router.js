const express = require('express')

const BlogCtrl = require('./blog-controller')

const router = express.Router()

router.post('/Blog', BlogCtrl.createBlog)
router.put('/Blog/:id', BlogCtrl.updateBlog)
router.delete('/Blog/:id', BlogCtrl.deleteBlog)
router.get('/Blog/:id', BlogCtrl.getBlogById)
router.get('/LoanCategory/:id', BlogCtrl.getBlogCategoryById)
router.get('/Blogs', BlogCtrl.getBlogs)
router.get('/Loantype', BlogCtrl.getLoantypes)
//router.get('/Sendemail', BlogCtrl.sendEmail)

module.exports = router