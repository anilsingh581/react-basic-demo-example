const Blog = require('./blog-model')
const LoanType = require('./loantype-model')
//const Sendemail = require('./contactModel')
const nodemailer = require('nodemailer');


createBlog = (req, res) => {
    const body = req.body
   

    if (!body) {
        return res.status(400).json({
            success: false,
            error: 'You must provide a Blog',
        })
    }

    const blog = new Blog(body)
  // console.log(blog);

    if (!blog) {
        return res.status(400).json({ success: false, error: err })
    }

    blog
        .save()
        .then(() => {
            return res.status(201).json({
                success: true,
                id: Blog._id,
                message: 'Blog created!',
            })
        })
        .catch(error => {
            return res.status(400).json({
                error,
                message: 'Blog not created!',
            })
        })
}

updateBlog = async (req, res) => {
    let id = req.params.id;
    //console.log(id);
    let update = req.body;
    //console.log(update);
    if (!req.body) {
        return res.status(400).json({
            success: false,
            error: 'You must provide a body to update',
        })
    }

    var query= {blogUID: id};
    var valueUpdate = {$set: update};

    Blog.updateMany(query, valueUpdate, function (err, result) {
        if (err) {
           // console.log(err);
            return res.status(404).json({
                error,
                message: 'Blog not updated.',
            })
        }

        return res.status(200).json({
            success: true,
            id: Blog._id,
            message: 'Blog updated succesfully.',
        })
    });
}

deleteBlog = async (req, res) => {
    await Blog.findOneAndDelete({ _id: req.params.id }, (err, Blog) => {
        if (err) {
            return res.status(400).json({ success: false, error: err })
        }

        if (!Blog) {
            return res
                .status(404)
                .json({ success: false, error: `Blog not found` })
        }

        return res.status(200).json({ success: true, data: Blog })
    }).catch(err => console.log(err))
}

getBlogById = (req, res) => {
     Blog.findOne({blogUID: req.params.id}, (err, Blog) => {
        if (err) {
            return res.status(400).json({ success: false, error: err })
        }

        //console.log(Blog);
        if (!Blog) {
            return res
                .status(404)
                .json({ success: false, error: `Blog not found` })
        }
        return res.status(200).json({ success: true, data: Blog })
    }).catch(err => console.log(err))
}

getBlogCategoryById = (req, res) => {
    //console.log(req.params.id);
    Blog.find({blgCategory: req.params.id}, (err, Blog) => {
       if (err) {
           return res.status(400).json({ success: false, error: err })
       }

      // console.log(Blog);
       if (!Blog) {
           return res
               .status(404)
               .json({ success: false, error: `Blog not found` })
       }
       return res.status(200).json({ success: true, data: Blog })
   }).catch(err => console.log(err))
}

getBlogs = async (req, res) => {
   //sendEmail();
    await Blog.find({}, (err, result) => {
        if (err) {
            return res.status(400).json({ success: false, error: err })
        }
        if (!result.length) {
            return res
                .status(404)
                .json({ success: false, error: `Blog not found` })
        }
        return res.status(200).json({ success: true, data: result })
    }).catch(err => console.log(err))
}

getLoantypes = async (req, res) => {
    await LoanType.find({}, (err, response) => {
        if (err) {
            return res.status(400).json({ success: false, error: err })
        }
        if (!response.length) {
            return res
                .status(404)
                .json({ success: false, error: `Blog not found` })
        }
        return res.status(200).json({ success: true, data: response })
    }).catch(err => console.log(err))
}

// sendEmail = async (req, res) => {
//     console.log(1);
//     console.log(1);
//     const transport = nodemailer.createTransport({
//         host: 'smtp.ethereal.email',
//         port: 587,
//         auth: {
//             user: 'laron8@ethereal.email',
//             pass: 'SAGxYc124fj42u4ZNQ'
//         }
//     });
//     console.log(2);
//     const message = {
//         from: 'laron8@ethereal.email', // Sender address
//         to: 'sheosagar.loantube@gmail.com',         // List of recipients
//         subject: 'Test email from LT demo', // Subject line
//         text: 'Have the most fun you can in a fun.... Get your fun today!' // Plain text body
//     };

//     transport.sendMail(message, function(err, info) {
//         //console.log(message);
//         if (err) {
//           console.log(err)
//         } else {
//             console.log(3);
//           console.log(info);
//         }
//     });

// }

module.exports = {
    createBlog,
    updateBlog,
    deleteBlog,
    getBlogs,
    getBlogById,
    getLoantypes,
    getBlogCategoryById
    //sendEmail
}