const mongoose = require('mongoose')
const Schema = mongoose.Schema

const Blog = new Schema(
    {
        titleName: { type: String, required: true },
        contentDescription: { type: String },
        metaattrib: { type: String },
        metaattribvalue: { type: String},
        metacontent: { type: String },
        blgCategory: { type: String, required: true },
        titleURL: { type: String },
        blgCategoryURL: { type: String },
        time: { type: [String], required: true },
        text: { type: String },
        blgImg: { type: String },
        blogUID: { type: String },
        allMeta: { type: String }
    },
    { timestamps: true },
)

module.exports = mongoose.model('blogs', Blog);
