const mongoose = require('mongoose')
const Schema = mongoose.Schema

const Loantype = new Schema(
    {
        id: { type: String}, 
        loantype: { type: String },
        loandesc: { type: String },
        loanpageurl: { type: String },
    },
    { timestamps: true },
)

module.exports = mongoose.model('loantypes', Loantype)
